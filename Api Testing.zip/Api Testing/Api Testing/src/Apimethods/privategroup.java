package Apimethods;

import static io.restassured.RestAssured.given;

import java.io.File;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class privategroup {
	AuthorizationToken a=new AuthorizationToken();
//Social private Group
	@Test(priority=1)
	public void  CreateSocialprivateGroup() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

        File privategroupimage=new File("C:\\Users\\CURD Automation\\Downloads\\AutomationTestImage.jpg");

String CreateprivateGroup= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("name","SpringTech private" ).multiPart("category", "social")
			.multiPart("privacy","private").multiPart("description","allsoftware").multiPart("interest","sports").multiPart("image",privategroupimage)
			.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

       JsonPath CGpri=new JsonPath(CreateprivateGroup);

          String Createprivategroupmessage=CGpri.get("message");
          String privateGroupId = CGpri.get("data._id");
          String privateGroupname = CGpri.get("data.name");
          String privateGroupcategory=CGpri.get("data.category");
          String privateGroupprivacy=CGpri.get("data.privacy");
          String privateGroupdescription=CGpri.get("data.description");
          
			
			 
			Assert.assertEquals("SUCCESS",Createprivategroupmessage );
			Assert.assertEquals(privateGroupname,"SpringTech private" );
			Assert.assertEquals(privateGroupcategory ,"social");
			Assert.assertEquals(privateGroupprivacy,"private" );
			Assert.assertEquals(privateGroupdescription,"allsoftware" );

			Reporter.log("Endpoint :/api/v2/group/");
	        Reporter.log("StatusCode :200");
			Reporter.log("User Created public social group sucessfully ");
			
	}
	@Test(priority=2)
	public void  GetGroup() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
        File privategroupimage1=new File("C:\\Users\\CURD Automation\\Downloads\\AutomationTestImage.jpg");


String CreateGroupforget=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)

.headers("Authorization", a.AuthorizationToken).multiPart("name","SpringTechsoftprivate" ).multiPart("category", "social")
.multiPart("privacy","private").multiPart("description","allsoftware").multiPart("interest","sports").multiPart("image",privategroupimage1)
.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();
 
       JsonPath CGg=new JsonPath(CreateGroupforget);

          String getGroupId = CGg.get("data._id");
	
          String Getgroup= given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("groupId", getGroupId)
					.when().get("/api/v2/group/").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(Getgroup);
					 JsonPath CGGet=new JsonPath(Getgroup);

			          String Createprivategroupmessage=CGGet.get("message");
			          String responseGroupId = CGGet.get("data._id");
						Assert.assertEquals(getGroupId,responseGroupId );				
	}
	@Test(priority=3)
	public void  UpdateGroup() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";


String CreateGroupforget= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("name","Siva social" ).multiPart("category", "social")
			.multiPart("privacy","private").multiPart("description","allsoftware").multiPart("interest","sports")
			.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

       JsonPath CGg=new JsonPath(CreateGroupforget);

          String getGroupId = CGg.get("data._id");
	
          String Updategroup= given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail).
		body("{\r\n"
				+ "\"name\":\"Siva  Group\",\r\n"
				+ "\"category\":\"social\",\r\n"
				+ "\"privacy\":\"private\",\r\n"
				+ "\"description\":\"all products\",\r\n"
				+ "\"about\":\"all services\",\r\n"
				+ "\"address\":\"Banglore\",\r\n"
				+ "\"interest\":[\"sports\"],\r\n"
				+ " \"phone\": [{\"phone_number\": 485445856, \"country_code\": \"+1684\", \"is_verified\": \"false\" }],\r\n"
				+ " \"email\":[{\"email\":\"alka@yopmail.com\",\r\n"
				+ "    \"is_verified\":\"false\"}]\r\n"
				+ "}")
					.when().patch("/api/v2/group/?groupId="+getGroupId+"").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(Updategroup);
					 JsonPath CGGet=new JsonPath(Updategroup);

			          String Createprivategroupmessage=CGGet.get("message");
						Assert.assertEquals(Createprivategroupmessage,"SUCCESS");
					
					
	}

	//Request to join group
	@Test(priority=4)
	public void  Addmember() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
		
		String CreateGroupforget= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
				
				.headers("Authorization", a.AuthorizationToken).multiPart("name","Siva socialmedia" ).multiPart("category", "social")
				.multiPart("privacy","private").multiPart("description","allsoftware").multiPart("interest","sports")
				.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

	       JsonPath CGgadd=new JsonPath(CreateGroupforget);

	          String getGroupIdforaddm = CGgadd.get("data._id");
	
String Addmemberinprivategroup= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken)
			.when().post("/api/v2/group/member/?groupId="+getGroupIdforaddm+"&member_id="+a.Memberid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
       JsonPath addmember=new JsonPath(Addmemberinprivategroup);
       String Createprivategroupmessage=addmember.get("message");
       String Memberstatus=addmember.get("data.status");
       String role=addmember.get("data.role");
		Assert.assertEquals(Createprivategroupmessage,"SUCCESS" );
		Assert.assertEquals(Memberstatus,"invited" );
		Assert.assertEquals(role,"member" );
		
	//Retrieve requested members info
		 String Getsentreqinfo= given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("groupId",getGroupIdforaddm )
					.param("skip", "0").param("limit", "5")
					.when().get("/api/v2/group/sent-req").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(Getsentreqinfo);
					 JsonPath getsentinfo=new JsonPath(Getsentreqinfo);

			          String sentreqinfomessage=getsentinfo.get("message");
			          Assert.assertEquals(sentreqinfomessage,"SUCCESS" );			


	//accept group join request
		String Approvegroupjoinrequest= given().log().all().headers("Content-Type","application/json").header("email",a.Referrermail)
				
				.headers("Authorization", a.ReferrarToken)
				.when().post("/api/v2/group/member/approve?groupId="+getGroupIdforaddm+"&member_id="+a.Memberid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
	       JsonPath approvereq=new JsonPath(Approvegroupjoinrequest);
	       String privategroupapprovemessage=approvereq.get("message");
	       String approveMemberstatus=approvereq.get("data.status");
	       String roleafterapprove=approvereq.get("data.role");
			Assert.assertEquals(privategroupapprovemessage,"SUCCESS" );
			Assert.assertEquals(approveMemberstatus,"approved");
			Assert.assertEquals(roleafterapprove,"member" );
	//Delete member
			String Deletemember= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
					
					.headers("Authorization", a.AuthorizationToken)
					.when().delete("/api/v2/group/member/?groupId="+getGroupIdforaddm+"&member_id="+a.Memberid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();	
		       JsonPath Delmember=new JsonPath(Deletemember);
		       String privategroupdelmemmessage=Delmember.get("message");
				Assert.assertEquals(privategroupdelmemmessage,"SUCCESS" );	
	}
	@Test(priority=5)
	public void  Addadmin() throws InterruptedException {
String CreateGroupforget= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
				
				.headers("Authorization", a.AuthorizationToken).multiPart("name","Siva socialmedia" ).multiPart("category", "social")
				.multiPart("privacy","private").multiPart("description","allsoftware").multiPart("interest","sports")
				.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

	       JsonPath CGgadd=new JsonPath(CreateGroupforget);

	          String getGroupIdforaddm = CGgadd.get("data._id");
	
String Addmemberinprivategroup= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken)
			.when().post("/api/v2/group/member/?groupId="+getGroupIdforaddm+"&member_id="+a.Memberid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
       JsonPath addmember=new JsonPath(Addmemberinprivategroup);
       String Createprivategroupmessage=addmember.get("message");
       String Memberstatus=addmember.get("data.status");
       String role=addmember.get("data.role");
		Assert.assertEquals(Createprivategroupmessage,"SUCCESS" );
		Assert.assertEquals(Memberstatus,"invited" );
		Assert.assertEquals(role,"member" );	
		
String Approvegroupjoinrequest= given().log().all().headers("Content-Type","application/json").header("email",a.Referrermail)
				
				.headers("Authorization", a.ReferrarToken)
				.when().post("/api/v2/group/member/approve?groupId="+getGroupIdforaddm+"&member_id="+a.Memberid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
	Thread.sleep(2000) ;   
//Add admin
String Addadmin= given().log().all().headers("Content-Type","application/json").header("email",a.mail)

.headers("Authorization", a.AuthorizationToken)
.when().post("/api/v2/group/admin/?groupId="+getGroupIdforaddm+"&member_id="+a.Memberid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
JsonPath addadminobj=new JsonPath(Addadmin);
String privategroupaddadminmessage=addadminobj.get("message");
String adminstatus=addadminobj.get("data.status");
String addadminrole=addadminobj.get("data.role");
	Assert.assertEquals(privategroupaddadminmessage,"SUCCESS" );
	Assert.assertEquals(adminstatus,"approved" );
	Assert.assertEquals(addadminrole,"admin" );	
	
		//Retrieve admin of the group
	 String Getgroupadmininfo= given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("groupId",getGroupIdforaddm )
				.param("skip", "0").param("limit", "5")
				.when().get("/api/v2/group/admin/").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(Getgroupadmininfo);
				 JsonPath adminin=new JsonPath(Getgroupadmininfo);

		          String admininfomessage=adminin.get("message");
		          Assert.assertEquals(admininfomessage,"SUCCESS" );	
	//manage group
		          String mangegroupdata= given().log().all().headers("Content-Type","application/json")
  						.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("skip", "0").param("limit", "5")
  						.when().get("/api/v2/group/manage-group/?groupId="+getGroupIdforaddm+"").then().assertThat().statusCode(200).extract().response().asString();
  						System.out.println(mangegroupdata);
  						 JsonPath Cmanage=new JsonPath(mangegroupdata);

  				          String privategroupmanagemessage=Cmanage.get("message");
  			    		  	Assert.assertEquals(privategroupmanagemessage,"SUCCESS" );
   //Delete admin
		        //Delete member
				/*	String Deleteadmin= given().log().all().headers("Content-Type","application/json").header("email",a.AuthorizationToken)
							
							.headers("Authorization", a.mail)
							.when().delete("/api/v2/group/admin/?groupId="+getGroupIdforaddm+"&member_id="+a.Memberid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();	
				       JsonPath Deladmin=new JsonPath(Deleteadmin);
				       String privategroupdeladminmessage=Deladmin.get("message");
						Assert.assertEquals(privategroupdeladminmessage,"SUCCESS" );*/		          
	}
//Superadminflow
	@Test(priority=6)
	public void Createsuperadmin() {
	RestAssured.baseURI="http://hcpdev.curd.network:3000";

    File privategroupimage=new File("C:\\Users\\CURD Automation\\Downloads\\AutomationTestImage.jpg");

String CreateprivateGroupsuper= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
		
		.headers("Authorization", a.AuthorizationToken).multiPart("name","Superadminprivate" ).multiPart("category", "social")
		.multiPart("privacy","private").multiPart("description","allsoftware").multiPart("interest","sports").multiPart("image",privategroupimage)
		.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

   JsonPath CGsuper=new JsonPath(CreateprivateGroupsuper);

      String Createprivatesupermessage=CGsuper.get("message");
      String privateGroupIdforsuper = CGsuper.get("data._id");
      //Personal profileid for super admin
      Response getpersonaldetails = given().log().all().headers("Content-Type","application/json")
    			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
    			.when().get("/api/v2/user/profile/");
    	 String PersonalprofileId = getpersonaldetails.then().contentType(ContentType.JSON).extract().path("data._id");
      
      //Add superadmin to group
      String AddSuperadmin= given().log().all().headers("Content-Type","application/json").header("email",a.mail)

    		  .headers("Authorization", a.AuthorizationToken)
    		  .when().post("/api/v2/group/admin/?groupId="+privateGroupIdforsuper+"&member_id="+PersonalprofileId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
    		  JsonPath addsuperadminobj=new JsonPath(AddSuperadmin);
    		  String privategroupaddsupermessage=addsuperadminobj.get("message");
    		  String Superadminstatus=addsuperadminobj.get("data.status");
    		  String addsuperadminrole=addsuperadminobj.get("data.role");
    		  	Assert.assertEquals(privategroupaddsupermessage,"SUCCESS" );
    		  	Assert.assertEquals(Superadminstatus,"approved" );
    		  	Assert.assertEquals(addsuperadminrole,"admin" );
    //Similar group

    	          String similargroup= given().log().all().headers("Content-Type","application/json")
    						.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("skip", "0").param("limit", "5")
    						.when().get("/api/v2/group/similar-groups/groupId="+privateGroupIdforsuper+"").then().assertThat().statusCode(200).extract().response().asString();
    						System.out.println(similargroup);
    						 JsonPath Csimilar=new JsonPath(similargroup);

    				          String privategroupsimilarmessage=Csimilar.get("message");
    			    		  	Assert.assertEquals(privategroupsimilarmessage,"SUCCESS" );

	}
	//Get all groups of User
	@Test
	public void allgroupUsers() {
	String allgroupusers= given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("skip", "0").param("limit", "5")
			.when().get("/api/v2/group/get-all/").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(allgroupusers);
			 JsonPath Callgroupuser=new JsonPath(allgroupusers);

	          String allgroupusermessage=Callgroupuser.get("message");
    		  	Assert.assertEquals(allgroupusermessage,"SUCCESS" );
	
}	
}