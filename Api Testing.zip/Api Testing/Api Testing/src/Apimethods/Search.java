package Apimethods;

import static io.restassured.RestAssured.given;

import org.openqa.selenium.json.Json;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Search {
	AuthorizationToken a=new AuthorizationToken();
@Test(priority=1)
public void Searchall() {
	RestAssured.baseURI="http://hcpdev.curd.network:3000";

	 String searchall=given().log().all().headers("Content-Type","application/json").
			  header("email",a.mail)
			.headers("Authorization", a.AuthorizationToken).param("key","suma")
			.when().get("/api/v2/search/all").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(searchall);
			JsonPath searchallobj=new JsonPath(searchall);
	         String SearchAllMeassage=searchallobj.get("message");
				Assert.assertEquals("SUCCESS",SearchAllMeassage );

	         Reporter.log("/api/v2/search/all");
				Reporter.log("statusCode 200");
				Reporter.log("User retrieve particular data sucessfully");
				
}
@Test(priority=2)
public void Searchpersonal() {
	String SearchPersonal=given().log().all().headers("Content-Type","application/json").
	  header("email",a.mail)
	.headers("Authorization", a.AuthorizationToken).param("key","nanda").param("filter","1")
	.when().get("/api/v2/search/personal").then().log().all().assertThat().statusCode(200).extract().response().asString();
	System.out.println(SearchPersonal);
	JsonPath searchpersonalobj=new JsonPath(SearchPersonal);
   String SearchpersonalMeassage=searchpersonalobj.get("message");
		Assert.assertEquals("SUCCESS",SearchpersonalMeassage );

   Reporter.log("/api/v2/search/personal");
		Reporter.log("statusCode 200");
		Reporter.log("User retrieve particular personal data sucessfully");
	
}
@Test(priority=3)
public void SearchMentions() {
		String Searchmentions=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail)
		.headers("Authorization", a.AuthorizationToken).param("key","Test")
		.when().get("/api/v2/search/mention").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(Searchmentions);
		JsonPath searchmentionobj=new JsonPath(Searchmentions);
	   String SearchMentionMeassage=searchmentionobj.get("message");
			Assert.assertEquals("SUCCESS",SearchMentionMeassage );

	   Reporter.log("/api/v2/search/mention");
			Reporter.log("statusCode 200");
			Reporter.log("User retrieve mentions data sucessfully");
		
}
@Test(priority=4)
public void SearchBusiness() {
		String Searchbusinessapi=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail)
		.headers("Authorization", a.AuthorizationToken).body("{\r\n"
				+ "  \"major_industries\": [\r\n"
				+ "    \"Business Strategy\"\r\n"
				+ "  ],\r\n"
				+ "  \"minor_industries\": [\r\n"
				+ "    \"Electrical Systems Enginerring\"\r\n"
				+ "  ]\r\n"
				+ "}")
		
		.when().post("/api/v2/search/business?key=Test&page=1").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(Searchbusinessapi);
		JsonPath searchbusinessobj=new JsonPath(Searchbusinessapi);
	   String SearchBusinessMeassage=searchbusinessobj.get("message");
			Assert.assertEquals("SUCCESS",SearchBusinessMeassage );

	   Reporter.log("/api/v2/search/business");
			Reporter.log("statusCode 200");
			Reporter.log("User retrieve particular business profile sucessfully");
		
}
@Test(priority=5)
public void Createsearch() {
		String createSearch=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail)
		.headers("Authorization", a.AuthorizationToken).body("{\r\n"
				+ "  \"search\": \"internal\",\r\n"
				+ "  \"type\": \"profile\"\r\n"
				+ "}")
		
		.when().post("/api/v2/search/createSearch").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(createSearch);
		JsonPath createsearchobj=new JsonPath(createSearch);
	   String createsearchMeassage=createsearchobj.get("message");
			Assert.assertEquals("SUCCESS",createsearchMeassage );

	   Reporter.log("/api/v2/search/createSearch");
			Reporter.log("statusCode 200");
		
}
  
@Test(priority=6)
public void recentSearch() {
		String rencentSearch=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail)
		.headers("Authorization", a.AuthorizationToken)
		
		.when().get("/api/v2/search/recentSearch").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(rencentSearch);
		JsonPath recentsearchobj=new JsonPath(rencentSearch);
	   String recentsearchMeassage=recentsearchobj.get("message");
			Assert.assertEquals("SUCCESS",recentsearchMeassage );

	   Reporter.log("/api/v2/search/recentSearch");
			Reporter.log("statusCode 200");
			Reporter.log("User retrieve recent search history sucessfully");
		
}
@Test(priority=7)
public void externalmention() {
		String externalmention=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail)
		.headers("Authorization", a.AuthorizationToken).body("{\r\n"
				+ "  \"phoneBook\": [\r\n"
				+ "    \"+919393935744\",\r\n"
				+ "    \"+919865423875\"\r\n"
				+ "  ],\r\n"
				+ "  \"google\": [\r\n"
				+ "    \"titto@yopmail.com\",\r\n"
				+ "    \"anvesh@lodestone.com\"\r\n"
				+ "  ]\r\n"
				+ "}")
		
		.when().post("/api/v2/search/externalMention").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(externalmention);
		JsonPath exmentionobj=new JsonPath(externalmention);
	   String externalmentionMeassage=exmentionobj.get("message");
			Assert.assertEquals("SUCCESS",externalmentionMeassage );

	   Reporter.log("/api/v2/search/externalMention");
			Reporter.log("statusCode 200");
			Reporter.log("User search external sucessfully");
		
}
@Test(priority=8)
public void lookforbusiness() {
		String lookforBuyer=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail).param("skip", "0").param("limit","5")
		.headers("Authorization", a.AuthorizationToken).body("{\r\n"
				+ "  \"type\": \"buyer\"\r\n"
				+ "}")
		
		.when().post("/api/v2/search/look-for-business").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(lookforBuyer);
		JsonPath lookfor=new JsonPath(lookforBuyer);
	   String lookforMeassage=lookfor.get("message");
			Assert.assertEquals("SUCCESS",lookforMeassage );

	   Reporter.log("/api/v2/search/look-for-business");
			Reporter.log("statusCode 200");
			Reporter.log("User search lookforbuyer sucessfully"); 
}
@Test(priority=9)
public void lookforbusinessseller() {
		String lookforseller=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail).param("skip", "0").param("limit", "5")
		.headers("Authorization", a.AuthorizationToken).body("{\r\n"
				+ "  \"type\": \"seller\"\r\n"
				+ "}")
		
		.when().post("/api/v2/search/look-for-business").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(lookforseller);
		JsonPath lookforsell=new JsonPath(lookforseller);
	   String lookforsellerMeassage=lookforsell.get("message");
			Assert.assertEquals("SUCCESS",lookforsellerMeassage );

	   Reporter.log("/api/v2/search/look-for-business");
			Reporter.log("statusCode 200");
			Reporter.log("User search lookforseller sucessfully"); 
}
@Test(priority=9)
public void personalconnection() {
		String Getpersonalconnection=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail).param("skip", "0").param("limit", "5").param("key", "alka")
		.headers("Authorization", a.AuthorizationToken)
		.when().post("/api/v2/search/personal-connection").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(Getpersonalconnection);
		JsonPath Pconnection=new JsonPath(Getpersonalconnection);
	   String pconnectionMeassage=Pconnection.get("message");
			Assert.assertEquals("SUCCESS",pconnectionMeassage );

	   Reporter.log("/api/v2/search/personal-connection");
			Reporter.log("statusCode 200");
			Reporter.log("User searched personal connection sucessfully"); 
}
@Test(priority=10)
public void personalfollower() {
		String Getpersonalfollower=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail).param("skip", "0").param("limit", "5").param("key", "alka")
		.headers("Authorization", a.AuthorizationToken)
		.when().post("/api/v2/search/personal-follower").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(Getpersonalfollower);
		JsonPath Pfollower=new JsonPath(Getpersonalfollower);
	   String pfollowerMeassage=Pfollower.get("message");
			Assert.assertEquals("SUCCESS",pfollowerMeassage );

	   Reporter.log("/api/v2/search/personal-follower");
			Reporter.log("statusCode 200");
			Reporter.log("User searched personal connection sucessfully"); 
}
@Test(priority=11)
public void personalfollowing() {
		String Getpersonalfollowing=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail).param("skip", "0").param("limit", "5").param("key", "alka")
		.headers("Authorization", a.AuthorizationToken)
		.when().post("/api/v2/search/personal-following").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(Getpersonalfollowing);
		JsonPath Pfollowing=new JsonPath(Getpersonalfollowing);
	   String pfollowingMeassage=Pfollowing.get("message");
			Assert.assertEquals("SUCCESS",pfollowingMeassage );

	   Reporter.log("/api/v2/search/personal-following");
			Reporter.log("statusCode 200");
			Reporter.log("User searched personal following list sucessfully"); 
}
@Test(priority=12)
public void Businessreview() {
		String BusinessReview=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail).param("skip", "0").param("limit", "5").param("key", "alka")
		.headers("Authorization", a.AuthorizationToken)
		.when().post("/api/v2/search/business-reviewed").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(BusinessReview);
		JsonPath BusinessReviewd=new JsonPath(BusinessReview);
	   String pfollowingMeassage=BusinessReviewd.get("message");
			Assert.assertEquals("SUCCESS",pfollowingMeassage );

	   Reporter.log("/api/v2/search/business-reviewed");
			Reporter.log("statusCode 200");
			Reporter.log("User retrieve reviewed business sucessfully"); 
}
@Test(priority=13)
public void Businessfollowing() {
		String Businessfollowing=given().log().all().headers("Content-Type","application/json").
		  header("email",a.mail).param("skip", "0").param("limit", "5").param("key", "Eco")
		.headers("Authorization", a.AuthorizationToken)
		.when().post("/api/v2/search/business-following").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(Businessfollowing);
		JsonPath Busfollowing=new JsonPath(Businessfollowing);
	   String pfollowingMeassage=Busfollowing.get("message");
			Assert.assertEquals("SUCCESS",pfollowingMeassage );
	   Reporter.log("/api/v2/search/business-following");
			Reporter.log("statusCode 200");
			Reporter.log("User retrieve following business sucessfully"); 
}
}
