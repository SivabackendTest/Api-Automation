package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;


public class Billing {
	AuthorizationToken a=new AuthorizationToken();
	Personal BP=new Personal();
	Businessprofile BBP=new Businessprofile();
public String CretedBillingid;
	@Test(priority=1)
	public void CreateBilling(){
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

	Response Createwalletbilling= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
			.body("{\r\n"
					+ "  \"createdBy\": {\r\n"
					+ "    \"ref_id\": \""+BP.PersonalprofileId+"\",\r\n"
					+ "    \"ref_model\": \"personal_profile\"\r\n"
					+ "  },\r\n"
					+ "  \"billingName\": \"alka\",\r\n"
					+ "  \"isDefault\": \"true\",\r\n"
					+ "  \"type\": \"company\",\r\n"
					+ "  \"businessId\": \""+BBP.BusinessProfileId+"\",\r\n"
					+ "  \"address\": {\r\n"
					+ "    \"line1\": \"hsr layout\",\r\n"
					+ "    \"line2\": \"bangalore\"\r\n"
					+ "  },\r\n"
					+ "  \"city\": \"bangalore\",\r\n"
					+ "  \"country\": \"India\",\r\n"
					+ "  \"pincode\": \"560017\",\r\n"
					+ "  \"pan\": \"EQEPBKSHK\"\r\n"
					+ " \r\n"
					+ "}")
			.headers("Authorization", a.AuthorizationToken)
			.when().post("/api/v2/billing/create");
			 String CretedBillingid = Createwalletbilling.then().contentType(ContentType.JSON).extract().path("data._id");
System.out.println(CretedBillingid);
			 String CreatedBillingmessage = Createwalletbilling.then().contentType(ContentType.JSON).extract().path("message");

			Assert.assertEquals("SUCCESS",CreatedBillingmessage );
			
			Reporter.log("Endpoint :/api/v2/billing/create");
	        Reporter.log("StatusCode :200");
			Reporter.log("User Created Billing Address Sucessfully");
}
	@Test(priority=2)
	public void SearchBilling(){
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

	Response Searchwalletbilling= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken)
			.when().post("/api/v2/billing/search");

			 String SearchBillingmessage = Searchwalletbilling.then().contentType(ContentType.JSON).extract().path("message");

			Assert.assertEquals("SUCCESS",SearchBillingmessage );
			
			Reporter.log("Endpoint :/api/v2/billing/search");
	        Reporter.log("StatusCode :200");
			Reporter.log("User Retrieve Billing Address Sucessfully");
}
	@Test(priority=3)
	public void UpdateBilling(){
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
		Response Createwalletbilling1= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
				.body("{\r\n"
						+ "  \"createdBy\": {\r\n"
						+ "    \"ref_id\": \""+BP.PersonalprofileId+"\",\r\n"
						+ "    \"ref_model\": \"personal_profile\"\r\n"
						+ "  },\r\n"
						+ "  \"billingName\": \"alka\",\r\n"
						+ "  \"isDefault\": \"true\",\r\n"
						+ "  \"type\": \"company\",\r\n"
						+ "  \"businessId\": \""+BBP.BusinessProfileId+"\",\r\n"
						+ "  \"address\": {\r\n"
						+ "    \"line1\": \"hsr layout\",\r\n"
						+ "    \"line2\": \"bangalore\"\r\n"
						+ "  },\r\n"
						+ "  \"city\": \"bangalore\",\r\n"
						+ "  \"country\": \"India\",\r\n"
						+ "  \"pincode\": \"560017\",\r\n"
						+ "  \"pan\": \"EQEPBKSHK\"\r\n"
						+ " \r\n"
						+ "}")
				.headers("Authorization", a.AuthorizationToken)
				.when().post("/api/v2/billing/create");
				 String CretedBillingid1 = Createwalletbilling1.then().contentType(ContentType.JSON).extract().path("data._id");
	System.out.println(CretedBillingid1);

	Response Updatewalletbilling= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).body("{\r\n"
					+ "  \"billingName\": \"ABBA\",\r\n"
					+ "  \"isDefault\": \"true\",\r\n"
					+ "  \"address\": {\r\n"
					+ "    \"line1\": \"hsr layout\",\r\n"
					+ "    \"line2\": \"bangalore\"\r\n"
					+ "  },\r\n"
					+ "  \"city\": \"vijayawada\",\r\n"
					+ "  \"country\": \"India\",\r\n"
					+ "  \"pincode\": \"560018\",\r\n"
					+ "  \"pan\": \"EQEPBKSHK\",\r\n"
					+ "  \"trn\": \"KSNFHKHKJ\"\r\n"
					+ "}")
			.when().put("/api/v2/billing/update?id="+CretedBillingid1+"");

			 String UpdateBillingmessage = Updatewalletbilling.then().contentType(ContentType.JSON).extract().path("message");
			 String UpdateBillingName = Updatewalletbilling.then().contentType(ContentType.JSON).extract().path("data.billingName");
			 String UpdateBillingline1= Updatewalletbilling.then().contentType(ContentType.JSON).extract().path("data.address.line1");
			 String UpdateBillingline2= Updatewalletbilling.then().contentType(ContentType.JSON).extract().path("data.address.line2");
			 String UpdateBillingCity= Updatewalletbilling.then().contentType(ContentType.JSON).extract().path("data.city");
			 String UpdateBillingcountry= Updatewalletbilling.then().contentType(ContentType.JSON).extract().path("data.country");
			 String UpdateBillingpincode= Updatewalletbilling.then().contentType(ContentType.JSON).extract().path("data.pincode");

			 
			Assert.assertEquals("SUCCESS",UpdateBillingmessage );
			Assert.assertEquals("ABBA",UpdateBillingName );
			Assert.assertEquals("hsr layout",UpdateBillingline1 );
			Assert.assertEquals("bangalore",UpdateBillingline2 );
			Assert.assertEquals("vijayawada",UpdateBillingCity );
			Assert.assertEquals("India",UpdateBillingcountry );
			Assert.assertEquals("560018",UpdateBillingpincode );

			Reporter.log("Endpoint :/api/v2/billing/update");
	        Reporter.log("StatusCode :200");
			Reporter.log("User Update Billing Address Sucessfully");
}
	@Test(priority=4)
	
	public void DeleteBilling(){
		Response Createwalletbilling2= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
				.body("{\r\n"
						+ "  \"createdBy\": {\r\n"
						+ "    \"ref_id\": \""+BP.PersonalprofileId+"\",\r\n"
						+ "    \"ref_model\": \"personal_profile\"\r\n"
						+ "  },\r\n"
						+ "  \"billingName\": \"alka\",\r\n"
						+ "  \"isDefault\": \"true\",\r\n"
						+ "  \"type\": \"company\",\r\n"
						+ "  \"businessId\": \""+BBP.BusinessProfileId+"\",\r\n"
						+ "  \"address\": {\r\n"
						+ "    \"line1\": \"hsr layout\",\r\n"
						+ "    \"line2\": \"bangalore\"\r\n"
						+ "  },\r\n"
						+ "  \"city\": \"bangalore\",\r\n"
						+ "  \"country\": \"India\",\r\n"
						+ "  \"pincode\": \"560017\",\r\n"
						+ "  \"pan\": \"EQEPBKSHK\"\r\n"
						+ " \r\n"
						+ "}")
				.headers("Authorization", a.AuthorizationToken)
				.when().post("/api/v2/billing/create");
				 String CretedBillingid2 = Createwalletbilling2.then().contentType(ContentType.JSON).extract().path("data._id");
	System.out.println(CretedBillingid2);
		String deleteBilling = given().log().all().headers("Content-Type","application/json").param("id",CretedBillingid2 )
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().delete("/api/v2/billing/delete").then().log().all().assertThat().statusCode(200).extract().response().asString();
				System.out.println(deleteBilling);
				JsonPath Bdele=new JsonPath(deleteBilling);
				String Billingaddressdelete=Bdele.get("message");
				Assert.assertEquals("SUCCESS",Billingaddressdelete );

				
				Reporter.log("Endpoint :/api/v2/billing/delete");
		        Reporter.log("StatusCode :200");
				Reporter.log("Sucessfully deleted business account");
	}
}
