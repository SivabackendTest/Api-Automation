package Apimethods;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Reusablemethods extends AuthorizationToken {
	public String Postsignup;

	public void singup(String mail,String localid) {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
		String Requestbody = given().header("Content-Type","application/json")
				.body(Payload.postsignup(mail,localid )).toString();
		Reporter.log(Requestbody);
		String Postsignup=given().log().all().header("Content-Type","application/json")
	.body(Payload.postsignup(mail, localid))
		.when().post("/api/v2/auth/post-signup").then().log().all().assertThat().statusCode(200).extract().asString();
		System.out.println(Postsignup);
		Reporter.log(Postsignup);
		JsonPath b=new JsonPath(Postsignup);
		String path="statusCode";
		String statuscodemess=b.getString(path); 
		System.out.println(statuscodemess);
		String actual="403";
		Assert.assertEquals(actual, statuscodemess);
		
	}
	public void withoutemail(String mail,String localid) {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
		String Requestbody = given().header("Content-Type","application/json")
				.body(Payload.postsignup(mail,localid )).toString();
		Reporter.log(Requestbody);
		String Postsignupwithoutbody=given().log().all().header("Content-Type","application/json")
	.body(Payload.postsignup(mail, localid))
		.when().post("/api/v2/auth/post-signup").then().log().all().assertThat().statusCode(200).extract().asString();
		System.out.println(Postsignupwithoutbody);
		Reporter.log(Postsignupwithoutbody);
		JsonPath withoutmail=new JsonPath(Postsignupwithoutbody);
		String empaty="statusCode";
		String statusofempty=withoutmail.getString(empaty); 
		System.out.println(statusofempty);
		String actualofEmptymail="400";
		Assert.assertEquals(actualofEmptymail, statusofempty);
		
	}
	AuthorizationToken a=new AuthorizationToken();
	public void signin(String Email,String localid) {
		String Signin = given().log().all().header("Content-Type","application/json").headers("Authorization", a.AuthorizationToken)
				.body("{\r\n"
						+ "  \"email\": \""+Email+"\",\r\n"
						+ "  \"uid\": \""+localid+"\",\r\n"
						+ "  \"device\": {\r\n"
						+ "    \"token\": \"deL5_IVSR5Sskgu40DvT3l:APA91bEvwltlTHUybBeWqzOkN1c7jr24fibJDPcY_E-HMRSOThqDzeyElo--8szEQ1NEbVOciE25IO4x8fk6skvhYFicng8IE4hHmB81bp3mrNFCY2RPfwSOo3IIlnHlbkzDP451ScDt\",\r\n"
						+ "    \"os_sdk\": \"34\",\r\n"
						+ "    \"os_version\": \"14\",\r\n"
						+ "    \"isPhysicalDevice\": \"true\",\r\n"
						+ "    \"ip\": \"124.23.24.174\",\r\n"
						+ "    \"os_type\": \"Android\",\r\n"
						+ "    \"app_version\": \"1.10.3\"\r\n"
						+ "  }\r\n"
						+ "}\r\n"
						+ "").when().post("/api/v2/auth/post-signin").then().log().all().assertThat().statusCode(200).extract().asString();
		System.out.println(Signin);
		Reporter.log(Signin);
		JsonPath Signinneg=new JsonPath(Signin);
		String signinreg="statusCode";
		String statusregisteredmail=Signinneg.getString(signinreg); 
		System.out.println(statusregisteredmail);
		String actualofregistedmail="400";
		Assert.assertEquals(actualofregistedmail, statusregisteredmail);
		
	}
	public void signinwithwrongid(String Email,String localid) {
		String Signin = given().log().all().header("Content-Type","application/json").headers("Authorization", a.AuthorizationToken)
				.body("{\r\n"
						+ "  \"email\": \""+Email+"\",\r\n"
						+ "  \"uid\": \""+localid+"\",\r\n"
						+ "  \"device\": {\r\n"
						+ "    \"token\": \"deL5_IVSR5Sskgu40DvT3l:APA91bEvwltlTHUybBeWqzOkN1c7jr24fibJDPcY_E-HMRSOThqDzeyElo--8szEQ1NEbVOciE25IO4x8fk6skvhYFicng8IE4hHmB81bp3mrNFCY2RPfwSOo3IIlnHlbkzDP451ScDt\",\r\n"
						+ "    \"os_sdk\": \"34\",\r\n"
						+ "    \"os_version\": \"14\",\r\n"
						+ "    \"isPhysicalDevice\": \"true\",\r\n"
						+ "    \"ip\": \"124.23.24.174\",\r\n"
						+ "    \"os_type\": \"Android\",\r\n"
						+ "    \"app_version\": \"1.10.3\"\r\n"
						+ "  }\r\n"
						+ "}\r\n"
						+ "").when().post("/api/v2/auth/post-signin").then().log().all().assertThat().statusCode(200).extract().asString();
		System.out.println(Signin);
		Reporter.log(Signin);
		JsonPath Signinneg=new JsonPath(Signin);
		String signinreg="statusCode";
		String statusregisteredmail=Signinneg.getString(signinreg); 
		System.out.println(statusregisteredmail);
		String actualofregistedmail="404";
		Assert.assertEquals(actualofregistedmail, statusregisteredmail);
	}
	public void SendOtp(String Email) {
		String sendotpresponse = given().log().all().headers("Content-Type","application/json").headers("Authorization", a.AuthorizationToken)
		.body("{\r\n"
				+ "    \"email\":\""+Email+"\"\r\n"
				+ "}")
		.when().post("api/v2/auth/verify-email").then().assertThat().
		statusCode(200).extract().response().asString();
		Reporter.log(sendotpresponse);
	JsonPath js=new JsonPath(sendotpresponse);
	String Sendotp="statusCode";
	String Otpcode=js.getString(Sendotp); 
	System.out.println(Otpcode);
	String actualofregistedmail="400";
	Assert.assertEquals(actualofregistedmail, Otpcode);
}
	public void VerifyOtp(String Email,String otp,String postcode) {
		String VerifyOtp = given().log().all().headers("Content-Type","application/json").headers("Authorization", a.AuthorizationToken)
		.body("{\r\n"
				+ "    \"email\": \""+Email+"\",\r\n"
				+ "    \"otp\": \""+otp+"\",\r\n"
				+ "    \"code\": \""+postcode+"\"\r\n"
				+ "}")
		.when().post("api/v2/auth/confirm-email").then().log().all().assertThat().statusCode(200).extract().response().asString();
		Reporter.log("Verification Successful");
		
		JsonPath js=new JsonPath(VerifyOtp);
		String verifyOtp="statusCode";
		String Otp=js.getString(verifyOtp); 
		System.out.println(Otp);
		String actualofregistedmail="400";
		Assert.assertEquals(actualofregistedmail, Otp);
		
		
	}
	public void validcodeotp(String Email,String otp) {
		String sendotpresponse = given().log().all().headers("Content-Type","application/json").headers("Authorization", a.AuthorizationToken)
				.body("{\r\n"
						+ "    \"email\":\""+Email+"\"\r\n"
						+ "}")
				.when().post("api/v2/auth/verify-email").then().assertThat().
				statusCode(200).extract().response().asString();
				Reporter.log(sendotpresponse);
			JsonPath js=new JsonPath(sendotpresponse);
			String path2="data.code";
				String postcode=js.getString(path2);
				System.out.println("code"+postcode);
				String otpwithcode = given().log().all().headers("Content-Type","application/json").headers("Authorization", a.AuthorizationToken)
				.body("{\r\n"
						+ "    \"email\": \""+Email+"\",\r\n"
						+ "    \"otp\": \""+otp+"\",\r\n"
						+ "    \"code\": \""+postcode+"\"\r\n"
						+ "}")
				.when().post("api/v2/auth/confirm-email").then().log().all().assertThat().statusCode(200).extract().response().asString();
				
				JsonPath verify=new JsonPath(otpwithcode);
				String validatewithcode="statusCode";
				String Otpvalidateres=verify.getString(validatewithcode); 
				System.out.println(Otpvalidateres);
				String actualofregistedmail="400";
				Assert.assertEquals(actualofregistedmail, Otpvalidateres);
	}
	public void invalidotp(String Email,String otp) {
		String sendinvalidotpresponse = given().log().all().headers("Content-Type","application/json").headers("Authorization", a.AuthorizationToken)
				.body("{\r\n"
						+ "    \"email\":\""+Email+"\"\r\n"
						+ "}")
				.when().post("api/v2/auth/verify-email").then().assertThat().
				statusCode(200).extract().response().asString();
				Reporter.log(sendinvalidotpresponse);
			JsonPath invalid=new JsonPath(sendinvalidotpresponse);
			String path3="data.code";
				String postcode=invalid.getString(path3);
				System.out.println("code"+postcode);
				String otpwithcode = given().log().all().headers("Content-Type","application/json").headers("Authorization", a.AuthorizationToken)
				.body("{\r\n"
						+ "    \"email\": \""+Email+"\",\r\n"
						+ "    \"otp\": \""+otp+"\",\r\n"
						+ "    \"code\": \""+postcode+"\"\r\n"
						+ "}")
				.when().post("api/v2/auth/confirm-email").then().log().all().assertThat().statusCode(200).extract().response().asString();
				
				JsonPath verifyotpwithinvalid=new JsonPath(otpwithcode);
				String invalidotp="statusCode";
				String Otpinvalidateres=verifyotpwithinvalid.getString(invalidotp); 
				System.out.println(Otpinvalidateres);
				String actualofregistedmail="401";
				Assert.assertEquals(actualofregistedmail, Otpinvalidateres);
	}
	public void emptysetpassword(String Email,String Password) {
		String Setpassword = given().log().all().header("Content-Type","application/json")
		.body("{\r\n"
				+ "  \"email\": \""+Email+"\",\r\n"
				+ "  \"password\": \""+Password+"\"\r\n"
				+ "}")
			.when().post("api/v2/auth/reset-password").then().log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath password=new JsonPath(Setpassword);
		String passcode="statusCode";
		String Code=password.getString(passcode); 
		System.out.println(Code);
		String actualresponsepassword="400";
		Assert.assertEquals(actualresponsepassword, Code);
	}
	public void setpasswordnonexistingUser(String Email,String Password) {
		String Setpasswordnotreg = given().log().all().header("Content-Type","application/json")
		.body("{\r\n"
				+ "  \"email\": \""+Email+"\",\r\n"
				+ "  \"password\": \""+Password+"\"\r\n"
				+ "}")
			.when().post("api/v2/auth/reset-password").then().log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath password=new JsonPath(Setpasswordnotreg);
		String passcodenon="statusCode";
		String Codenonexist=password.getString(passcodenon); 
		System.out.println(Codenonexist);
		String actualresponsepassword="404";
		Assert.assertEquals(actualresponsepassword, Codenonexist);
	}
	public void ExistingEmail(String Email) {
		String ExistingMail = given().log().all().header("Content-Type","application/json")
		.body("{\r\n"
				+ "    \"email\":\""+Email+"\"\r\n"
				+ "}")
			.when().post("/api/v2/auth/email-exist").then().log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath Em=new JsonPath(ExistingMail);
		String Emcode="statusCode";
		String existMail=Em.getString(Emcode); 
		System.out.println(existMail);
		String actualExixtingmailcode="400";
		Assert.assertEquals(actualExixtingmailcode, existMail);
	}
	public void ExistingEmailnonexistinguser(String Email) {
		String ExistingMailnotreg = given().log().all().header("Content-Type","application/json")
		.body("{\r\n"
				+ "    \"email\":\""+Email+"\"\r\n"
				+ "}")
			.when().post("/api/v2/auth/email-exist").then().log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath Em=new JsonPath(ExistingMailnotreg);
		String Emnonuser="data.message";
		String Message=Em.getString(Emnonuser); 
		System.out.println(Message);
		String actualExixtmessage="Email not found. Sign up to create a new account";
		Assert.assertEquals(actualExixtmessage, Message);
	}
	public void Createprofile(String name,String Username,String designation) {
		String CreatePersonalprofilewithnull = given().log().all().headers("Content-Type","multipart/form-data").multiPart("name",name)
				.multiPart("userName",Username).multiPart("designation",designation)
				.headers("Authorization", a.AuthorizationToken)
				.when().post("api/v2/user/profile").then().log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath p =new JsonPath(CreatePersonalprofilewithnull);
		String persoanlcode="statusCode";
		String codeofpersonal=p.getString(persoanlcode); 
		System.out.println(codeofpersonal);
		String actualpcode="400";
		Assert.assertEquals(actualpcode, codeofpersonal);
	}
	
	public void Createprofilewithimage(String name,String Username,String designation,String image) {
		String CreatePersonalprofilewithimage = given().log().all().headers("Content-Type","multipart/form-data").multiPart("name",name)
				.multiPart("userName",Username).multiPart("designation","Analyst").multiPart("image",new File(image))
				.headers("Authorization", a.AuthorizationToken)
				.when().post("api/v2/user/profile").then().log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath pimg =new JsonPath(CreatePersonalprofilewithimage);
		String persoanlimgcode="statusCode";
		String codeofpersonalimg=pimg.getString(persoanlimgcode); 
		System.out.println(codeofpersonalimg);
		String actualpimagcode="400";
		Assert.assertEquals(actualpimagcode, codeofpersonalimg);
	}
	public void UpdateProfile(String Type,String Name,String Phone,String Gender) {
		 String updatepersonalprofilenegative = given().log().all().headers("Content-Type","application/json")
					.body("{\r\n"
							+ "    \"type\": \""+Type+"\",\r\n"
							+ "    \"name\": \""+Name+"\",\r\n"
							+ "    \"phone\": \""+Phone+"\",\r\n"
							+ "    \"gender\": \""+Gender+"\"\r\n"
							+ "}")
					.headers("Authorization", a.AuthorizationToken)
					.when().patch("/api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
		 
		 
	}
	
	
	
	
	
	
	
	
	
}


