package Apimethods;

import org.testng.Reporter;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;

public class General {
	AuthorizationToken a=new AuthorizationToken();

 
	/*@Test(priority=1)
	public void generalapi() {


	RestAssured.baseURI="http://hcpdev.curd.network:3000";
		  String PostInterest=given().log().all().headers("Content-Type","application/json").header("email",a.mail).param("type","SI").param("name",a.addRequest)
					.headers("Authorization", a.AuthorizationToken)
.when().post("api/v2/req-interest").then().assertThat().statusCode(200).extract().response().asString();
		  System.out.println(PostInterest);
		  Reporter.log("Endpoint :api/v2/req-interest");
	        Reporter.log("StatusCode :200"); 
		Reporter.log("Interest Requested sucessfully");
		  
		  
	}*/
	//Get personal interests
	@Test(priority=2)
	public void getpersonalinterest() {

	given().log().all().headers("Content-Type","application/json").header("email",a.mail)
	.headers("Authorization", a.AuthorizationToken)
.when().get("api/v2/personal-interests").then().log().all().assertThat().statusCode(200).extract().response().asString();
	Reporter.log("Endpoint :api/v2/personal-interests");
    Reporter.log("StatusCode :200");
Reporter.log("personal Interest retrieve sucessfully");
	}
	//get professional interest
	
	@Test(priority=3)
	public void getprofessionalinterest() {

	given().log().all().headers("Content-Type","application/json").header("email",a.mail)
	.headers("Authorization", a.AuthorizationToken)
.when().get("api/v2/professional-interests").then().log().all().assertThat().statusCode(200).extract().response().asString();	
	Reporter.log("Endpoint :api/v2/professional-interests");
    Reporter.log("StatusCode :200");
Reporter.log("professional Interest retrieve sucessfully");	
}
	@Test(priority=4)
	public void newpersonalint() {
		given().log().all().headers("Content-Type","application/json").header("email",a.mail)
		.headers("Authorization", a.AuthorizationToken)
	.when().get("/api/v2/new-personal-interests").then().log().all().assertThat().statusCode(200).extract().response().asString();
		Reporter.log("Endpoint :/api/v2/new-personal-interests");
	    Reporter.log("StatusCode :200");
	Reporter.log("new personal Interest retrieve sucessfully");	
	}
	@Test(priority=5)
	public void newprofessionalint() {
		given().log().all().headers("Content-Type","application/json").header("email",a.mail)
		.headers("Authorization", a.AuthorizationToken)
	.when().get("api/v2/professional-interests").then().log().all().assertThat().statusCode(200).extract().response().asString();	
		Reporter.log("Endpoint :/api/v2/new-professional-interests");
	    Reporter.log("StatusCode :200");
	Reporter.log("professional Interest retrieve sucessfully");		
	}
	
}
