package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Influencer {
	AuthorizationToken a=new AuthorizationToken();
	
	@Test(priority=1)
	public void CreateInfluencer() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

		String personalinflu = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
				.headers("Authorization", a.AuthorizationToken)
				.body("{\r\n"
						+ "  \"category\": [\r\n"
						+ "    \"Bars\"\r\n"
						+ "  ],\r\n"
						+ "  \"link\": {\r\n"
						+ "    \"x\": \"www.twitterlink.com\",\r\n"
						+ "    \"fb\": \"www.fblink.com\",\r\n"
						+ "    \"ig\": \"www.intragramlink.com\",\r\n"
						+ "    \"ln\": \"www.linkedinlink.com\",\r\n"
						+ "    \"custom1\": \"www.customlink.com\"\r\n"
						+ "  },\r\n"
						+ "  \"comment\": \"product make you want to share it with everyone around you. Just one bite is all it takes!\"\r\n"
						+ "}")

				.when().post("api/v2/influencer/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
				System.out.println(personalinflu);
				
				JsonPath Jinf=new JsonPath(personalinflu);
				String Influencermessage=Jinf.get("message");
				 String Influenceridforuse = Jinf.get("data._id");
System.out.println(Influenceridforuse);
				Assert.assertEquals("SUCCESS",Influencermessage );
				
				Reporter.log("Endpoint :/api/v2/influencer/create");
		        Reporter.log("StatusCode :200");
				Reporter.log("User Created Influncer sucessfully");
				
				
//update
				String updateinfluncer= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
						.headers("Authorization", a.AuthorizationToken).body("{\r\n"
								+ "  \"category\": [\r\n"
								+ "    \"cooking\"\r\n"
								+ "  ],\r\n"
								+ "  \"link\": {\r\n"
								+ "    \"x\": \"www.twitterlink.com\",\r\n"
								+ "    \"fb\": \"www.fblink.com\",\r\n"
								+ "    \"ig\": \"www.intragramlink.com\",\r\n"
								+ "    \"ln\": \"www.linkedinlink.com\",\r\n"
								+ "    \"custom1\": \"www.customlink.com\"\r\n"
								+ "  },\r\n"
								+ "  \"comment\": \"product make you want to share it with everyone around you. Just one bite is all it takes!\",\r\n"
								+ "  \"isVerified\": \"false\",\r\n"
								+ "  \"status\": \"REJECTED\"\r\n"
								+ "}")
					
						.when().put("/api/v2/influencer/update?id="+Influenceridforuse+"").then().assertThat().statusCode(200).extract().response().asString();
						System.out.println(updateinfluncer);

						JsonPath Patchinflu=new JsonPath(updateinfluncer);
						String updateinfluencermessage=Patchinflu.get("message");
						Assert.assertEquals("SUCCESS",updateinfluencermessage );

						Reporter.log("Endpoint :/api/v2/influencer/update");
						Reporter.log("StatusCode :200");
						Reporter.log("profile influencer details update sucessfully");
// Delete influencer
						String deleteinflu = given().log().all().headers("Content-Type","application/json")
								.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
								.when().delete("/api/v2/influencer/delete?id="+Influenceridforuse+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
								System.out.println(deleteinflu);
								JsonPath jd=new JsonPath(deleteinflu);
								String infludelete=jd.get("message");
								Assert.assertEquals("SUCCESS",infludelete );


								Reporter.log("Endpoint :/api/v2/influencer/delete");
								Reporter.log("StatusCode :200");
								Reporter.log("Sucessfully deleted Influence details");
				
	}
	@Test(priority=2)
	public void Getinfluencer() {
		
			String getinfluencer = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("/api/v2/influencer/get").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getinfluencer);
					
					JsonPath js9=new JsonPath(getinfluencer);
					
									String GetinfluencerMessage=js9.get("message");
									System.out.println("businessgetapi message"+GetinfluencerMessage);
									Assert.assertEquals("SUCCESS",GetinfluencerMessage );

					Reporter.log("Endpoint :/api/v2/influencer/get");
			        Reporter.log("StatusCode :200");
						Reporter.log("User Retrieve Influencer sucessful");}
	


//@Test(priority=3)
//public void UpdateInfluence() {
//	String createInfuencerforupdate = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
//			.body("{\r\n"
//					+ "  \"category\": [\r\n"
//					+ "    \"Acting\"\r\n"
//					+ "  ],\r\n"
//					+ "  \"link\": {\r\n"
//					+ "    \"x\": \"www.twitterlink.com\",\r\n"
//					+ "    \"fb\": \"www.fblink.com\",\r\n"
//					+ "    \"ig\": \"www.intragramlink.com\",\r\n"
//					+ "    \"ln\": \"www.linkedinlink.com\",\r\n"
//					+ "    \"custom1\": \"www.customlink.com\"\r\n"
//					+ "  },\r\n"
//					+ "  \"comment\": \"product make you want to share it with everyone around you. Just one bite is all it takes!\"\r\n"
//					+ "}")
//			.headers("Authorization", a.AuthorizationToken)
//			.when().post("api/v2/influencer/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
//	JsonPath upflu=new JsonPath(createInfuencerforupdate);
//	String updateinfluencer=upflu.get("message");
// String Influenceridupdate = upflu.get("data._id");
// System.out.println(Influenceridupdate);
//	
//String updateinfluncer= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
//.body("{\r\n"
//		+ "  \"category\": [\r\n"
//		+ "    \"Acting\"\r\n"
//		+ "  ],\r\n"
//		+ "  \"link\": {\r\n"
//		+ "    \"x\": \"www.twitter.com\",\r\n"
////		+ "    \"fb\": \"www.fblink.com\",\r\n"
////		+ "    \"ig\": \"www.intragramlink.com\",\r\n"
////		+ "    \"ln\": \"www.linkedinlink.com\",\r\n"
////		+ "    \"custom1\": \"www.customlink.com\"\r\n"
////		+ "  },\r\n"
////		+ "  \"comment\": \"product make you want to share it with everyone around you. Just one bite is all it takes!\",\r\n"
//		+ "  \"isVerified\": \"false\",\r\n"
//		+ "  \"status\": \"PENDING\"\r\n"
//		+ "}")
//.headers("Authorization", a.AuthorizationToken)
//.when().put("/api/v2/influencer/update?id="+Influenceridupdate+"").then().assertThat().statusCode(200).extract().response().asString();
//System.out.println(updateinfluncer);
//
//JsonPath Patchinflu=new JsonPath(updateinfluncer);
//String updateinfluencermessage=Patchinflu.get("message");
//Assert.assertEquals("SUCCESS",updateinfluencermessage );
//
//Reporter.log("Endpoint :/api/v2/influencer/update");
//Reporter.log("StatusCode :200");
//Reporter.log("profile influencer details update sucessfully");
//}
//@Test(priority=4)
//public void DeleteInfluence() {
//	
//	String CreateInfuencerfordelete = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
//			.body("{\r\n"
//					+ "  \"category\": [\r\n"
//					+ "    \"Bars\"\r\n"
//					+ "  ],\r\n"
//					+ "  \"link\": {\r\n"
//					+ "    \"x\": \"www.twitterlink.com\",\r\n"
//					+ "    \"fb\": \"www.fblink.com\",\r\n"
//					+ "    \"ig\": \"www.intragramlink.com\",\r\n"
//					+ "    \"ln\": \"www.linkedinlink.com\",\r\n"
//					+ "    \"custom1\": \"www.customlink.com\"\r\n"
//					+ "  },\r\n"
//					+ "  \"comment\": \"product make you want to share it with everyone around you. Just one bite is all it takes!\"\r\n"
//					+ "}")
//			.headers("Authorization", a.AuthorizationToken)
//			.when().post("api/v2/influencer/create").then().assertThat().statusCode(200).extract().response().asString();
//	JsonPath upflu=new JsonPath(CreateInfuencerfordelete);
//	String updateinfluencer=upflu.get("message");
// String Influenceridfordelete = upflu.get("data._id");
//String deleteinflu = given().log().all().headers("Content-Type","application/json")
//.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
//.when().delete("/api/v2/influencer/delete?id="+Influenceridfordelete+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
//System.out.println(deleteinflu);
//JsonPath jd=new JsonPath(deleteinflu);
//String infludelete=jd.get("message");
//Assert.assertEquals("SUCCESS",infludelete );
//
//
//Reporter.log("Endpoint :/api/v2/influencer/delete");
//Reporter.log("StatusCode :200");
//Reporter.log("Sucessfully deleted Influence details");

}
