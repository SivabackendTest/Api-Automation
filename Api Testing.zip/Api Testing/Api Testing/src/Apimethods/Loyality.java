package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Loyality {
	AuthorizationToken a=new AuthorizationToken(); 

	@Test(priority=1)
	public void Createloyalitypoints(){
			
			RestAssured.baseURI="http://hcpdev.curd.network:3000";
			// TODO Auto-generated method stub
			 Response Createloyality = given().log().all().headers("Content-Type","application/json")
					.header("email",a.mail).body("{\r\n"
							+ "  \"profileId\": \""+a.Memberid+"\",\r\n"
							+ "  \"businessId\": \""+a.Businessid+"\",\r\n"
							+ "  \"currency\": \"AED\",\r\n"
							+ "  \"dealValue\": 1000,\r\n"
							+ "  \"orderId\": \"IN001\",\r\n"
							+ "  \"reward\": 2000,\r\n"
							+ "  \"redeem\": 2000,\r\n"
							+ "  \"invoice\": \"IN001\"\r\n"
							+ "}").headers("Authorization", a.AuthorizationToken)
			.when().post("/api/v2/loyalty/create-loyalty-point");
			 Object loyalityId = Createloyality.then().contentType(ContentType.JSON).extract().path("data._id");
			 //BusinessUserId=Createloyality.then().contentType(ContentType.JSON).extract().path("data[0].userId");
			 String loyalitymessage = Createloyality.then().contentType(ContentType.JSON).extract().path("message");
 System.out.println(loyalitymessage);
	Assert.assertEquals("SUCCESS",loyalitymessage );

			System.out.println(loyalityId);
//			JsonPath js1=new JsonPath(Createbusiness);
//
//				String businessid=js1.get("data[0]._id");
//				System.out.println("businessid"+businessid);
				   Reporter.log("Endpoint :/api/v2/loyalty/create-loyalty-point");
			        Reporter.log("StatusCode :200");
				
				Reporter.log("loyality created");
	}
	@Test(priority=2)
	public void getloyality() {
		
			String getavaliblityloyality = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("/api/v2/loyalty/get-available-loyalty").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getavaliblityloyality);
					
					JsonPath js9=new JsonPath(getavaliblityloyality);
					
									String  loyalitygetMessage=js9.get("message");
									System.out.println("getloyality message"+loyalitygetMessage);
									Assert.assertEquals("SUCCESS",loyalitygetMessage );

					Reporter.log("Endpoint :/api/v2/loyalty/get-available-loyalty");
			        Reporter.log("StatusCode :200");
						Reporter.log("Retrieve Loyality sucessful");}
	@Test(priority=3)
	public void UpdateBusiness() {
		
		 Response Createloyality = given().log().all().headers("Content-Type","application/json")
					.header("email",a.mail).body("{\r\n"
							+ "  \"profileId\": \""+a.Memberid+"\",\r\n"
							+ "  \"businessId\": \""+a.Businessid+"\",\r\n"
							+ "  \"currency\": \"AED\",\r\n"
							+ "  \"dealValue\": 1000,\r\n"
							+ "  \"orderId\": \"IN001\",\r\n"
							+ "  \"reward\": 2000,\r\n"
							+ "  \"redeem\": 2000,\r\n"
							+ "  \"invoice\": \"IN001\"\r\n"
							+ "}").headers("Authorization", a.AuthorizationToken)
			.when().post("/api/v2/loyalty/create-loyalty-point");
			 Object loyalityId2 = Createloyality.then().contentType(ContentType.JSON).extract().path("data._id");
				
					//update businessprofile
					String updateloyality = given().log().all().headers("Content-Type","application/json").header("email",a.mail).param("id", loyalityId2)
							.body("{\r\n"
									+ "  \"currency\": \"AED\",\r\n"
									+ "  \"dealValue\": 1000,\r\n"
									+ "  \"reward\": 2000,\r\n"
									+ "  \"redeem\": 2000,\r\n"
									+ "  \"validity\": \"2024-10-06\"\r\n"
									+ "}")
							.headers("Authorization", a.AuthorizationToken)
							.when().put("/api/v2/loyalty/update-loyalty").then().assertThat().statusCode(200).extract().response().asString();
							System.out.println(updateloyality);
							
							JsonPath jub=new JsonPath(updateloyality);
							String updateloyalitypoint=jub.get("message");
							Assert.assertEquals("SUCCESS",updateloyalitypoint );
							
							Reporter.log("Endpoint :/api/v2/loyalty/update-loyalty");
					        Reporter.log("StatusCode :200");
							Reporter.log("Updated loyality points sucessfully");
	}
							
							@Test(priority=8)
							public void Deletebusiness() {
								
							
					//Delete businessprofile
								
								 Response CreateloyalityforDelete= given().log().all().headers("Content-Type","application/json")
											.header("email",a.mail).body("{\r\n"
													+ "  \"profileId\": \""+a.Memberid+"\",\r\n"
													+ "  \"businessId\": \""+a.Businessid+"\",\r\n"
													+ "  \"currency\": \"AED\",\r\n"
													+ "  \"dealValue\": 1000,\r\n"
													+ "  \"orderId\": \"IN001\",\r\n"
													+ "  \"reward\": 2000,\r\n"
													+ "  \"redeem\": 2000,\r\n"
													+ "  \"invoice\": \"IN001\"\r\n"
													+ "}").headers("Authorization", a.AuthorizationToken)
									.when().post("/api/v2/loyalty/create-loyalty-point");
									 Object loyalityIdDelete = CreateloyalityforDelete.then().contentType(ContentType.JSON).extract().path("data._id");
										

								
							String deleteLoyality= given().log().all().headers("Content-Type","application/json").param("id", loyalityIdDelete)
									.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
									.when().delete("/api/v2/loyalty/delete-loyalty").then().log().all().assertThat().statusCode(200).extract().response().asString();
									System.out.println(deleteLoyality);
									JsonPath jd=new JsonPath(deleteLoyality);
									String Loyalitydelete=jd.get("message");
									Assert.assertEquals("SUCCESS",Loyalitydelete );

									
									Reporter.log("Endpoint :/api/v2/loyalty/delete-loyalty");
							        Reporter.log("StatusCode :200");
									Reporter.log("Sucessfully deleted Loyality");
		}
}
