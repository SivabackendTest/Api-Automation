package Apimethods;

import static io.restassured.RestAssured.given;

import java.util.Scanner;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Businessprofile {
public AuthorizationToken token;

AuthorizationToken a=new AuthorizationToken(); 
public String BusinessProfileId="66d7faf0295597f419644bbe";
public String BusinessProfileId1;
public String BusinessUserId;
@Test(priority=1)
	public void Createbusinessprofile(){
			
			RestAssured.baseURI="http://hcpdev.curd.network:3000";
			// TODO Auto-generated method stub
			 String Createbusiness = given().log().all().headers("Content-Type","application/json")
					.header("email",a.mail).body("{\r\n"
							+ "    \"businessName\":\""+a.BusinessName+"\",\r\n"
							+ "    \"description\":\"services\",\r\n"
							+ "    \"industry\":\"Information Technology & Services\",\r\n"
							+ "    \"address\":\"Hyderabad\",\r\n"
							+ "    \"keywords\":[\"food\"],\r\n"
							+ "   \r\n"
							+ "    \"businessKind\":[\"Manufacturer\"],\r\n"
							+ "    \"lat\":\"18.93\",\r\n"
							+ "    \"ownerId\":\"68d4e7e4108014aaff0d638a\",\r\n"
							+ "    \"long\":\"14.23\"\r\n"
						
							+ "}\r\n"
							+ "").headers("Authorization", a.AuthorizationToken)
			.when().post("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
//			 BusinessProfileId=Createbusiness.then().contentType(ContentType.JSON).extract().path("data[0]._id");
//			 BusinessUserId=Createbusiness.then().contentType(ContentType.JSON).extract().path("data[0].userId");
//			 String Businessmessage = Createbusiness.then().contentType(ContentType.JSON).extract().path("message");
 //System.out.println(Businessmessage);
	//Assert.assertEquals("SUCCESS",Businessmessage );

			System.out.println(BusinessProfileId);
			JsonPath js1=new JsonPath(Createbusiness);

				String businessid=js1.get("data[0]._id");
				System.out.println("businessid"+businessid);
				   Reporter.log("Endpoint :api/v2/businessProfile");
			        Reporter.log("StatusCode :200");
			        System.out.println(Createbusiness);
				
				Reporter.log("Business profile created");
	}
	@Test(priority=2)
	public void getbusiness() {
		
			String getbusiness = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getbusiness);
					
					JsonPath js9=new JsonPath(getbusiness);
					
									String businessgetMessage=js9.get("message");
									System.out.println("businessgetapi message"+businessgetMessage);
									Assert.assertEquals("SUCCESS",businessgetMessage );

					Reporter.log("Endpoint :api/v2/businessProfile");
			        Reporter.log("StatusCode :200");
						Reporter.log("Retrieve business profile sucessful");}
	@Test(priority=3)
	public void UpdateBusiness() {
		
	Response businessidcreate1 = given().log().all().headers("Content-Type","application/json")
				.header("email",a.mail).body("{\r\n"
						+ "    \"businessName\":\""+a.BusinessName2+"\",\r\n"
						+ "    \"description\":\"services\",\r\n"
						+ "    \"industry\":\"Information Technology & Services\",\r\n"
						+ "    \"address\":\"Hyderabad\",\r\n"
						+ "    \"keywords\":[\"food\"],\r\n"
						+ "   \r\n"
						+ "    \"businessKind\":[\"Manufacturer\"],\r\n"
						+ "    \"lat\":\"18.63\",\r\n"
						+ "    \"long\":\"16.23\"\r\n"
						+ "}\r\n"
						+ "").headers("Authorization", a.AuthorizationToken)
		.when().post("api/v2/businessProfile");
		 BusinessProfileId1=businessidcreate1.then().contentType(ContentType.JSON).extract().path("data[0]._id");
	
				System.out.println(businessidcreate1);
				
					//update businessprofile
					String updatebusiness = given().log().all().headers("Content-Type","application/json").header("email",a.mail).param("id", BusinessProfileId)
							.body("{\r\n"
									+ "    \"type\": \"award\",\r\n"
									+ "    \"title\": \""+a.Awardtitle+"\",\r\n"
									+ "    \"received\": \""+a.Received+"\",\r\n"
									+ "    \"organization\": \""+a.Organization+"\"\r\n"
									+ "}")
							.headers("Authorization", a.AuthorizationToken)
							.when().patch("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
							System.out.println(updatebusiness);
							
							JsonPath jub=new JsonPath(updatebusiness);
							String businessupdateaward=jub.get("message");
							Assert.assertEquals("SUCCESS",businessupdateaward );
							
							Reporter.log("Endpoint :api/v2/businessProfile");
					        Reporter.log("StatusCode :200");
							Reporter.log("Updated business profile sucessfully");
	}
							
							@Test(priority=8)
							public void Deletebusiness() {
								
							
					//Delete businessprofile
								String businessidcreate =  given().log().all().headers("Content-Type","application/json")
										.header("email",a.mail).body("{\r\n"
												+ "    \"businessName\":\"InfoGain\",\r\n"
												+ "    \"description\":\"provide services\",\r\n"
												+ "    \"industry\":\"Information Technology & Services\",\r\n"
												+ "    \"address\":\"Hyderabad\",\r\n"
												+ "    \"keywords\":[\"food\"],\r\n"
												+ "   \r\n"
												+ "    \"businessKind\":[\"Manufacturer\"],\r\n"
												+ "    \"lat\":\"18.63\",\r\n"
												+ "    \"long\":\"16.23\"\r\n"
												+ "}\r\n"
												+ "").headers("Authorization", a.AuthorizationToken)
								.when().post("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
							
										System.out.println(businessidcreate);
										JsonPath js3=new JsonPath(businessidcreate);

											String businessidforDelete=js3.get("data[0]._id");
											System.out.println("businessidforupdate"+businessidforDelete);

								
							String deletebusiness = given().log().all().headers("Content-Type","application/json").param("id", businessidforDelete)
									.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
									.when().delete("api/v2/businessProfile").then().log().all().assertThat().statusCode(200).extract().response().asString();
									System.out.println(deletebusiness);
									JsonPath jd=new JsonPath(deletebusiness);
									String businessdelete=jd.get("message");
									Assert.assertEquals("SUCCESS",businessdelete );

									
									Reporter.log("Endpoint :api/v2/businessProfile");
							        Reporter.log("StatusCode :200");
									Reporter.log("Sucessfully deleted business account");
		}
							@Test(priority=5)
							public void SearchSEOkeywords(){
									
									String Createbusiness = given().log().all().headers("Content-Type","application/json")
											.header("email",a.mail).body("{\r\n"
													+ "  \"key\": \""+a.SeoKeyword+"\"\r\n"
													+ "}").headers("Authorization", a.AuthorizationToken)
									.when().post("/api/v2/businessProfile/searchSeo").then().assertThat().statusCode(200).extract().response().asString();
									System.out.println(Createbusiness);
									JsonPath js1=new JsonPath(Createbusiness);
										String businessSeosearch=js1.get("message");
										Assert.assertEquals("SUCCESS",businessSeosearch );

										System.out.println("businessseokeyword"+businessSeosearch);
										   Reporter.log("Endpoint :/api/v2/businessProfile/searchSeo");
									        Reporter.log("StatusCode :200");
										
										Reporter.log("Business profile search SEO Keywords");
							}
							@Test(priority=6)
								public void BusinessUpdatephonenumber() {
								
								/*String getbusinessupdateemail = given().log().all().headers("Content-Type","application/json")
										.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
										.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
								
								JsonPath jE3=new JsonPath(getbusinessupdateemail);

									String businessidforEmailupdate=jE3.get("data[0]._id");
									System.out.println("businessidforEmailupdate"+businessidforEmailupdate);*/
								
								
								
							String updatebusinesscontact = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
									.body("{\r\n"
											+ "  \"emailId\": \""+a.mail+"\",\r\n"
											+ "  \"phoneNumber\": "+a.Phonenumber+",\r\n"
											+ "  \"is_verified\": \"false\"\r\n"
											+ "}")
									.headers("Authorization", a.AuthorizationToken)
									.when().patch("/api/v2/businessProfile/status?id="+BusinessProfileId+"").then().assertThat().statusCode(200).extract().response().asString();
									System.out.println(updatebusinesscontact);
									JsonPath updatedcontact=new JsonPath(updatebusinesscontact);
							        String Updatedcontactmessage=updatedcontact.get("message");
							        
									Assert.assertEquals("SUCCESS",Updatedcontactmessage );
									Reporter.log("Endpoint :/api/v2/businessProfile/status?id");
							        Reporter.log("StatusCode :200");
									Reporter.log("Updated business profile Email sucessfully");
							}
							
							
							@Test(priority=7)
							public void BusinessReviewRetrieve() {
								/*String getbusinessforreview = given().log().all().headers("Content-Type","application/json")
										.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
										.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
								
								JsonPath jE3=new JsonPath(getbusinessforreview);

									String businessidforEmailupdate=jE3.get("data[0]._id");
									System.out.println("businessidforReviewupdate"+businessidforEmailupdate);*/
					
									String getbusinessreview = given().log().all().headers("Content-Type","application/json")
											.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
											.param("businessId",BusinessProfileId ).param("skip", "0").param("limit", "5")
											.when().get("/api/v2/businessProfile/getUserForFollowReview").then().assertThat().statusCode(200).extract().response().asString();	
									JsonPath Review=new JsonPath(getbusinessreview);
							        String reviewmessage=Review.get("message");
							        
									Assert.assertEquals("SUCCESS",reviewmessage );
									Reporter.log("Endpoint :/api/v2/businessProfile/getUserForFollowReview");
							        Reporter.log("StatusCode :200");
									Reporter.log("Business review retrieve sucessfully");
							}
							
}

