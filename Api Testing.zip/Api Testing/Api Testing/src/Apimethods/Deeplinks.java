package Apimethods;

import static io.restassured.RestAssured.given;

import java.io.File;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.path.json.JsonPath;

public class Deeplinks {
	AuthorizationToken a=new AuthorizationToken();
	Personal P=new Personal();
	Businessprofile B=new Businessprofile();
	@Test(priority=1)
	public void Getprofiledeeplink(){
		String Getprofiledeep = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("userId",P.PersonalprofileId).
				when().get("/api/v2/deeplink/getProfile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(Getprofiledeep);
				
				JsonPath PDeep=new JsonPath(Getprofiledeep);
				
								String GetDeeplinkProfileMessage=PDeep.get("message");
								System.out.println("Deeplinkprofilegetapi message"+GetDeeplinkProfileMessage);
								Assert.assertEquals("SUCCESS",GetDeeplinkProfileMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/getProfile");
		        Reporter.log("StatusCode :200");
					Reporter.log("Retrieve Personal profile deeplink");
					}
	@Test(priority=2)
	public void Getwalletdeeplink(){
		String Getprofiledeep = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("userId",P.PersonalprofileId).
				when().get("/api/v2/deeplink/getWallet").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(Getprofiledeep);
				
				JsonPath walletDeep=new JsonPath(Getprofiledeep);
				
								String GetDeeplinkwalletMessage=walletDeep.get("message");
								System.out.println("Deeplinkwalletgetapi message"+GetDeeplinkwalletMessage);
								Assert.assertEquals("SUCCESS",GetDeeplinkwalletMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/getWallet");
		        Reporter.log("StatusCode :200");
					Reporter.log("User Retrieve Wallet profile deeplink");
					}
	@Test(priority=3)
	public void Checkphonedeeplink(){
		String phonenumberdeep = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
						+ "  \"phoneBook\": [\r\n"
						+ "    \"+91 9934834343\"\r\n"
						+ "  ],\r\n"
						+ "  \"google\": [\r\n"
						+ "    \""+a.mail+"\"\r\n"
						+ "  ]\r\n"
						+ "}").
				when().post("/api/v2/deeplink/").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(phonenumberdeep);
				
				JsonPath phoneDeep=new JsonPath(phonenumberdeep);
				
								String DeeplinkphonenumberMessage=phoneDeep.get("message");
								System.out.println("Deeplinkphonecheckapi message"+DeeplinkphonenumberMessage);
								Assert.assertEquals("SUCCESS",DeeplinkphonenumberMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/");
		        Reporter.log("StatusCode :200");
					Reporter.log("User Retrieve Profile withcontact details deeplink");
					}
	@Test(priority=4)
	public void fetchcontactdeeplink(){
		String Fetchcontactdeep = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).
				when().post("/api/v2/deeplink/fetchContact").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(Fetchcontactdeep);
				
				JsonPath phonefetchDeep=new JsonPath(Fetchcontactdeep);
				String Fetchcontactresult = phonefetchDeep.get("data");
				
								String phonenumberfetchMessage=phonefetchDeep.get("message");
								System.out.println("DeeplinkphoneFetchapi message"+phonenumberfetchMessage);
								Assert.assertEquals("SUCCESS",phonenumberfetchMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/fetchContact");
		        Reporter.log("StatusCode :200");
					Reporter.log("User Retrieve contact details deeplink");
					}
	@Test(priority=5)
	public void inviteemaildeeplink(){
		String inviteemaildeep = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).
				body("{\r\n"
						+ "  \"name\": \""+a.invitename+"\",\r\n"
						+ "  \"email\": \""+a.inviteemailDeeplink+"\"\r\n"
						+ "}").
				when().post("/api/v2/deeplink/inviteEmail").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(inviteemaildeep);
				
				JsonPath phonefetchDeep=new JsonPath(inviteemaildeep);
				
								String phonenumberfetchMessage=phonefetchDeep.get("message");
								System.out.println("DeeplinkphoneFetchapi message"+phonenumberfetchMessage);
								Assert.assertEquals("SUCCESS",phonenumberfetchMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/inviteEmail");
		        Reporter.log("StatusCode :200");
					Reporter.log("User Retrieve contact details deeplink");
					}
	@Test(priority=6)
	public void Geturl(){
		String Geturldeep = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).
				when().get("/api/v2/deeplink/url").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(Geturldeep);
				
				JsonPath UrlDeep=new JsonPath(Geturldeep);
				
								String GetDeeplinkurlMessage=UrlDeep.get("message");
								System.out.println("Deeplinkurlgetapi message"+GetDeeplinkurlMessage);
								Assert.assertEquals("SUCCESS",GetDeeplinkurlMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/url");
		        Reporter.log("StatusCode :200");
					Reporter.log("Retrieve User Url deeplink");
					}
	@Test(priority=7)
	public void GetpersonalprofileDeep(){
		String Getprofiledeep = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).
				when().post("/api/v2/deeplink/genPersonalProfile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(Getprofiledeep);
				
				JsonPath propDeep=new JsonPath(Getprofiledeep);
				
								String GetDeepprofileMessage=propDeep.get("message");
							
								String PersonalprofileDeeplink = propDeep.get("data");
								Reporter.log(PersonalprofileDeeplink);
								System.out.println("Deepgetpersonalapi message"+GetDeepprofileMessage);
								Assert.assertEquals("SUCCESS",GetDeepprofileMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/genPersonalProfile");
		        Reporter.log("StatusCode :200");
					Reporter.log("Retrieve User profile deeplink");
					}
	
	@Test(priority=8)
	public void GetbusinessprofileDeep(){
		String GetBprofiledeep = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
						+ "  \"businessId\": \""+B.BusinessProfileId+"\"\r\n"
						+ "}").
				when().post("/api/v2/deeplink/genBusinessProfile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(GetBprofiledeep);
				
				JsonPath propDeep=new JsonPath(GetBprofiledeep);
				
								String GetDeepbprofileMessage=propDeep.get("message");
							
								String BusinessprofileDeeplink = propDeep.get("data");
								Reporter.log(BusinessprofileDeeplink);
								System.out.println("Deepgetpersonalapi message"+GetDeepbprofileMessage);
								Assert.assertEquals("SUCCESS",GetDeepbprofileMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/genBusinessProfile");
		        Reporter.log("StatusCode :200");
					Reporter.log("Retrieve User profile deeplink");
					}
	@Test(priority=9)

	public void GetbusinesscontactuploadDeep(){
	    File contactfile=new File("C:\\Users\\CURD Automation\\Downloads\\sample_test (2).csv");

		String GetBprofilecontact = given().log().all().headers("Content-Type","multipart/form-data")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).multiPart("contact",contactfile).
				when().post("/api/v2/deeplink/business-contact-list?businessId="+B.BusinessProfileId+"").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(GetBprofilecontact);
				
				JsonPath ContactDeep=new JsonPath(GetBprofilecontact);
				
								String GetContactBusinessMessage=ContactDeep.get("message");
							
								String BusinessprofileDeeplinkcontact = ContactDeep.get("data.count");

								Reporter.log(BusinessprofileDeeplinkcontact);
								System.out.println("DeepgetBcontactapi message"+GetContactBusinessMessage);
								Assert.assertEquals("SUCCESS",GetContactBusinessMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/business-contact-list");
		        Reporter.log("StatusCode :200");
					Reporter.log("User Uploaded Business Contacts Sucessfully");
					}
	@Test(priority=10)
	public void Getbusinesscontact(){
		String GetBprofileContactdetails = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("businessId",B.BusinessProfileId).
				param("skip","0").param("limit","5").
				when().post("/api/v2/deeplink/business-contact-list").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(GetBprofileContactdetails);
				
				JsonPath GBdetails=new JsonPath(GetBprofileContactdetails);
				
								String GetbcontactMessage=GBdetails.get("message");
							
								String Businesscontactlink = GBdetails.get("data.count");
								Reporter.log(Businesscontactlink);
								System.out.println("Deepgetpersonalapi message"+GetbcontactMessage);
								Assert.assertEquals("SUCCESS",GetbcontactMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/business-contact-list");
		        Reporter.log("StatusCode :200");
					Reporter.log("User Retrieve Business Contacts sucessfully");
					}
	@Test(priority=11)
	public void Businesscsvemail(){
		File contactfile=new File("C:\\Users\\CURD Automation\\Downloads\\sample_test (2).csv");

		String GetBprofilecsvcontact = given().log().all().headers("Content-Type","multipart/form-data")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).multiPart("contact",contactfile).
				when().post("/api/v2/deeplink/csvEmail?businessId="+B.BusinessProfileId+"").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(GetBprofilecsvcontact);
				
				JsonPath ContactDeep=new JsonPath(GetBprofilecsvcontact);
				
								String GetContactBusinesscsvMessage=ContactDeep.get("message");
							

								System.out.println("DeepgetBcontactapi message"+GetContactBusinesscsvMessage);
								Assert.assertEquals("SUCCESS",GetContactBusinesscsvMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/csvEmail");
		        Reporter.log("StatusCode :200");
					Reporter.log("User send email Sucessfully");
					}
	@Test(priority=12)
	public void contactsearch(){

		String Searchcontact = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
						+ "  \"name\": \"Keshav\",\r\n"
						+ "  \"source\": \"phonebook\",\r\n"
						+ "  \"phone\": [\r\n"
						+ "\"+91 9852485215\" \r\n"
						+ " ]\r\n"
						+ "}").
				when().post("/api/v2/deeplink/searchContact").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(Searchcontact);
				
				JsonPath ContactDeep=new JsonPath(Searchcontact);
				
								String SearchcontactMessage=ContactDeep.get("message");
							

								System.out.println("DeepgetBcontactapi message"+SearchcontactMessage);
								Assert.assertEquals("SUCCESS",SearchcontactMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/searchContact");
		        Reporter.log("StatusCode :200");
					Reporter.log("User Retrieve contact details sucessfully");
					}
	@Test(priority=13)

	public void PersonalcontactuploadDeep(){
	    File personalcontactfile=new File("C:\\Users\\CURD Automation\\Downloads\\phonebook.json");

		String GetBprofilecontact = given().log().all().headers("Content-Type","multipart/form-data")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).multiPart("contact",personalcontactfile).
				when().post("/api/v2/deeplink/contact-list").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(personalcontactfile);
				
				JsonPath ContactDeepper=new JsonPath(personalcontactfile);
				
								String GetContactpersonalMessage=ContactDeepper.get("message");
							

								System.out.println("DeepgetBcontactapi message"+GetContactpersonalMessage);
								Assert.assertEquals("SUCCESS",GetContactpersonalMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/contact-list");
		        Reporter.log("StatusCode :200");
					Reporter.log("User Uploaded phonebook Contacts Sucessfully");
					}
	@Test(priority=14)

	public void Bulkinvite(){
	    File personalcontactfile1=new File("C:\\Users\\CURD Automation\\Downloads\\phonebook.json");

		String Bulkinvite = given().log().all().headers("Content-Type","multipart/form-data")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).multiPart("contact",personalcontactfile1).
				when().post("/api/v2/deeplink/bulk-user-invite").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(Bulkinvite);
				
				JsonPath ContactDeepper=new JsonPath(Bulkinvite);
				
								String BulkinviteMessage=ContactDeepper.get("message");
							

								System.out.println("Bulkinvite message"+BulkinviteMessage);
								Assert.assertEquals("SUCCESS",BulkinviteMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/bulk-user-invite");
		        Reporter.log("StatusCode :200");
					Reporter.log("User did Bulk invited contacts Sucessfully");
					}
	@Test(priority=15)

	public void Postoutsidebusiness(){

		String OutsideBusiness = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
						+ "  \"referralId\": \"65d85182b46de822593a815a\",\r\n"
						+ "  \"referrerId\": \"65d85182b46de822593a815a\",\r\n"
						+ "  \"businessEmail\": \"dinesh@curd.network\"\r\n"
						+ "}").
				when().post("/api/v2/deeplink/outsideBusiness").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(OutsideBusiness);
				
				JsonPath outsideref=new JsonPath(OutsideBusiness);
				
								String outsiderefMessage=outsideref.get("message");
							

								System.out.println("Outside referral message"+outsiderefMessage);
								Assert.assertEquals("SUCCESS",outsiderefMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/outsideBusiness");
		        Reporter.log("StatusCode :200");
					Reporter.log("User refer outside business Sucessfully");
					}
	@Test(priority=16)

	public void PostInsidebusiness(){

		String insideBusiness = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
						+ "  \"referralId\": \"65d85182b46de822593a815a\",\r\n"
						+ "  \"referrerId\": \"65d85182b46de822593a815a\",\r\n"
						+ "  \"businessEmail\": \"dinesh@curd.network\"\r\n"
						+ "}").
				when().post("/api/v2/deeplink/insideBusiness").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(insideBusiness);
				
				JsonPath insideref=new JsonPath(insideBusiness);
				
								String insiderefMessage=insideref.get("message");
							

								System.out.println("Outside referral message"+insiderefMessage);
								Assert.assertEquals("SUCCESS",insiderefMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/insideBusiness");
		        Reporter.log("StatusCode :200");
					Reporter.log("User refer inside business Sucessfully");
					}
	@Test(priority=17)

	public void Postinsidepersonal(){

		String insidepersonal = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
						+ "  \"referralId\": \"65d85182b46de822593a815a\",\r\n"
						+ "  \"referrerId\": \"65d85182b46de822593a815a\",\r\n"
						+ "  \"personalId\": \"65d85182b46de822593a815a\"\r\n"
						+ "}").
				when().post("/api/v2/deeplink/insidePersonal").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(insidepersonal);
				
				JsonPath insideref=new JsonPath(insidepersonal);
				
								String insiderefpMessage=insideref.get("message");
							

								System.out.println("Outside referral message"+insiderefpMessage);
								Assert.assertEquals("SUCCESS",insiderefpMessage );

				Reporter.log("Endpoint :/api/v2/deeplink/insidePersonal");
		        Reporter.log("StatusCode :200");
					Reporter.log("User refer inside personalProfile Sucessfully");
					}
	
	}
		

