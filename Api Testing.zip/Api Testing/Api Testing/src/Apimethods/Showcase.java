package Apimethods;

import static io.restassured.RestAssured.given;

import java.io.File;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Showcase {
	public AuthorizationToken token;
	public String BusinessShowcaseId;
	AuthorizationToken a=new AuthorizationToken(); 	
	Businessprofile BS=new Businessprofile();
	@Test(priority=1)
	public void CreatebusinessShowcase(){
			
			RestAssured.baseURI="http://hcpdev.curd.network:3000";
			
			/*String getbusinessforShowcase = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getbusinessforShowcase);
			JsonPath SS1=new JsonPath(getbusinessforShowcase);

				String businessidforShowcase=SS1.get("data[0]._id");
				
				System.out.println("businessidcollection "+businessidforShowcase);*/
			
				File image1=new File("C:\\Users\\CURD Automation\\Downloads\\AutomationTestImage.jpg");
				
		
			
		 Response CreateShowcase = given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
					.headers("Authorization", a.AuthorizationToken).multiPart("businessId",BS.BusinessProfileId).multiPart("docName","Soft")
					.multiPart("description","all")
					.when().post("/api/v2/showcase/create");
			BusinessShowcaseId= CreateShowcase.then().contentType(ContentType.JSON).extract().path("data._id");			

		
			 				System.out.println(CreateShowcase);
			
			
			 

				/*String Showcasemessage=jc1.get("message");
				Assert.assertEquals("SUCCESS",Showcasemessage );
				System.out.println("businessShowcaseid"+Showcaseid);
				   Reporter.log("Endpoint :/api/v2/showcase/create");
			        Reporter.log("StatusCode :200");
				
				Reporter.log("Business Collection Created");*/
				

				String CreateShowcase1 =given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
						.headers("Authorization", a.AuthorizationToken).multiPart("businessId",BS.BusinessProfileId).multiPart("docName","Soft")
						.multiPart("description","all").multiPart("image",image1)
						.when().post("/api/v2/showcase/create")
						.then().log().all().assertThat().statusCode(200).extract().response().asString();
				 				System.out.println(CreateShowcase1);
				 				
}
	@Test(priority=2)
	public void GetbusinessShowcase(){
			
		/*String getbusinessforShowcase = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getbusinessforShowcase);
		JsonPath SS2=new JsonPath(getbusinessforShowcase);

			String businessidforGetShowcase=SS2.get("data[0]._id");
			String UserIdforGetShowcase= SS2.get("data[0].userId");
			System.out.println("businessidcollection "+businessidforGetShowcase);*/
		
		
			
	String getShowcase = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.param("skip", "0").param("limit", "5").param("businessId", BS.BusinessProfileId).param("userId",BS.BusinessUserId)
			.when().get("/api/v2/showcase/").then().assertThat().statusCode(200).extract().response().asString();
	System.out.println(getShowcase);
	JsonPath SS3=new JsonPath(getShowcase);

		String businessidforShowcase=SS3.get("data[0]._id");
		
		System.out.println("businessidcollection "+businessidforShowcase);
	}
	
	@Test(priority=3)
	public void updatebusinessShowcase(){
			
		/*String getbusinessforupdateShowcase = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getbusinessforupdateShowcase);
		JsonPath SS2=new JsonPath(getbusinessforupdateShowcase);

			String businessidforUpdateShowcase=SS2.get("data[0]._id");
			String UserIdforUpdateShowcase= SS2.get("data[0].userId");
			
			
			String CreateShowcase2 =given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
					.headers("Authorization", a.AuthorizationToken).multiPart("businessId",businessidforUpdateShowcase).multiPart("docName","Soft")
					.multiPart("description","all")
					.when().post("/api/v2/showcase/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
			 				System.out.println(CreateShowcase2);
			
			JsonPath jc5=new JsonPath(CreateShowcase2);

				String Showcaseidforupdate=jc5.get("data._id");
				String Showcasemessage=jc5.get("message");
				Assert.assertEquals("SUCCESS",Showcasemessage );
				System.out.println("businessShowcaseid"+Showcaseidforupdate);*/
		
		
			String UpdateShowcase =given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
					.headers("Authorization", a.AuthorizationToken).multiPart("docName","Software")
					.multiPart("description","allproduct")
					.when().put("/api/v2/showcase/update?id="+BusinessShowcaseId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
			 				System.out.println(UpdateShowcase);
			
	
			 				JsonPath SS3=new JsonPath(UpdateShowcase);

		String businessidforShowcase=SS3.get("data[0]._id");
		
		System.out.println("businessidcollection "+businessidforShowcase);
		File patchimage1=new File("C:\\Users\\CURD Automation\\Downloads\\AutomationTestImage.jpg");
		File patchvideo=new File("C:\\Users\\CURD Automation\\Downloads\\SampleVideo_1280x720_5mb.mp4");

		String UpdateShowcase2 =given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
				.headers("Authorization", a.AuthorizationToken).multiPart("docName","Software")
				.multiPart("description","allproduct").multiPart("image",patchimage1)
				.when().put("/api/v2/showcase/update?id="+BusinessShowcaseId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
		 				System.out.println(UpdateShowcase2);
		 				
		 				String UpdateShowcase3 =given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
		 						.headers("Authorization", a.AuthorizationToken).multiPart("docName","Software")
		 						.multiPart("description","allproduct").multiPart("video",patchvideo)
		 						.when().put("/api/v2/showcase/update?id="+BusinessShowcaseId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
		 				 				System.out.println(UpdateShowcase3);
	}
	
	@Test(priority=4)
	public void DeletebusinessShowcase(){
		String getbusinessforDeleteShowcase = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getbusinessforDeleteShowcase);
		JsonPath SS6=new JsonPath(getbusinessforDeleteShowcase);

			String businessidforDeleteShowcase=SS6.get("data[0]._id");
			String UserIdforGetShowcase1= SS6.get("data[0].userId");
			System.out.println("businessidfordeleteshowcase "+businessidforDeleteShowcase);
			
			String CreateShowcase2=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
					.headers("Authorization", a.AuthorizationToken).multiPart("businessId",businessidforDeleteShowcase).multiPart("docName","Soft")
					.multiPart("description","all")
					.when().post("/api/v2/showcase/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
			 				System.out.println(CreateShowcase2);
			
			JsonPath jfd=new JsonPath(CreateShowcase2);

				String Showcaseid3=jfd.get("data._id");
			
			String deleteproduct = given().log().all().headers("Content-Type","application/json").param("id",Showcaseid3 )
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().delete("/api/v2/showcase/delete").then().log().all().assertThat().statusCode(200).extract().response().asString();
					System.out.println(deleteproduct);
					Reporter.log("Endpoint :/api/v2/showcase/delete");
			        Reporter.log("StatusCode :200");
					Reporter.log("Sucessfully deleted business Showcase");
		
	}
	
	
	
}