package Apimethods;

import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.given;

public class Likeapi{
	AuthorizationToken a=new AuthorizationToken();


	@Test(priority=1)
	public void Like() throws InterruptedException {
 		RestAssured.baseURI="http://hcpdev.curd.network:3000";

    	String getpersonaldetailsForlike = given().log().all().headers("Content-Type","application/json")
    			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
    			System.out.println(getpersonaldetailsForlike);
    			JsonPath Crl=new JsonPath(getpersonaldetailsForlike);
    	        String PersonalprofIdforLike = Crl.get("data._id");
    	        System.out.println("PersonalUserIdLike "+PersonalprofIdforLike);
    	        
    	        
    	        
     String CreatePostlike=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
				.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","everyone")
				.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
				.multiPart("createdBy.ref_id",PersonalprofIdforLike).multiPart("createdBy.ref_model","personal_profile").multiPart("isRepost","false")
				.when().post("api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();		
   
    	System.out.println(CreatePostlike);
    				JsonPath LS1=new JsonPath(CreatePostlike);

    					String Postmessageforlike=LS1.get("message");
    					String PostIdforlike=LS1.get("data._id");
    					System.out.println("PostIdforlike "+PostIdforlike);
    						System.out.println("Postmessage"+Postmessageforlike);
    						   Thread.sleep(3000);   
    	        
    	       
    	//Post Like				
    	
    	String Postlike=given().log().all().headers("Content-Type","application/json")
    			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
    					+ "  \"createdBy\": {\r\n"
    					+ "    \"ref_id\": \""+PersonalprofIdforLike+"\",\r\n"
    					+ "    \"ref_model\": \"personal_profile\"\r\n"
    					+ "  },\r\n"
    					+ "  \"type\": \"post\",\r\n"
    					+ "  \"postType\": \"professional\",\r\n"
    					+ "  \"feedId\": \""+PostIdforlike+"\",\r\n"
    					+ "  \"parentId\": \""+PostIdforlike+"\"\r\n"
    					+ "}")	    	    			
    			.when().post("api/v2/like").then().log().all().assertThat().statusCode(200).extract().response().asString();
    			System.out.println(Postlike);
    		JsonPath li=new JsonPath(Postlike);

    			String Likemessage=li.get("message");
    			String LikeId=li.get("data._id");
    			System.out.println("LikeId "+LikeId);
    				System.out.println("Like message"+Likemessage);
    				Reporter.log("api/v2/like");
    				Reporter.log("statusCode 200");
    				Reporter.log("User like sucessfully"); 
    				
    	//Like Count
    				String getlikecountuser= given().log().all().headers("Content-Type","application/json")
	    		    	   	.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
	    		    	   			+ "  \"type\": \"post\",\r\n"
	    		    	   			+ "  \"parentId\": \""+PostIdforlike+"\"\r\n"
	    		    	   			+ "}").
	    		    	    			when().post("api/v2/like/count").then().log().all().assertThat().statusCode(200).extract().response().asString();
	    		    	    			System.out.println(getlikecountuser);
	    		    	    						
	    		    	    			JsonPath Getlikecount=new JsonPath(getlikecountuser);
	    		    	    			String Getcountmessage=Getlikecount.get("message");
	    		    	    						
	    		    	    				System.out.println("Getlikecountmessage "+Getcountmessage);
	    		    	    				Reporter.log("api/v2/like/count");
	    		    	    				Reporter.log("statusCode 200");
	    		    	    				Reporter.log("User like count retrieve sucessfully"); 
	    		    			
    				
    	//Delete Like
    		String deleteLike = given().log().all().headers("Content-Type","application/json").param("id", LikeId)
							.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
							.when().delete("api/v2/like").then().log().all().assertThat().statusCode(200).extract().response().asString();
										System.out.println(deleteLike);
										Reporter.log("api/v2/like");
    		    	    				Reporter.log("statusCode 200");
										Reporter.log("Sucessfully Like deleted");	    	    						
    				
    				
    	 }

}
