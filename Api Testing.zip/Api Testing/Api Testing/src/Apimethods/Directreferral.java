package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Directreferral {
	AuthorizationToken a=new AuthorizationToken();

	@Test(priority=1)
	
	public void DirectreferralCreate() throws InterruptedException {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

	//Directreferral
		
		String getpersonaldetailscreatedirectref = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail)
				.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(getpersonaldetailscreatedirectref);
				JsonPath Cref=new JsonPath(getpersonaldetailscreatedirectref);
		        String PersonalprofIdforDirectrefe = Cref.get("data._id");
		       String ReferrerUserid=Cref.get("data.userId");
		       String ReferrerName=Cref.get("data.name");
		        System.out.println(PersonalprofIdforDirectrefe);
		
		
		
		
String getbuyerdirect = given().log().all().headers("Content-Type","application/json")
	.headers("Authorization", a.buyertoken).header("email",a.buyermail)
	.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
	System.out.println(getbuyerdirect);
	JsonPath cpr=new JsonPath(getbuyerdirect);
    String Personalbuyerdirect = cpr.get("data._id");
    System.out.println("PersonalUserId "+Personalbuyerdirect);
    

String Createdirectreferral = given().log().all().headers("Content-Type","application/json")
	.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail).body("{\r\n"
			+ "  \"postType\": \"directReferral\",\r\n"
			+ "  \"createdBy\": {\r\n"
			+ "    \"ref_id\": \""+PersonalprofIdforDirectrefe+"\",\r\n"
			+ "    \"ref_model\": \"personal_profile\"\r\n"
			+ "  },\r\n"
			+ "  \"buyerType\": \"internal\",\r\n"
			+ "  \"sellerType\": \"internal\",\r\n"
			+ "  \"buyer\": {\r\n"
			+ "    \"ref_id\": \""+Personalbuyerdirect+"\",\r\n"
			+ "    \"ref_model\": \"personal_profile\",\r\n"
			+ "    \"message\": \"Hi , since you were looking for a bikes shop, I'm referring one.\",\r\n"
			+ "    \"mention\": [\r\n"
			+ "      {\r\n"
			+ "        \"index\": 6,\r\n"
			+ "        \"profileId\": \""+Personalbuyerdirect+"\",\r\n"
			+ "        \"profileType\": \"personal_profile\"\r\n"
			+ "      }\r\n"
			+ "    ]\r\n"
			+ "  },\r\n"
			+ "  \"seller\": {\r\n"
			+ "    \"ref_id\": \""+a.Businessid+"\",\r\n"
			+ "    \"ref_model\": \"business_profile\",\r\n"
			+ "    \"message\": \"Hi, I'm referring your shop to my friend here who's looking for some bikes.\",\r\n"
			+ "    \"mention\": [\r\n"
			+ "      {\r\n"
			+ "        \"index\": 6,\r\n"
			+ "        \"profileId\": \""+a.Businessid+"\",\r\n"
			+ "        \"profileType\": \"business_profile\"\r\n"
			+ "      }\r\n"
			+ "    ]\r\n"
			+ "  }\r\n"
			+ " \r\n"
			+ "}\r\n"
			+ "").
when().post("/api/v2/referral/directReferral").then().log().all().assertThat().statusCode(200).extract().response().asString();
JsonPath Dr=new JsonPath(Createdirectreferral);
String DirectReferralmessage=Dr.get("message");
String Directreferralid=Dr.get("data._id");
System.out.println(Directreferralid);
Assert.assertEquals("SUCCESS",DirectReferralmessage );
Reporter.log("/api/v2/referral/directReferral");
Reporter.log("statusCode 200");

Reporter.log("Direct Referral Created Sucessfully");
Thread.sleep(10000);
//Get post in Activity (Referrer)

String getDirectRefferal = given().log().all().headers("Content-Type","application/json").param("id", Directreferralid)
		.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail).
		when().get("api/v2/referral").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getDirectRefferal);
		
		JsonPath pgd=new JsonPath(getDirectRefferal);
		String GetRefferalmessage=pgd.get("message");
		String ReferrarId2 = pgd.get("data[0]._id");
	//	Assert.assertEquals(ReferrarId2,Directreferralid);
			System.out.println("Postmessage"+GetRefferalmessage);
			Reporter.log("api/v2/referral");
			Reporter.log("statusCode 200");
			
			Reporter.log("User retrieve refferal data sucessfully");
			//Get post Created Filter
			String getDirectRefferalCreatedfillter = given().log().all().headers("Content-Type","application/json").param("filter", "created")
					.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail).
					when().get("api/v2/referral").then().log().all().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getDirectRefferalCreatedfillter);
					
					JsonPath pgg=new JsonPath(getDirectRefferalCreatedfillter);
					String GetRefferalcreatedmessage=pgg.get("message");
						System.out.println("Postcreatefiltermessage"+GetRefferalcreatedmessage);
						Reporter.log("api/v2/referral");
						Reporter.log("statusCode 200");
						
						Reporter.log("User retrieve refferal created data sucessfully");
	//Activity Tab get posts
						String getDirectRefferalActivityfillter = given().log().all().headers("Content-Type","application/json").param("feedType", "activity")
								.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail).
								when().get("api/v2/referral").then().log().all().assertThat().statusCode(200).extract().response().asString();
								System.out.println(getDirectRefferalActivityfillter);
								
								JsonPath pgA=new JsonPath(getDirectRefferalActivityfillter);
								String GetRefferalactivitymessage=pgA.get("message");
									System.out.println("Postactivityfiltermessage"+GetRefferalactivitymessage);
									Reporter.log("api/v2/referral");
									Reporter.log("statusCode 200");
									
									Reporter.log("User retrieve refferal Activity data sucessfully");
			
									
									
//closed deal by Buyer
	String closedeal = given().log().all().headers("Content-Type","application/json")
											.headers("Authorization", a.buyertoken).header("email",a.buyermail).
											body("{\r\n"
													+ "  \"status\": \"close\",\r\n"
													+ "  \"reason\": \"good\",\r\n"
													+ "  \"closeDeal\": [\r\n"
													+ "    {\r\n"
													+ "      \"dealClosedBy\": \"buyer\",\r\n"
													+ "      \"referrerList\": [\r\n"
													+ "        {\r\n"
													+ "          \"referrerName\": \""+ReferrerName+"\",\r\n"
													+ "          \"userId\": \""+ReferrerUserid+"\",\r\n"
													+ "          \"image\": \"\"\r\n"
													+ "        }\r\n"
													+ "      ],\r\n"
													+ "      \"businessId\": \""+a.Businessid+"\",\r\n"
													+ "      \"businessName\": \""+a.BusinessName+"\",\r\n"
													+ "      \"currencyType\": \"USD\",\r\n"
													+ "      \"businessValue\": \"100\",\r\n"
													+ "      \"businessImage\": \"\"\r\n"
													+ "    }\r\n"
													+ "  ]\r\n"
													+ "}")
										.when().patch("/api/v2/referral/closeDeal?id="+Directreferralid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
									System.out.println(closedeal);
									JsonPath cdeal=new JsonPath(closedeal);
								    String Closedealbuyermessage=cdeal.get("message");
										Assert.assertEquals("SUCCESS",Closedealbuyermessage );
										Reporter.log("api/v2/referral/closeDeal");
										Reporter.log("statusCode 200");
									
									Reporter.log("Buyer Informed Deal closer Sucessfully");								
		//Reveal Buyer
		//walletapi
		String TranstionsId = given().log().all().headers("Content-Type","application/json").header("email",a.sellermail)
											.body("{\r\n"
													+ "    \"referralId\": \""+Directreferralid+"\",\r\n"
													+ "    \"businessId\": \""+a.Businessid+"\",\r\n"
													+ "    \"amount\": \"0\",\r\n"
													+ "    \"type\": \"REVEAL\",\r\n"
													+ "    \"toUserID\": [\r\n"
													+ "        \""+ReferrerUserid+"\"\r\n"
													+ "    ]\r\n"
													+ "}")
											.headers("Authorization", a.SellerToken)
											.when().post("/api/v2/wallet/transfer-curd").then().assertThat().statusCode(200).extract().response().asString();
											System.out.println(TranstionsId);
											
											JsonPath jubt=new JsonPath(TranstionsId);
											String wallettransfer=jubt.get("message");
											String TransactionIdforreveal=jubt.get("data[0].transaction._id");
											System.out.println(TransactionIdforreveal);
											
											Assert.assertEquals("SUCCESS",wallettransfer );
											
											Reporter.log("Endpoint :/api/v2/wallet/transfer-curd");
									        Reporter.log("StatusCode :200");
											Reporter.log("User send reward to referrer sucessfully");
											
					
	//revealbuyer
	
	String RevealBuyer = given().log().all().headers("Content-Type","application/json").header("email",a.sellermail)
			.body("{\r\n"
					+ "  \"transactionId\": [\r\n"
					+ "    \""+TransactionIdforreveal+"\"\r\n"
					+ "  ],\r\n"
					+ "  \"id\": \""+Directreferralid+"\",\r\n"
					+ "  \"sellerId\": \""+a.Businessid+"\"\r\n"
					+ "}")
			.headers("Authorization", a.SellerToken)
			.when().post("/api/v2/referral/revealBuyer").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(RevealBuyer);
			
			JsonPath jur=new JsonPath(RevealBuyer);
			String revealbuyermessage=jur.get("message");
			String buyerIdId=jur.get("data[0].buyer.ref_id._id");
			
			Assert.assertEquals("SUCCESS",revealbuyermessage );
			
			Reporter.log("Endpoint :/api/v2/referral/revealBuyer");
	        Reporter.log("StatusCode :200");
			Reporter.log("User send reward to referrer sucessfully");
//close deal by seller
		/*	String sellerclosedeal = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.SellerToken).header("email",a.sellermail).param("id",Directreferralid).
					body("{\r\n"
							+ "  \"status\": \"close\",\r\n"
							+ "  \"reason\": \"good\",\r\n"
							+ "  \"closeDeal\": [\r\n"
							+ "    {\r\n"
							+ "      \"dealClosedBy\": \"seller\",\r\n"
							+ "      \"referrerList\": [\r\n"
							+ "        {\r\n"
							+ "          \"referrerName\": \""+ReferrerName+"\",\r\n"
							+ "          \"userId\": \""+ReferrerUserid+"\",\r\n"
							+ "          \"image\": \"\"\r\n"
							+ "        }\r\n"
							+ "      ],\r\n"
							+ "      \"businessId\": \""+a.Businessid+"\",\r\n"
							+ "      \"businessName\": \""+a.BusinessName+"\",\r\n"
							+ "      \"currencyType\": \"USD\",\r\n"
							+ "      \"businessValue\": \"100\",\r\n"
							+ "      \"businessImage\": \"\"\r\n"
							+ "    }\r\n"
							+ "  ]\r\n"
							+ "}")
				.when().patch("/api/v2/referral/closeDeal?id="+Directreferralid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
			
			JsonPath cselldeal=new JsonPath(sellerclosedeal);
		    String Closedealsellermessage=cselldeal.get("message");
				Assert.assertEquals("SUCCESS",Closedealsellermessage );
				Reporter.log("api/v2/referral/closeDeal");
				Reporter.log("statusCode 200");
			
			Reporter.log("seller Informed Deal closer Sucessfully");	*/
	//closedbusiness (reward)
			
//ClosedReward
			String ClosedDealsendreward = given().log().all().headers("Content-Type","application/json").header("email",a.sellermail)
					.body("{\r\n"
							+ "    \"referralId\": \""+Directreferralid+"\",\r\n"
							+ "    \"businessId\": \""+a.Businessid+"\",\r\n"
							+ "    \"amount\": \"0\",\r\n"
							+ "    \"type\": \"CLOSEDEAL\",\r\n"
							+ "    \"toUserID\": [\r\n"
							+ "        \""+ReferrerUserid+"\"\r\n"
							+ "    ],\r\n"
							+ "    \"toBuyer\": [\r\n"
							+ "        \""+Personalbuyerdirect+"\"\r\n"
							+ "    ]\r\n"
							+ "}")
					.headers("Authorization", a.SellerToken)
					.when().post("/api/v2/wallet/transfer-curd").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(ClosedDealsendreward);
					
					JsonPath jurclose=new JsonPath(ClosedDealsendreward);
					String closeddealmessage=jurclose.get("message");
					//String buyerIdId=jur.get("data[0].buyer.ref_id._id");
					
					Assert.assertEquals("SUCCESS",closeddealmessage );
					
					Reporter.log("Endpoint :/api/v2/wallet/transfer-curd");
			        Reporter.log("StatusCode :200");
					Reporter.log("User send reward to referrer and buyer sucessfully");
			//reportcloser
					String Reportclosure=given().log().all().headers("Content-Type","application/json")
							.headers("Authorization", a.buyertoken).header("email",a.buyermail).body("{\r\n"
									+ "  \"reportedClosure\": [\r\n"
									+ "    {\r\n"
									+ "      \"closedBy\": \"seller\",\r\n"
									+ "      \"status\": \"close\",\r\n"
									+ "      \"reason\": \"good\",\r\n"
									+ "      \"businessId\": \""+a.Businessid+"\"\r\n"
									+ "    }\r\n"
									+ "  ]\r\n"
									+ "}").
						when().patch("/api/v2/referral/reportedClosure?id="+Directreferralid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
					JsonPath RClosure=new JsonPath(Reportclosure);
				    String Closuremessage=RClosure.get("message");  
						Assert.assertEquals("SUCCESS",Closuremessage );
						Reporter.log("/api/v2/referral/reportedClosure");
						Reporter.log("statusCode 200");
					
					
		
			String getClosedBusinee = given().log().all().headers("Content-Type","application/json").param("skip","0").param("limit", "3").param("businessId", a.Businessid)
						.param("type", "rewarded").headers("Authorization", a.SellerToken).header("email",a.sellermail).
															when().get("/api/v2/referral/closedBusiness").then().log().all().assertThat().statusCode(200).extract().response().asString();
															System.out.println(getClosedBusinee);
															
															JsonPath getclosedBmess=new JsonPath(getClosedBusinee);
										   			         String getCbusinessmessage=getclosedBmess.get("message");
																Assert.assertEquals("SUCCESS",getCbusinessmessage );

															Reporter.log("/api/v2/referral/closedBusiness");
									    					Reporter.log("statusCode 200");
									    	    			Reporter.log("Workcenter closed Business rewarded deatails retrieve sucessfully");
					
	}
	
						
			
}

