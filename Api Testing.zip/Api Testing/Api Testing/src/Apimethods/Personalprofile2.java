package Apimethods;

public class Personalprofile2 {

}
