package Apimethods;

import static io.restassured.RestAssured.given;

import java.io.File;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class KYC {
	AuthorizationToken a=new AuthorizationToken();
	Businessprofile B=new Businessprofile();
	@Test(priority=1)
	public void Kyc(){
        File aadharimage=new File("C:\\Users\\CURD Automation\\Downloads\\addressProofFront.png");

	Response VerifyAadhar = given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("type","Aadhaar").multiPart("email",a.mail).multiPart("uid","666683161459")
			.multiPart("image",aadharimage)
			.when().post("/api/v2/kyc/verifyAadhaar");
			 String Verifykycid = VerifyAadhar.then().contentType(ContentType.JSON).extract().path("data.id");

			 String Kycverifymessage = VerifyAadhar.then().contentType(ContentType.JSON).extract().path("message");
			 String Kycresult = VerifyAadhar.then().contentType(ContentType.JSON).extract().path("data.response.result.verified");

			Assert.assertEquals("SUCCESS",Kycverifymessage );
			Assert.assertEquals("true",Kycresult );

			Reporter.log("Endpoint :/api/v2/kyc/verifyAadhaar");
	        Reporter.log("StatusCode :200");
			Reporter.log("User did kyc with aadhar sucessfully");
}
	@Test(priority=2)
	public void verifypanprof(){
		
		String getpersonaldetailsforReferrer1 = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail)
				.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(getpersonaldetailsforReferrer1);
				JsonPath Cr1=new JsonPath(getpersonaldetailsforReferrer1);
		        String PersonalprofIdforRefferer1 = Cr1.get("data._id");
		        

	Response VerifyPan = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).body("{\r\n"
					+ "  \"name\": \"VIKASH BHARTI\",\r\n"
					+ "  \"panId\": \"EQEPB6205E\",\r\n"
					+ "}")
			.when().post("/api/v2/kyc/verifyPan");
			 String Verifypanid = VerifyPan.then().contentType(ContentType.JSON).extract().path("data.id");

			 String Kycverifypanmessage = VerifyPan.then().contentType(ContentType.JSON).extract().path("message");
			 String Kycpanresult = VerifyPan.then().contentType(ContentType.JSON).extract().path("data.response.result.verified");

			Assert.assertEquals("SUCCESS",Kycverifypanmessage );
			Assert.assertEquals("true",Kycpanresult );

			Reporter.log("Endpoint :/api/v2/kyc/verifyPan");
	        Reporter.log("StatusCode :200");
			Reporter.log("User did kyc with pan sucessfully");
}
	@Test(priority=3)
	public void VerifyBusinessPan(){
        File Businesspanimage=new File("C:\\Users\\CURD Automation\\Downloads\\Business Pan-Card (1).jpg");

	Response VerifyAadhar = given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("name","JEEVAN MITRA EDUCATIONAL SOCEITY").multiPart("panId","AACTJ6273C")
			.multiPart("file",Businesspanimage).multiPart("businessId",B.BusinessProfileId)
			.when().post("/api/v2/kyc/verifybusinessPan");
			 String Verifykycid = VerifyAadhar.then().contentType(ContentType.JSON).extract().path("data.id");

			 String Kycverifymessage = VerifyAadhar.then().contentType(ContentType.JSON).extract().path("message");
			 String Kycresult = VerifyAadhar.then().contentType(ContentType.JSON).extract().path("data.response.result.verified");

			Assert.assertEquals("SUCCESS",Kycverifymessage );
			Assert.assertEquals("true",Kycresult );

			Reporter.log("Endpoint :/api/v2/kyc/verifybusinessPan");
	        Reporter.log("StatusCode :200");
			Reporter.log("User did kyb with businesspan sucessfully");
}
	@Test(priority=4)
	public void getKyc() {
		
			String getKyc = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("/api/v2/kyc/getKyc").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getKyc);
					
					JsonPath getkycop=new JsonPath(getKyc);
					
									String getKycmessage=getkycop.get("message");
									System.out.println("businessgetapi message"+getKycmessage);
									Assert.assertEquals("SUCCESS",getKycmessage );

					Reporter.log("Endpoint :/api/v2/kyc/getKyc");
			        Reporter.log("StatusCode :200");
						Reporter.log("User Retrieve KYC data sucessful");
						}
	
	@Test(priority=5)
	public void getKYB() {
		
			String getKyb = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("businessId",B.BusinessProfileId)
					.when().get("/api/v2/kyc/getKyb").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getKyb);
					
					JsonPath getkybop=new JsonPath(getKyb);
					
									String getKyBmessage=getkybop.get("message");
									System.out.println("businessgetapi message"+getKyBmessage);
									Assert.assertEquals("SUCCESS",getKyBmessage );

					Reporter.log("Endpoint :/api/v2/kyc/getKyb");
			        Reporter.log("StatusCode :200");
						Reporter.log("User Retrieve KYB data sucessful");
						}
	@Test(priority=6)
	public void VerifyEmrates(){
		String emiratesIdNumber="784198526036961";
        File EmratesId=new File("C:\\Users\\CURD Automation\\Downloads\\WhatsApp Image 2024-02-19 at 11.33.03 AM.jpeg");

	Response BusinessEmrates = given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("emiratesIdNumber",emiratesIdNumber).multiPart("dateOfBirth","1985-03-30")
			.multiPart("file",EmratesId).multiPart("idType","Id Card").multiPart("currentNationality","india").multiPart("country","United Arab Emirates")
			.when().post("/api/v2/kyc/verifyEmiratesId");
			 String VerifykycemrateresEid = BusinessEmrates.then().contentType(ContentType.JSON).extract().path("data.eidCardNumber");

			 String Kybemiratesmessage = BusinessEmrates.then().contentType(ContentType.JSON).extract().path("message");
			 String EmratesIdnumber = BusinessEmrates.then().contentType(ContentType.JSON).extract().path("data.emiratesIdNumber");

			Assert.assertEquals("SUCCESS",Kybemiratesmessage );
			Assert.assertEquals("emiratesIdNumber", EmratesIdnumber);

			Reporter.log("Endpoint :/api/v2/kyc/verifyEmiratesId");
	        Reporter.log("StatusCode :200");
			Reporter.log("User did kyb with businesspan sucessfully");
}
	@Test(priority=7)
	public void VerifyTradelicense(){

	Response BusinessTradeli= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).body("{\r\n"
					+ "  \"businessId\": \""+B.BusinessProfileId1+"\"\",\r\n"
					+ "  \"LicenseNumber\": \"631359\",\r\n"
					+ "  \"businessName\": \"NINE SQUARE GENERAL TRADING L.L.C\",\r\n"
					+ "  \"minMatchScore\": \"0.1\"\r\n"
					+ "}")
			.when().post("/api/v2/kyc/verifyTradeLicense");
			 String VerifykybTradesid = BusinessTradeli.then().contentType(ContentType.JSON).extract().path("data.id");

			 String KybTrademessage = BusinessTradeli.then().contentType(ContentType.JSON).extract().path("message");
			 String Traderesult = BusinessTradeli.then().contentType(ContentType.JSON).extract().path("data.response.result.verified");

			Assert.assertEquals("SUCCESS",KybTrademessage );
			Assert.assertEquals("true",Traderesult);

			Reporter.log("Endpoint :/api/v2/kyc/verifyTradeLicense");
	        Reporter.log("StatusCode :200");
			Reporter.log("User did kyb with businesspan sucessfully");
}	
	
}
