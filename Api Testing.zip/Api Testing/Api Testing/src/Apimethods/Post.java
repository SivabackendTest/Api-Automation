package Apimethods;

import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

import java.io.File;
public class Post {
	AuthorizationToken a=new AuthorizationToken();
	public String PostId;

     @Test(priority=1)
     
	public void Post() {
 		RestAssured.baseURI="http://hcpdev.curd.network:3000";

		String getpersonalcreatepostdetails = given().log().all().headers("Content-Type","application/json")
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
		.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getpersonalcreatepostdetails);
		JsonPath cp=new JsonPath(getpersonalcreatepostdetails);
        String PersonalprofIdforpost = cp.get("data._id");
        System.out.println("PersonalUserId "+PersonalprofIdforpost);

		  Response CreatePost = given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
					.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","my_network")
					.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
					.multiPart("createdBy.ref_id",PersonalprofIdforpost).multiPart("createdBy.ref_model","personal_profile").multiPart("isRepost","false")
					.when().post("api/v2/post/create");
					/*.then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(CreatePost);
				JsonPath Fs1=new JsonPath(CreatePost);

					String Postmessage=Fs1.get("message");
					String PostId=Fs1.get("data._id");
					System.out.println("PostId "+PostId);
						System.out.println("Postmessage"+Postmessage);
						Reporter.log("api/v2/post/create");
						Reporter.log("statusCode 200");
						Reporter.log("User Create post sucessfully");*/
			
		 PostId = CreatePost.then().contentType(ContentType.JSON).extract().path("data._id");
		 System.out.println(PostId);
						
						 String View=given().log().all().headers("Content-Type","application/json").header("email",a.mail)
									.headers("Authorization", a.AuthorizationToken)
									.when().post("/api/v2/post/viewPost?postId="+PostId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
							System.out.println(View);
							JsonPath Fs2=new JsonPath(View);

							String PostViewpost=Fs2.get("message");
						    System.out.println(PostViewpost);
						    
						
}
     @Test(priority=5)
     public void PostWithPhoto() {
  		RestAssured.baseURI="http://hcpdev.curd.network:3000";
        File image2=new File("C:\\Users\\CURD Automation\\Downloads\\AutomationTestImage.jpg");

 		String getpersonalcreatepostimg = given().log().all().headers("Content-Type","application/json")
 		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
 		.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
 		System.out.println(getpersonalcreatepostimg);
 		JsonPath cp=new JsonPath(getpersonalcreatepostimg);
         String PersonalprofIdforpostimg = cp.get("data._id");
         System.out.println("PersonalUserId "+PersonalprofIdforpostimg);

 		 String CreatePostimg=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
 					.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","my_network")
 					.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
 					.multiPart("createdBy.ref_id",PersonalprofIdforpostimg).multiPart("createdBy.ref_model","personal_profile")
 					.multiPart("isRepost","false").multiPart("image",image2)
 					.when().post("api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
 			System.out.println(CreatePostimg);
 				JsonPath Fs1=new JsonPath(CreatePostimg);

 					String Postmessage=Fs1.get("message");
 					String PostId=Fs1.get("data._id");
 					System.out.println("PostId "+PostId);
 						System.out.println("Postmessage"+Postmessage);
 						Reporter.log("api/v2/post/create");
 						Reporter.log("statusCode 200");
 						Reporter.log("User Create post sucessfully");
 			
     }
     
     @Test(priority=6)
     public void PostWithVideo() {
  		RestAssured.baseURI="http://hcpdev.curd.network:3000";
        File image2=new File("C:\\Users\\CURD Automation\\Downloads\\AutomationTestImage.jpg");

 		String getpersonalcreatepostvideo= given().log().all().headers("Content-Type","application/json")
 		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
 		.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
 		System.out.println(getpersonalcreatepostvideo);
 		JsonPath cp=new JsonPath(getpersonalcreatepostvideo);
         String PersonalprofIdforpostvide = cp.get("data._id");
         System.out.println("PersonalUserId "+PersonalprofIdforpostvide);
 		File patchvideo1=new File("C:\\Users\\CURD Automation\\Downloads\\SampleVideo_1280x720_5mb.mp4");

         
 		 String CreatePostVideo=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
 					.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","my_network")
 					.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
 					.multiPart("createdBy.ref_id",PersonalprofIdforpostvide).multiPart("createdBy.ref_model","personal_profile")
 					.multiPart("isRepost","false").multiPart("video",patchvideo1)
 					.when().post("api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
 			System.out.println(CreatePostVideo);
 				JsonPath Fs3=new JsonPath(CreatePostVideo);

 					String Postmessage=Fs3.get("message");
 					String PostId5=Fs3.get("data._id");
 					System.out.println("PostId "+PostId5);
 						System.out.println("Postmessage"+Postmessage);
 						Reporter.log("api/v2/post/create");
 						Reporter.log("statusCode 200");
 						Reporter.log("User Create post with Video sucessfully");
 						
 						String removePost = given().log().all().headers("Content-Type","application/json")
								.headers("Authorization", a.AuthorizationToken)
								.header("email",a.mail)
								.when().post("/api/v2/post/remove?postId="+PostId5+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
								System.out.println(removePost);
 			
     }
     
     @Test(priority=7)
     public void PostWithpdf() {
  		RestAssured.baseURI="http://hcpdev.curd.network:3000";
        File file2=new File("C:\\Users\\CURD Automation\\Downloads\\sample-1.pdf");

 		String getpersonalcreatepostvideo= given().log().all().headers("Content-Type","application/json")
 		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
 		.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
 		System.out.println(getpersonalcreatepostvideo);
 		JsonPath cp=new JsonPath(getpersonalcreatepostvideo);
         String PersonalprofIdforpostvide = cp.get("data._id");
         System.out.println("PersonalUserId "+PersonalprofIdforpostvide);

         
 		 String CreatePostpdf=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
 					.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","my_network")
 					.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
 					.multiPart("createdBy.ref_id",PersonalprofIdforpostvide).multiPart("createdBy.ref_model","personal_profile")
 					.multiPart("isRepost","false").multiPart("pdf",file2)
 					.when().post("api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
 			System.out.println(CreatePostpdf);
 				JsonPath Fs4=new JsonPath(CreatePostpdf);

 					String Postmessage=Fs4.get("message");
 					String PostId=Fs4.get("data._id");
 					System.out.println("PostId "+PostId);
 						System.out.println("Postmessage"+Postmessage);
 						Reporter.log("api/v2/post/create");
 						Reporter.log("statusCode 200");
 						Reporter.log("User Create post with pdf sucessfully");
 			
     }

						//getpost
						@Test(priority=2)
						public void Getpost() {
						String getPost = given().log().all().headers("Content-Type","application/json")
								.headers("Authorization", a.AuthorizationToken)
								.header("email",a.mail).body("{\r\n"
										+ "  \"postType\" :\"social\"\r\n"
										+ "}")
								.when().post("api/v2/post/getPost").then().log().all().assertThat().statusCode(200).extract().response().asString();
								System.out.println(getPost);
								
								JsonPath pgs=new JsonPath(getPost);
								String Getmessage=pgs.get("message");
								
									System.out.println("Postmessage"+Getmessage);
									Reporter.log("api/v2/post/create");
									Reporter.log("statusCode 200");
									Reporter.log("User retrieve data sucessfully");
						}	
						@Test(priority=3)
						public void Updatepost() {
							String getpersonaldetailsforupdate = given().log().all().headers("Content-Type","application/json")
									.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
									.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
									System.out.println(getpersonaldetailsforupdate);
									JsonPath cp2=new JsonPath(getpersonaldetailsforupdate);
							        String PersonalprofIdforupdatepost = cp2.get("data._id");
							        System.out.println("PersonalupdateUserId "+PersonalprofIdforupdatepost);

									/* String CreatePostupdate=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
												.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","my_network")
												.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
												.multiPart("createdBy.ref_id",PersonalprofIdforupdatepost).multiPart("createdBy.ref_model","personal_profile").multiPart("isRepost","false")
												.when().post("api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
										System.out.println(CreatePostupdate);
											JsonPath Fs2=new JsonPath(CreatePostupdate);

												String Postmessage=Fs2.get("message");
												String PostIdupdate=Fs2.get("data._id");
												System.out.println("PostId "+PostIdupdate);
													System.out.println("Postmessage"+Postmessage);
													Reporter.log("User Create post sucessfully");*/		
							
							
							
							
								
					//Update Post
								 String UpdatePost=given().log().all().headers("Content-Type","application/json").param("id",PostId)
											.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{ \r\n"
													+ " \"postType\" : \"social\",\r\n"
													+ " \"visibleTo\" : \"everyone\",\r\n"
													+ " \"caption\":\"dell\" \r\n"
													+ "}")
											.when().patch("api/v2/post/update").then().log().all().assertThat().statusCode(200).extract().response().asString();
											System.out.println(UpdatePost);
										JsonPath up=new JsonPath(UpdatePost);

											String updatemessage=up.get("message");
											
												System.out.println("Postmessage"+updatemessage);
												Reporter.log("User update sucessfully");
						}
												
				//Removepost
		/*String removePost = given().log().all().headers("Content-Type","application/json")
														.headers("Authorization", a.AuthorizationToken)
														.header("email",mail).param("id", PostId)
														.when().post("api/v2/post/remove").then().log().all().assertThat().statusCode(200).extract().response().asString();
														System.out.println(removePost);*/
																			
												
												
					//Delete Post
		@Test(priority=4)
		public void Deletepost() {
			
			String getpersonaldetailsDelete = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getpersonaldetailsDelete);
					JsonPath cp3=new JsonPath(getpersonaldetailsDelete);
			        String PersonalprofIdfordeletepost = cp3.get("data._id");
			        System.out.println("PersonalupdateUserId "+PersonalprofIdfordeletepost);

					 /*String CreatePostfordelete=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
								.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","my_network")
								.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
								.multiPart("createdBy.ref_id",PersonalprofIdfordeletepost).multiPart("createdBy.ref_model","personal_profile").multiPart("isRepost","false")
								.when().post("api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
						System.out.println(CreatePostfordelete);
							JsonPath Fs3=new JsonPath(CreatePostfordelete);

								String Postmessage=Fs3.get("message");
								String PostIdDelete=Fs3.get("data._id");
								System.out.println("PostId "+PostIdDelete);
									System.out.println("Postmessage"+Postmessage);*/
										
												
		String deletePost = given().log().all().headers("Content-Type","application/json").param("id", PostId)
											.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
											.when().delete("api/v2/post/delete").then().log().all().assertThat().statusCode(200).extract().response().asString();
											System.out.println(deletePost);
											Reporter.log("api/v2/post/create");
											Reporter.log("statusCode 200");
											Reporter.log("Sucessfully Post deleted");											
				    				
	}

}
