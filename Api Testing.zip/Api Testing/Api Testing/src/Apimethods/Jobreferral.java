package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Jobreferral {
	
	AuthorizationToken a=new AuthorizationToken();

	@Test(priority=1)
	public void Refferal() throws InterruptedException {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
		String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.buyertoken).header("email",a.buyermail)
				.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(getpersonaldetails);
				JsonPath Cr=new JsonPath(getpersonaldetails);
		        String PersonalprofIdforRefferal = Cr.get("data._id");
		        System.out.println("PersonalUserId "+PersonalprofIdforRefferal);
				String getpersonaldetailscreatedirectjobref = given().log().all().headers("Content-Type","application/json")
						.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail)
						.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
						System.out.println(getpersonaldetailscreatedirectjobref);
						JsonPath Crefjob=new JsonPath(getpersonaldetailscreatedirectjobref);
				        String PersonalprofIdforjobDirectrefe = Crefjob.get("data._id");
				       String ReferrerUserid=Crefjob.get("data.userId");
				       String ReferrerName=Crefjob.get("data.name");
				        System.out.println(PersonalprofIdforjobDirectrefe);
		// Referral create
		String RefferalPost=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.buyermail)
				.headers("Authorization", a.buyertoken).multiPart("postType","referral").multiPart("visibleTo","my_network")
				.multiPart("caption","I need laptop").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
				.multiPart("createdBy.ref_id",PersonalprofIdforRefferal).multiPart("createdBy.ref_model","personal_profile")
				.multiPart("referralExpiry","2024-06-30 11:55").multiPart("industry","3D Printing").multiPart("lat","16.87")
				.multiPart("long","82.78").multiPart("address","Banglore").multiPart("lookingForJob","true")
				.when().post("api/v2/referral").then().log().all().assertThat().statusCode(200).extract().response().asString();
				System.out.println(RefferalPost);
			JsonPath Rsj=new JsonPath(RefferalPost);
	         String Refferalmessage=Rsj.get("message");
				String RefferalId=Rsj.get("data._id");
				System.out.println("RefferalId "+RefferalId);
				Assert.assertEquals("SUCCESS",Refferalmessage );

					System.out.println("Refferalmessage"+Refferalmessage);
					Reporter.log("api/v2/referral");
					Reporter.log("statusCode 200");
					Reporter.log("User Create refferal post sucessfully");
					String referbusinessComment=given().log().all().headers("Content-Type","application/json")
	    	    			.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail)
	    	    			.body("{\r\n"
	    	    					+ "  \"createdBy\": {\r\n"
	    	    					+ "    \"ref_id\": \""+PersonalprofIdforRefferal+"\",\r\n"
	    	    					+ "    \"ref_model\": \"personal_profile\"\r\n"
	    	    					+ "  },\r\n"
	    	    					+ "  \"mention\":[\r\n"
	    	    					+ "    {\r\n"
	    	    					+ "    \"index\": 0,\r\n"
	    	    					+ "    \"profileId\": \""+a.Businessid+"\",\r\n"
	    	    					+ "    \"profileType\": \"business_profile\"\r\n"
	    	    					+ "}\r\n"
	    	    					+ "],\r\n"
	    	    					+ "  \"text\":\"hello\",\r\n"
	    	    					+ "\"feedId\": \""+RefferalId+"\",\r\n"
	    	    					+ "\"feedType\": \"referral\",\r\n"
	    	    					+ "\"postType\": \"referral\"\r\n"
	    	    					
	    	    					+ "}")	    	    			
	    	    			.when().post("api/v2/comment/").then().log().all().assertThat().statusCode(200).extract().response().asString();
	    	    			System.out.println(referbusinessComment);
	    	    			JsonPath referB=new JsonPath(referbusinessComment);
	   			         String Referecommentmessage=referB.get("message");
	   			         String CommentId = referB.get("data._id");
							Assert.assertEquals("SUCCESS",Referecommentmessage );


	    	    			Reporter.log("api/v2/comment/");
	    					Reporter.log("statusCode 200");
	    	    			Reporter.log("Business refer to Buyer Sucessfully");			
					
	//deal inform by buyer
	    	    			String closedeal = given().log().all().headers("Content-Type","application/json")
									.headers("Authorization", a.buyertoken).header("email",a.buyermail).
									body("{\r\n"
											+ "  \"status\": \"close\",\r\n"
											+ "  \"reason\": \"good\",\r\n"
											+ "  \"closeDeal\": [\r\n"
											+ "    {\r\n"
											+ "      \"dealClosedBy\": \"buyer\",\r\n"
											+ "      \"referrerList\": [\r\n"
											+ "        {\r\n"
											+ "          \"referrerName\": \""+ReferrerName+"\",\r\n"
											+ "          \"userId\": \""+ReferrerUserid+"\",\r\n"
											+ "          \"image\": \"\"\r\n"
											+ "        }\r\n"
											+ "      ],\r\n"
											+ "      \"businessId\": \""+a.Businessid+"\",\r\n"
											+ "      \"businessName\": \""+a.BusinessName+"\",\r\n"
											+ "      \"currencyType\": \"USD\",\r\n"
											+ "      \"businessValue\": \"100\",\r\n"
											+ "      \"businessImage\": \"\"\r\n"
											+ "    }\r\n"
											+ "  ]\r\n"
											+ "}")
								.when().patch("/api/v2/referral/closeDeal?id="+RefferalId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
							System.out.println(closedeal);
							JsonPath cdeal=new JsonPath(closedeal);
						    String Closedealbuyermessage=cdeal.get("message");
								Assert.assertEquals("SUCCESS",Closedealbuyermessage );
								Reporter.log("api/v2/referral/closeDeal");
								Reporter.log("statusCode 200");
							
							Reporter.log("Buyer Informed Deal closer Sucessfully");	
		// Reveal buyer
							//walletapi
							String TranstionsId = given().log().all().headers("Content-Type","application/json").header("email",a.sellermail)
																.body("{\r\n"
																		+ "    \"referralId\": \""+RefferalId+"\",\r\n"
																		+ "    \"businessId\": \""+a.Businessid+"\",\r\n"
																		+ "    \"amount\": \"0\",\r\n"
																		+ "    \"type\": \"REVEAL\",\r\n"
																		+ "    \"toUserID\": [\r\n"
																		+ "        \""+ReferrerUserid+"\"\r\n"
																		+ "    ]\r\n"
																		+ "}")
																.headers("Authorization", a.SellerToken)
																.when().post("/api/v2/wallet/transfer-curd").then().assertThat().statusCode(200).extract().response().asString();
																System.out.println(TranstionsId);
																
																JsonPath jubt=new JsonPath(TranstionsId);
																String wallettransfer=jubt.get("message");
																String TransactionIdforreveal=jubt.get("data[0].transaction._id");
																System.out.println(TransactionIdforreveal);
																
																Assert.assertEquals("SUCCESS",wallettransfer );
																
																Reporter.log("Endpoint :/api/v2/wallet/transfer-curd");
														        Reporter.log("StatusCode :200");
																Reporter.log("User send reward to referrer sucessfully");
																
										
						//revealbuyer
						
						String RevealBuyer = given().log().all().headers("Content-Type","application/json").header("email",a.sellermail)
								.body("{\r\n"
										+ "  \"transactionId\": [\r\n"
										+ "    \""+TransactionIdforreveal+"\"\r\n"
										+ "  ],\r\n"
										+ "  \"id\": \""+RefferalId+"\",\r\n"
										+ "  \"sellerId\": \""+a.Businessid+"\"\r\n"
										+ "}")
								.headers("Authorization", a.SellerToken)
								.when().post("/api/v2/referral/revealBuyer").then().assertThat().statusCode(200).extract().response().asString();
								System.out.println(RevealBuyer);
								
								JsonPath jur=new JsonPath(RevealBuyer);
								String revealbuyermessage=jur.get("message");
								String buyerIdId=jur.get("data[0].buyer.ref_id._id");
								
								Assert.assertEquals("SUCCESS",revealbuyermessage );
								
								Reporter.log("Endpoint :/api/v2/referral/revealBuyer");
						        Reporter.log("StatusCode :200");
								Reporter.log("User send reward to referrer sucessfully");
								String Reportclosure=given().log().all().headers("Content-Type","application/json")
										.headers("Authorization", a.SellerToken).header("email",a.sellermail).body("{\r\n"
												+ "  \"reportedClosure\": [\r\n"
												+ "    {\r\n"
												+ "      \"closedBy\": \"seller\",\r\n"
												+ "      \"status\": \"close\",\r\n"
												+ "      \"reason\": \"close\",\r\n"
												+ "      \"businessId\": \""+a.Businessid+"\"\r\n"
												+ "    }\r\n"
												+ "  ]\r\n"
												+ "}").
									when().patch("/api/v2/referral/reportedClosure?id="+RefferalId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
								JsonPath RClosure=new JsonPath(Reportclosure);
							    String Closuremessage=RClosure.get("message");  
									Assert.assertEquals("SUCCESS",Closuremessage );
									Reporter.log("/api/v2/referral/reportedClosure");
									Reporter.log("statusCode 200");							
								

}
}