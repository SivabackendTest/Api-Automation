package Apimethods;

import static io.restassured.RestAssured.given;

import java.io.File;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Product {
	public AuthorizationToken token;
	public String ProductId;
	AuthorizationToken a=new AuthorizationToken(); 
	Businessprofile Bp=new Businessprofile();
	Collection Cl=new Collection();
	@Test(priority=1)
	public void CreatebusinessProduct(){
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
		/*String getbusinessforProduct = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getbusinessforProduct);
		JsonPath jP4=new JsonPath(getbusinessforProduct);

			String businessidforProduction=jP4.get("data[0]._id");
			
			System.out.println("businessidcollection "+businessidforProduction);
		
		String CreateCollectionforProduct = given().log().all().headers("Content-Type","application/json")
				.header("email",a.mail).body("{\r\n"
						+ "  \"businessId\": \""+businessidforProduction+"\",\r\n"
						+ "  \"collectionName\": \"Soap\",\r\n"
						+ "  \"Description\": \"Mysore Sandle\"\r\n"
						+ "}").headers("Authorization", a.AuthorizationToken)
		.when().post("/api/v2/product/createCollection").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(CreateCollectionforProduct);
		
		JsonPath jp2=new JsonPath(CreateCollectionforProduct);

			String Collectionidforprod=jp2.get("data._id");
			String Createmessage=jp2.get("message");
			Assert.assertEquals("SUCCESS",Createmessage );
			System.out.println("businessCollectionid"+Collectionidforprod);
			   Reporter.log("Endpoint :/api/v2/product/createCollection");
		        Reporter.log("StatusCode :200");
			
			Reporter.log("Business Collection Created");*/
		 Response CreateProduct = given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
				.headers("Authorization", a.AuthorizationToken).multiPart("businessId",Bp.BusinessProfileId).multiPart("collectionId",Cl.BusinessprofileCollectionId)
				.multiPart("productName","Britaniya").multiPart("productDescription","Bisckets").multiPart("price","100")
				.multiPart("link","www.ssc.com").multiPart("keystore","Software")
				.when().post("/api/v2/product/create");
		 
		 ProductId=CreateProduct.then().contentType(ContentType.JSON).extract().path("data._id");

		 System.out.println(ProductId);
			/*JsonPath CP1=new JsonPath(CreateProduct);

				String Productmessage=CP1.get("message");
				String ProductId=CP1.get("data._id");
				System.out.println("ProductId "+ProductId);
					System.out.println("Postmessage"+Productmessage);
					Reporter.log("/api/v2/product/create");
					Reporter.log("statusCode 200");
					Reporter.log("User Create Product sucessfully");*/
						
}
	@Test(priority=2)
	public void GetCollection (){
		/*String getbusinesscollection = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getbusinesscollection);
		JsonPath jc1=new JsonPath(getbusinesscollection);

			String GetbusinessidforPsearch=jc1.get("data[0]._id");
			String UserIdforProduct= jc1.get("data[0].userId");
			System.out.println(GetbusinessidforPsearch);
			System.out.println(UserIdforProduct);
			System.out.println("businessidProduct "+GetbusinessidforPsearch);
		
		String CreateCollectionforProductSearch = given().log().all().headers("Content-Type","application/json")
				.header("email",a.mail).body("{\r\n"
						+ "  \"businessId\": \""+GetbusinessidforPsearch+"\",\r\n"
						+ "  \"collectionName\": \"Box\",\r\n"
						+ "  \"Description\": \"Lunchbox\"\r\n"
						+ "}").headers("Authorization", a.AuthorizationToken)
		.when().post("/api/v2/product/createCollection").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(CreateCollectionforProductSearch);
		
		JsonPath Gp2=new JsonPath(CreateCollectionforProductSearch);

			String Collectionidforprodsearch=Gp2.get("data._id");
			String Createmessagesearch=Gp2.get("message");
			Assert.assertEquals("SUCCESS",Createmessagesearch );
			System.out.println("businessCollectionid"+Collectionidforprodsearch);
			   Reporter.log("Endpoint :/api/v2/product/createCollection");
		        Reporter.log("StatusCode :200");
			
			Reporter.log("Business Collection Created");
		String CreateProduct=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
				.headers("Authorization", a.AuthorizationToken).multiPart("businessId",GetbusinessidforPsearch).multiPart("collectionId",Collectionidforprodsearch)
				.multiPart("productName","Britaniya").multiPart("productDescription","Bisckets").multiPart("price","100")
				.multiPart("link","www.ssc.com").multiPart("keystore","Software")
				.when().post("/api/v2/product/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(CreateProduct);
			JsonPath CP1=new JsonPath(CreateProduct);

				String Productmessage=CP1.get("message");
				String ProductId=CP1.get("data._id");
				System.out.println("ProductId "+ProductId);
					System.out.println("Postmessage"+Productmessage);
					Reporter.log("/api/v2/product/create");
					Reporter.log("statusCode 200");
					Reporter.log("User Create Product sucessfully");*/
		
						
		String getProduct = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.param("collectionId",Cl.BusinessprofileCollectionId ).param("userId", Bp.BusinessUserId).param("businessId", Bp.BusinessProfileId)
				.when().get("/api/v2/product/search").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getProduct);
		JsonPath PS1=new JsonPath(getProduct);
	    String Productretrievemessage=PS1.get("message");
		Assert.assertEquals("SUCCESS",Productretrievemessage );
			
			Reporter.log("/api/v2/product/search");
			Reporter.log("statusCode 200");
}
	@Test(priority=3)
	public void UpdateProduct (){
	
	String getbusinessforUpdateProduct = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
	System.out.println(getbusinessforUpdateProduct);
	JsonPath JU1=new JsonPath(getbusinessforUpdateProduct);

		String businessidforProduction=JU1.get("data[0]._id");
		
		System.out.println("businessidcollection "+businessidforProduction);
	
	String CreateCollectionforProduct = given().log().all().headers("Content-Type","application/json")
			.header("email",a.mail).body("{\r\n"
					+ "  \"businessId\": \""+businessidforProduction+"\",\r\n"
					+ "  \"collectionName\": \"Dell\",\r\n"
					+ "  \"Description\": \"Relieance\"\r\n"
					+ "}").headers("Authorization", a.AuthorizationToken)
	.when().post("/api/v2/product/createCollection").then().assertThat().statusCode(200).extract().response().asString();
	System.out.println(CreateCollectionforProduct);
	
	JsonPath jp2=new JsonPath(CreateCollectionforProduct);

		String Collectionidforprod=jp2.get("data._id");
		String Createmessage=jp2.get("message");
		Assert.assertEquals("SUCCESS",Createmessage );
		System.out.println("businessCollectionid"+Collectionidforprod);
		   Reporter.log("Endpoint :/api/v2/product/createCollection");
	        Reporter.log("StatusCode :200");
		
		Reporter.log("Business Collection Created");
	String CreateProduct=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			.headers("Authorization", a.AuthorizationToken).multiPart("businessId",businessidforProduction).multiPart("collectionId",Collectionidforprod)
			.multiPart("productName","Britaniya").multiPart("productDescription","Bisckets").multiPart("price","100")
			.multiPart("link","www.dfc.com").multiPart("keystore","Software")
			.when().post("/api/v2/product/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
	System.out.println(CreateProduct);
		JsonPath CP1=new JsonPath(CreateProduct);

			String Productmessage=CP1.get("message");
			String ProductId=CP1.get("data._id");
			System.out.println("ProductId "+ProductId);
				System.out.println("Postmessage"+Productmessage);
				Reporter.log("/api/v2/product/create");
				Reporter.log("statusCode 200");
				Reporter.log("User Create Product sucessfully");
		
				String UpdateProduct =given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
						.headers("Authorization", a.AuthorizationToken).multiPart("businessId",businessidforProduction).multiPart("collectionId",Collectionidforprod)
						.multiPart("productName","Brilant").multiPart("productDescription","Bisckets").multiPart("price","100")
						.multiPart("link","www.viz.com").multiPart("keystore","Software")
						.when().put("/api/v2/product/update?id="+ProductId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
				 				System.out.println(UpdateProduct);
				JsonPath uc3=new JsonPath(UpdateProduct);

					String updatemessage1=uc3.get("message");
					Assert.assertEquals("SUCCESS",updatemessage1 );
					
					
					   Reporter.log("Endpoint :/api/v2/product/updateCollection");
				        Reporter.log("StatusCode :200");
				        
				        File image1=new File("C:\\Users\\CURD Automation\\Downloads\\AutomationTestImage.jpg");
				        
				        String UpdateProductwithImage =given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
								.headers("Authorization", a.AuthorizationToken).multiPart("businessId",businessidforProduction).multiPart("collectionId",Collectionidforprod)
								.multiPart("productName","Britaniya").multiPart("productDescription","Bisckets").multiPart("price","100")
								.multiPart("link","www.ssc.com").multiPart("keystore","Software").multiPart("image",image1)
								.when().put("/api/v2/product/update?id="+ProductId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
						 				System.out.println(UpdateProductwithImage);
						JsonPath uc4=new JsonPath(UpdateProductwithImage);

							String updatemessagewithimage=uc4.get("message");
							Assert.assertEquals("SUCCESS",updatemessagewithimage );
							
							
							   Reporter.log("Endpoint :/api/v2/product/updateCollection");
						        Reporter.log("StatusCode :200");

	
}
	@Test(priority=4)
	public void DeleteProduct() {
		
		String getbusinessforDeleteProduct = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getbusinessforDeleteProduct);
		JsonPath Jd1=new JsonPath(getbusinessforDeleteProduct);

			String businessidforProductiond=Jd1.get("data[0]._id");
			
			System.out.println("businessidcollection "+businessidforProductiond);
		
		String CreateCollectionforProductd = given().log().all().headers("Content-Type","application/json")
				.header("email",a.mail).body("{\r\n"
						+ "  \"businessId\": \""+businessidforProductiond+"\",\r\n"
						+ "  \"collectionName\": \"Dell\",\r\n"
						+ "  \"Description\": \"Relieance\"\r\n"
						+ "}").headers("Authorization", a.AuthorizationToken)
		.when().post("/api/v2/product/createCollection").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(CreateCollectionforProductd);
		
		JsonPath jd3=new JsonPath(CreateCollectionforProductd);

			String Collectionidforprodd=jd3.get("data._id");
			String Createmessage=jd3.get("message");
			Assert.assertEquals("SUCCESS",Createmessage );
			System.out.println("businessCollectionid"+Collectionidforprodd);
			   Reporter.log("Endpoint :/api/v2/product/createCollection");
		        Reporter.log("StatusCode :200");
			
			Reporter.log("Business Collection Created");
		String CreateProduct=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
				.headers("Authorization", a.AuthorizationToken).multiPart("businessId",businessidforProductiond).multiPart("collectionId",Collectionidforprodd)
				.multiPart("productName","Britaniya").multiPart("productDescription","Bisckets").multiPart("price","100")
				.multiPart("link","www.dfc.com").multiPart("keystore","Software")
				.when().post("/api/v2/product/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(CreateProduct);
			JsonPath Cpd=new JsonPath(CreateProduct);

				String Productdmessage=Cpd.get("message");
				String ProductdId=Cpd.get("data._id");
				System.out.println("ProductId "+ProductdId);
					System.out.println("Postmessage"+Productdmessage);
					Reporter.log("/api/v2/product/create");
					Reporter.log("statusCode 200");
					Reporter.log("User Create Product sucessfully");
		
	String deleteproduct = given().log().all().headers("Content-Type","application/json").param("id",ProductdId )
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().delete("/api/v2/product/delete").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(deleteproduct);
			Reporter.log("Endpoint :/api/v2/product/delete");
	        Reporter.log("StatusCode :200");
			Reporter.log("Sucessfully deleted business Collection");
	
}

}