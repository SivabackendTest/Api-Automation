package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Collection {
	public AuthorizationToken token;
	Businessprofile B=new Businessprofile();
	AuthorizationToken a=new AuthorizationToken(); 	
	public String BusinessprofileCollectionId;
	@Test(priority=1)
	public void CreatebusinessCollection(){
			
			RestAssured.baseURI="http://hcpdev.curd.network:3000";
			
			
			/*String getbusinessforcollection = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getbusinessforcollection);
			JsonPath jE3=new JsonPath(getbusinessforcollection);

				String businessidforCollection=jE3.get("data[0]._id");
				
				System.out.println("businessidcollection "+businessidforCollection);*/
			
			 Response CreateCollection = given().log().all().headers("Content-Type","application/json")
					.header("email",a.mail).body("{\r\n"
							+ "  \"businessId\": \""+B.BusinessProfileId+"\",\r\n"
							+ "  \"collectionName\": \"Jwellery\",\r\n"
							+ "  \"Description\": \"Jwellery Product\"\r\n"
							+ "}").headers("Authorization", a.AuthorizationToken)
			.when().post("/api/v2/product/createCollection");
			BusinessprofileCollectionId= CreateCollection.then().contentType(ContentType.JSON).extract().path("data._id");			
			 System.out.println(BusinessprofileCollectionId);
			
			/*JsonPath jc1=new JsonPath(CreateCollection);

				String Collectionid=jc1.get("data._id");
				String Createmessage=jc1.get("message");
				Assert.assertEquals("SUCCESS",Createmessage );
				System.out.println("businessCollectionid"+Collectionid);
				   Reporter.log("Endpoint :/api/v2/product/createCollection");
			        Reporter.log("StatusCode :200");
				
				Reporter.log("Business Collection Created");*/
	}
	@Test(priority=2)
	public void GetCollection (){
		
		/*String getbusinesscollection = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getbusinesscollection);
		JsonPath jc1=new JsonPath(getbusinesscollection);

			String GetbusinessidforCollection=jc1.get("data[0]._id");
			String UserIdforcollection= jc1.get("data[0].userId");
			System.out.println(GetbusinessidforCollection);
			System.out.println(UserIdforcollection);
			System.out.println("businessidcollection "+GetbusinessidforCollection);
			
					String CreateCollection = given().log().all().headers("Content-Type","application/json")
							.header("email",a.mail).body("{\r\n"
									+ "  \"businessId\": \""+GetbusinessidforCollection+"\",\r\n"
									+ "  \"collectionName\": \"Milk\",\r\n"
									+ "  \"Description\": \"Dairy Product\"\r\n"
									+ "}").headers("Authorization", a.AuthorizationToken)
					.when().post("/api/v2/product/createCollection").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(CreateCollection);
					JsonPath jc2=new JsonPath(CreateCollection);

						String Collectionid2=jc2.get("data._id");
						System.out.println(Collectionid2);*/
						
		String getcollection = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.param("id", BusinessprofileCollectionId).param("userId", B.BusinessUserId).param("businessId", B.BusinessProfileId)
				.when().get("/api/v2/product/searchCollection").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getcollection);
		JsonPath Getc=new JsonPath(getcollection);
	    String Collectionmessage=Getc.get("message");
		Assert.assertEquals("SUCCESS",Collectionmessage );
			
			Reporter.log("/api/v2/product/searchCollection");
			Reporter.log("statusCode 200");
	}
	
	@Test(priority=4)
	public void DeleteCollection(){
		
		/*String getbusinessforcollection = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
		
		JsonPath jE3=new JsonPath(getbusinessforcollection);

			String businessidforCollection=jE3.get("data[0]._id");
			System.out.println("businessidcollection"+businessidforCollection);*/
		
		String CreateCollection = given().log().all().headers("Content-Type","application/json")
				.header("email",a.mail).body("{\r\n"
						+ "  \"businessId\": \""+B.BusinessProfileId+"\",\r\n"
						+ "  \"collectionName\": \"Jwellery\",\r\n"
						+ "  \"Description\": \"Jwellery Product\"\r\n"
						+ "}").headers("Authorization", a.AuthorizationToken)
		.when().post("/api/v2/product/createCollection").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(CreateCollection);
		JsonPath jc1=new JsonPath(CreateCollection);

			String Collectionid=jc1.get("data._id");
			
		String deleteCollection = given().log().all().headers("Content-Type","application/json").param("id",Collectionid )
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().delete("/api/v2/product/deleteCollection").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(deleteCollection);
			Reporter.log("Endpoint :/api/v2/product/deleteCollection");
	        Reporter.log("StatusCode :200");
			Reporter.log("Sucessfully deleted business Collection");

	}
	@Test(priority=3)
	public void UpdateCollection() {
		
		/*String getbusinessforupdatecollection = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
		
		JsonPath jE4=new JsonPath(getbusinessforupdatecollection);

			String businesscollectid=jE4.get("data[0]._id");
			System.out.println("businessidcollect"+businesscollectid);
		
		String CreateCollection = given().log().all().headers("Content-Type","application/json")
				.header("email",a.mail).body("{\r\n"
						+ "  \"businessId\": \""+businesscollectid+"\",\r\n"
						+ "  \"collectionName\": \"Jwellery\",\r\n"
						+ "  \"Description\": \"Jwellery Product\"\r\n"
						+ "}").headers("Authorization", a.AuthorizationToken)
		.when().post("/api/v2/product/createCollection").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(CreateCollection);
		JsonPath jc5=new JsonPath(CreateCollection);

			String Collectionidput=jc5.get("data._id");
			System.out.println(Collectionidput);*/

		
	String UpdateCollection = given().log().all().headers("Content-Type","application/json")
			.header("email",a.mail).body("{\r\n"
					+ "  \"collectionName\": \"Jwell\",\r\n"
					+ "  \"Description\": \"Jwellery Product\"\r\n"
					+ "}").headers("Authorization", a.AuthorizationToken)
	.when().put("/api/v2/product/updateCollection?id="+BusinessprofileCollectionId+"").then().assertThat().statusCode(200).extract().response().asString();
	System.out.println(UpdateCollection);
	JsonPath jc3=new JsonPath(UpdateCollection);

		String Collectionidupdate=jc3.get("data._id");
		String updatemessage=jc3.get("message");
		Assert.assertEquals("SUCCESS",updatemessage);
		
		System.out.println("businessCollectionidupdate"+Collectionidupdate);
		   Reporter.log("Endpoint :/api/v2/product/updateCollection");
	        Reporter.log("StatusCode :200");
	
	}
}