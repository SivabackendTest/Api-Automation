//package Apimethods;
//
//public class Dump {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		
//			
////			ExtentReports extents=new ExtentReports();
////			ExtentSparkReporter spark=new ExtentSparkReporter("target/Spark.html");
////			@BeforeSuite
////			public void beforeResponse() {
////				spark.config().setTheme(Theme.DARK);
////				spark.config().setDocumentTitle("ApiReport");
////				extents.attachReporter(spark);
////				
//				//PrintStream out = new PrintStream(new FileOutputStream("UseronboardingNegative.txt"));
//			    //    System.setOut(out);
//			        
////			        RequestSpecification myRequest = RestAssured.given()
////			                .filter(new ResponseLoggingFilter())
////			                .filter(new RequestLoggingFilter());
//				
//				
//				
//			//}
//			
//			AuthorizationToken a=new AuthorizationToken();
//			@Test(priority=1)
//		public void useronboarding() throws InterruptedException {
//			//public static void main(String[] args) throws MalformedURLException, URISyntaxException {
//				// TODO Auto-generated method stub
//		//given,when,then
//				//System.setProperty("webdriver.chrome.driver", "");
//			//	WebDriver driver=new ChromeDriver();
//			 
//				//RestAssured.baseURI="https://identitytoolkit.googleapis.com";
////				String bearer=given().log().all().queryParam("key","AIzaSyBnjKx9NOENM-sc13cwjVNsDVShDWsR5Hk")
////				.body("{\"email\":\"rajuoct5000@yopmail.com\",\"password\":\"Curd@123\",\"returnSecuteToken\":true}")
////				.when().post("https://identitytoolkit.googleapis.com/v1/accounts:signUp").asString();
////				JsonPath js= new JsonPath(bearer);
////				String Token = js.getString("bearer");
//		//
////				//Post-Signup
//				//Reporter.log("String date = new java.text.SimpleDateFormat(\"MM/dd/yyyy HH:mm:ss\").format(new java.util.Date (epoch*1000))");
//				String mail = "sivafeb148@yopmail.com";
//				String LocalId="A2sTiOvKgybMMa2b0COYJWWUlIs1";
//				//String name = mail.substring(0,4);
//			//	System.out.println(name);
//				//String Username = mail.substring(4,11);
//				//System.out.println(Username);
//				RestAssured.baseURI="http://hcpdev.curd.network:3000";
//				String Postsignup=given().log().all().header("Content-Type","application/json").header("email",mail)
//			.body(Payload.postsignup(mail, LocalId))
//				.when().post("/api/v2/auth/post-signup").then().log().all().assertThat().statusCode(200).extract().asString();
//				System.out.println(Postsignup);
//				JsonPath b=new JsonPath(Postsignup);
//				String path="data.email";
//				String path1="data.uid";
//					String signinEmail=b.getString(path);
//					System.out.println("email"+signinEmail);
//					String signinuid=b.getString(path1);
//					System.out.println("Uid"+signinuid);
//					Reporter.log("User signup sucessfully");
//			//	
//				//sign-in
//				//RestAssured.baseURI="http://hcpdev.curd.network:3000";
//				String Signin = given().log().all().header("Content-Type","application/json").header("email",mail).headers("Authorization", a.AuthorizationToken)
//				.body("{\r\n"
//						+ "  \"email\": \""+signinEmail+"\",\r\n"
//						+ "  \"uid\": \""+signinuid+"\",\r\n"
//						+ "  \"device\": {\r\n"
//						+ "    \"token\": \"deL5_IVSR5Sskgu40DvT3l:APA91bEvwltlTHUybBeWqzOkN1c7jr24fibJDPcY_E-HMRSOThqDzeyElo--8szEQ1NEbVOciE25IO4x8fk6skvhYFicng8IE4hHmB81bp3mrNFCY2RPfwSOo3IIlnHlbkzDP451ScDt\",\r\n"
//						+ "    \"os_sdk\": \"34\",\r\n"
//						+ "    \"os_version\": \"14\",\r\n"
//						+ "    \"isPhysicalDevice\": \"true\",\r\n"
//						+ "    \"ip\": \"124.23.24.174\",\r\n"
//						+ "    \"os_type\": \"Android\",\r\n"
//						+ "    \"app_version\": \"1.10.3\"\r\n"
//						+ "  }\r\n"
//						+ "}\r\n"
//						+ "").when().post("/api/v2/auth/post-signin").then().log().all().assertThat().statusCode(200).extract().asString();
//			
//				
//				//SendOtp
//				String sendotpresponse = given().log().all().header("Content-Type","application/json").header("Authorization", a.AuthorizationToken)
//				.header("email",mail).body("{\r\n"
//						+ "    \"email\":\""+signinEmail+"\"\r\n"
//						+ "}")
//				.when().post("api/v2/auth/verify-email").then().assertThat().
//				statusCode(200).extract().response().asString();
//				System.out.println(sendotpresponse);
//			JsonPath js=new JsonPath(sendotpresponse);
//			String path2="data.code";
//				String postcode=js.getString(path2);
//				System.out.println("code"+postcode);
////				
//					
//					//System.out.println("Enter OTP:"+otp);
//					Reporter.log("An OTP has been sent to your device, valid for the next 5 minutes");
//					
//				//verifyotp
//					String otp="112233";
//				given().log().all().header("Content-Type","application/json").header("Authorization", a.AuthorizationToken)
//				.headers("email",mail).body("{\r\n"
//						+ "    \"email\": \""+signinEmail+"\",\r\n"
//						+ "    \"otp\": \""+otp+"\",\r\n"
//						+ "    \"code\": \""+postcode+"\"\r\n"
//						+ "}")
//				.when().post("api/v2/auth/confirm-email").then().log().all().assertThat().statusCode(200);
//				Reporter.log("Verification Successful");
//				//Email-Exist
//				given().log().all().header("Content-Type","application/json").header("email",mail)
//				.body("{\r\n"
//						+ "    \"email\":\""+signinEmail+"\"\r\n"
//						+ "}")
//					.when().post("/api/v2/auth/email-exist").then().log().all().assertThat().statusCode(200);
//				//Reset password
//				given().log().all().header("Content-Type","application/json").header("email",mail)
//				.body("{\r\n"
//						+ "  \"email\": \""+signinEmail+"\",\r\n"
//						+ "  \"password\": \"Anasur@123\"\r\n"
//						+ "}")
//					.when().post("api/v2/auth/reset-password").then().log().all().assertThat().statusCode(200);
//				
//			//Logout
//		/*	given().log().all().header("Content-Type","application/json").header("email",mail)
//			.header("Authorization", a.AuthorizationToken)
//			.body("{\r\n"
//					+ "     \"device\": {\r\n"
//					+ "            \"token\": \"deL5_IVSR5Sskgu40DvT3:APA91bEvwltlTHUybBeWqzOkN1DPcY_E-HMRSOThqDzeyElo--8szEQ1NEbVOciE25IO4x8fk6skvhYFicng8IE4hHmB81bp3mrNFCY2RPfwSOo3IIlnHlbkzDP451ScDt\"\r\n"
//					+ " }}")
//				.when().post("api/v2/auth/logout").then().log().all().assertThat().statusCode(200);*/
//			//Delete
//			given().log().all().header("Content-Type","application/json").header("email",mail).param("email",mail)
//			.header("Authorization", a.AuthorizationToken)
//			
//				.when().delete("api/v2/auth/delete-user").then().log().all().assertThat().statusCode(200);
//			
//			}
//				
//					//Create personal Profile
//			/*	String CreatePersonalprofile = given().log().all().headers("Content-Type","multipart/form-data").multiPart("name",name)
//				.multiPart("userName",Username).multiPart("designation","Analyst")
//				.headers("Authorization", a.AuthorizationToken)
//				.when().post("api/v2/user/profile").then().log().all().assertThat().statusCode(200).extract().response().asString();
//			System.out.println(CreatePersonalprofile);
//			Reporter.log("User created personal profile sucessfully");
//			//Retrieve Personal profile details
//			String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
//					.headers("Authorization", a.AuthorizationToken)
//					.when().get("/api/v2/user/profile/").then().assertThat().statusCode(200).extract().response().asString();
//					System.out.println(getpersonaldetails);
//					JsonPath gp2=new JsonPath(getpersonaldetails);
//			        String PersonalprofId = gp2.get("data._id");
//			        System.out.println("PersonalUserId "+PersonalprofId);
//			        
//			        Thread.sleep(5000);
//			        
//			 //Update basicPersonal Profile
//			        String basicupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
//							.body("{\r\n"
//									+ "    \"type\": \"basic\",\r\n"
//									+ "    \"name\": \"Rangadu\",\r\n"
//									+ "    \"phone\": \"78963144796\",\r\n"
//									+ "    \"gender\": \"male\"\r\n"
//									+ "}")
//							.headers("Authorization", a.AuthorizationToken)
//							.when().patch("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
//							System.out.println(basicupdatepersonalprofile);
//							Reporter.log("Updated basic personal profile sucessfully");
//				//	Update skillPersonal Profile
//							String Skillupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
//									.body("{\r\n"
//											+ "    \"type\":\"skill\",\r\n"
//											+ "    \"skill\":\"manual\"\r\n"
//											+ "}")
//									.headers("Authorization", a.AuthorizationToken)
//									.when().patch("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
//									System.out.println(Skillupdatepersonalprofile);
//									Reporter.log("Updated personal profile skills sucessfully");
//				//update linkpersoanl Profile
//									String linkupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
//											.body("{\r\n"
//													+ "    \"type\":\"link\",\r\n"
//													+ "    \"link\":\"www.js.com\"\r\n"
//													+ "}")
//											.headers("Authorization", a.AuthorizationToken)
//											.when().patch("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
//											System.out.println(linkupdatepersonalprofile);
//											Reporter.log("Updated personal profile links sucessfully");				
//		 // Update award
//						String awardupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
//													.body("{\r\n"
//															+ "    \"type\": \"award\",\r\n"
//															+ "    \"title\": \"IEEE\",\r\n"
//															+ "    \"received\": \"10-10-2022\",\r\n"
//															+ "    \"organization\": \"Indian\"\r\n"
//															+ "}")
//													.headers("Authorization", a.AuthorizationToken)
//													.when().patch("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
//													System.out.println(awardupdatepersonalprofile);
//													Reporter.log("Updated personal profile awards sucessfully");				
//													JsonPath award=new JsonPath(awardupdatepersonalprofile);
//											        String awardid = gp2.get("data.awards[0]._id");
//											        System.out.println("AwardId "+awardid);
//			//Update Education								       
//							String Educationupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
//															.body("{\r\n"
//																	+ "    \"type\": \"education\",\r\n"
//																	+ "    \"institute\": \"gbp school\",\r\n"
//																	+ "    \"degree\": \"Mba\",\r\n"
//																	+ "    \"startDate\": \"05-06-2021\",\r\n"
//																	+ "    \"endDate\": \"07-06-2023\"\r\n"
//																	+ "}")
//															.headers("Authorization", a.AuthorizationToken)
//															.when().patch("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
//															System.out.println(Educationupdatepersonalprofile);
//															Reporter.log("Updated personal profile Education sucessfully");				
//															JsonPath Education=new JsonPath(Educationupdatepersonalprofile);
//													        String Educationid = Education.get("data.educations[0]._id");
//													        System.out.println("EducationId "+Educationid);	
//			//update Experience										   
//													      
//													        
//			String Experienceupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
//																	.body("{\r\n"
//																			+ "    \"type\": \"experience\",\r\n"
//																			+ "    \"organization\": \"TCS\",\r\n"
//																			+ "    \"position\": \"Analyst\",\r\n"
//																			+ "    \"startDate\": \"05-05-2019\",\r\n"
//																			+ "    \"endDate\": \"06-09-2023\"\r\n"
//																			+ "}")
//																	.headers("Authorization", a.AuthorizationToken)
//																	.when().patch("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
//																	System.out.println(Experienceupdatepersonalprofile);
//																	Reporter.log("Updated personal profile Experience sucessfully");				
//																	JsonPath Experience=new JsonPath(Educationupdatepersonalprofile);
//															        String Experienceid = Experience.get("data.educations[0]._id");
//															        System.out.println("EducationId "+Experienceid);										        
//			
//			
//			}
//			/*	@Test(priority=2)
//				public void Createbusinessprofile(){
//					//String AuthorizationToken = "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IjlhNTE5MDc0NmU5M2JhZTI0OWIyYWE3YzJhYTRlMzA2M2UzNDFlYzciLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vY3VyZC1uZXR3b3JrLS0tZGV2IiwiYXVkIjoiY3VyZC1uZXR3b3JrLS0tZGV2IiwiYXV0aF90aW1lIjoxNjk2NzY5MDU3LCJ1c2VyX2lkIjoiWnVZa0c2M052b2VzSzlGdjlGTEROV0VkUDlXMiIsInN1YiI6Ilp1WWtHNjNOdm9lc0s5RnY5RkxETldFZFA5VzIiLCJpYXQiOjE2OTY3NjkwNTcsImV4cCI6MTY5Njc3MjY1NywiZW1haWwiOiJzaXZhb2N0ODJAeW9wbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsImZpcmViYXNlIjp7ImlkZW50aXRpZXMiOnsiZW1haWwiOlsic2l2YW9jdDgyQHlvcG1haWwuY29tIl19LCJzaWduX2luX3Byb3ZpZGVyIjoicGFzc3dvcmQifX0.0UVayjE4NBRvgNr8EgtyVrfJnEfGw8UirlvAuglkg-eHcuVitboM-tVyATkBM79WGo3qjU8zdEA2SGtMkLmFrPDykyWYoyn3Oua0GQQKEhBv9_uNgWRuUITa8xKjxp0Dobzv5PiLvG3KR6DgZxxbKOTM0ASreW101MS06XsJe4aeWGyNYP3N-glDFM0vHANlgKFFNZwMCHz9kUNTmTplOL9xdYkL98y1mTUbZrQNnTPw83j9Cr_ycDaycICd_cVFKGVKjxCeD8Is1Ru8WCYw330pGiMS9-eFpJGB-BpwgGvwpS4Nx92VG_APyJw5GuyduYVSo5U0VCldSbgoQ05b-A";
//							//Scanner s=new Scanner(System.in);
//					//String AuthorizationToken = s.next();
//					//System.out.println(AuthorizationToken);
//					//RestAssured.baseURI="http://hcpdev.curd.network:3000";
//					// TODO Auto-generated method stub
//					String Createbusiness = given().log().all().headers("Content-Type","multipart/form-data").multiPart("businessName","fashiontech")
//					.multiPart("tagline","space ao").multiPart("description","electronics").multiPart("industry","semi")
//					.headers("Authorization", a.AuthorizationToken)
//					.when().post("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
//					System.out.println(Createbusiness);
//					JsonPath js1=new JsonPath(Createbusiness);
//
//						String businessid=js1.get("data[0]._id");
//						System.out.println("businessid"+businessid);
//						Reporter.log("Business profile created");
//						
//
//					String getbusiness = given().log().all().headers("Content-Type","application/json").param("id", businessid)
//							.headers("Authorization", a.AuthorizationToken)
//							.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
//							System.out.println(getbusiness);
//							
//								Reporter.log("Retrieve business profile sucessful");
//
//							//update businessprofile
//							String updatebusiness = given().log().all().headers("Content-Type","application/json").param("id", businessid)
//									.body("{\r\n"
//											+ "    \"type\": \"basic\",\r\n"
//											+ "    \"businessName\": \"Helpdesk ok\",\r\n"
//											+ "    \"tagline\": \" Helpdesk Tag\",\r\n"
//											+ "    \"address\": \"bangalore\",\r\n"
//											+ "    \"lat\": \"12.6\",\r\n"
//											+ "    \"long\": \"12.1\",\r\n"
//											+ "    \"website\": \"www.tech.com\"\r\n"
//											+ "}")
//									.headers("Authorization", a.AuthorizationToken)
//									.when().patch("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
//									System.out.println(updatebusiness);
//									Reporter.log("Updated business profile sucessfully");
////									Scanner e=new Scanner(System.in);
////									String busid1 = e.next();
////									System.out.println("id:"+busid1);
//							//Delete businessprofile
//									String deletebusiness = given().log().all().headers("Content-Type","application/json").param("id", businessid)
//											.headers("Authorization", a.AuthorizationToken)
//											.when().delete("api/v2/businessProfile").then().log().all().assertThat().statusCode(200).extract().response().asString();
//											System.out.println(deletebusiness);
//											Reporter.log("Sucessfully deleted business account");
//				}
//				
//				//follow
//				@Test(priority=3)
//				public void Follow(){
//					String followId = "654a0845b81bb724efa0ba24";
//				  String Createfollow=given().log().all().headers("Content-Type","application/json")
//						.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//								+ "  \"following\": \""+followId+"\",\r\n"
//								+ "  \"ref_model\": \"personal_profile\"\r\n"
//								+ "}")
//						.when().post("/api/v2/network/follow").then().log().all().assertThat().statusCode(200).extract().response().asString();
//						System.out.println(Createfollow);
//					JsonPath Fs1=new JsonPath(Createfollow);
//
//						String followmessage=Fs1.get("data.message");
//							System.out.println("folliwermessage"+followmessage);
//							Reporter.log("User followed sucessfully");
//					
//							
//
//							String followingofUser = given().log().all().headers("Content-Type","application/json")
//									.headers("Authorization", a.AuthorizationToken)
//									.when().get("/api/v2/network/followings").then().log().all().assertThat().statusCode(200).extract().response().asString();
//									System.out.println(followingofUser);
//									JsonPath Fs2=new JsonPath(followingofUser);
//									 String followerUser = "data.message";
//										String following=Fs2.getString(followerUser);
//										System.out.println("meassage"+following);
//										Reporter.log("following retrieve sucessfully");
//										
//										
//							String followersofUser = given().log().all().headers("Content-Type","application/json")
//											.headers("Authorization", a.AuthorizationToken)
//												.when().get("/api/v2/network/followers").then().log().all().assertThat().statusCode(200).extract().response().asString();
//												System.out.println(followersofUser);
//												JsonPath Fs3=new JsonPath(followersofUser);
//												 String followers= "data.message";
//													String Userfollowers=Fs3.getString(followers);
//													System.out.println("meassage"+Userfollowers);
//													Reporter.log("following retrieve sucessfully");	
//													
//									String Managenetwork = given().log().all().headers("Content-Type","application/json")
//															.headers("Authorization", a.AuthorizationToken)
//															.when().get("/api/v2/network/followers").then().log().all().assertThat().statusCode(200).extract().response().asString();
//															System.out.println(Managenetwork);
//															JsonPath Fs4=new JsonPath(Managenetwork);
//															 String UserManagenetwork= "data.message";
//																String UserallManagenetwork=Fs4.getString(UserManagenetwork);
//																System.out.println("meassage"+UserallManagenetwork);
//																Reporter.log("User Getting all data");						
//													
//						    String deletebusiness = given().log().all().headers("Content-Type","application/json")
//																		.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//																				+ "  \"following\": \""+followId+"\",\r\n"
//																				+ "  \"ref_model\": \"personal_profile\"\r\n"
//																				+ "}")
//																		.when().delete("/api/v2/network/follow").then().log().all().assertThat().statusCode(200).extract().response().asString();
//																		System.out.println(deletebusiness);
//																		Reporter.log("Sucessfully deleted business account");
//											
//				}
//				@Test(priority=4)
//				public void Post() {
//				String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
//				.headers("Authorization", a.AuthorizationToken)
//				.when().get("/api/v2/user/profile/").then().assertThat().statusCode(200).extract().response().asString();
//				System.out.println(getpersonaldetails);
//				JsonPath cp=new JsonPath(getpersonaldetails);
//		        String PersonalprofIdforpost = cp.get("data._id");
//		        System.out.println("PersonalUserId "+PersonalprofIdforpost);
//
//				 String CreatePost=given().log().all().headers("Content-Type","application/json")
//							.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//									+ "\"postType\":\"social\",\r\n"
//									+ "\"visibleTo\":\"everyone\",\r\n"
//									+ "\"createdBy\": {\r\n"
//									+ "             \"ref_id\":\""+PersonalprofIdforpost+"\",\r\n"
//									+ "             \"ref_model\":\"personal_profile\"\r\n"
//									+ "},\r\n"
//									+ "\"caption\":\"hii\",\r\n"
//									+ "\"majorIndustry\":\"Fashion\",\r\n"
//									+ "\"minorIndustry\":\"Clothing\",\r\n"
//									+ "\"lat\":\"12.9\",\r\n"
//									+ "\"long\":\"13.9\",\r\n"
//									+ "\"address\":\"Mysore\",\r\n"
//									+ "\"isRepost\":false\r\n"
//									+ "}")
//							.when().post("/api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
//							System.out.println(CreatePost);
//						JsonPath Fs1=new JsonPath(CreatePost);
//
//							String Postmessage=Fs1.get("message");
//							String PostId=Fs1.get("data._id");
//							System.out.println("PostId "+PostId);
//								System.out.println("Postmessage"+Postmessage);
//								Reporter.log("User Create post sucessfully");
//								
//								//getpost
//								
//								String getPost = given().log().all().headers("Content-Type","application/json")
//										.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//												+ "  \"id\": \""+PostId+"\",\r\n"
//												+ "  \"postType\": \"social\"\r\n"
//												+ "}")
//										.when().post("/api/v2/post/getPost").then().log().all().assertThat().statusCode(200).extract().response().asString();
//										System.out.println(getPost);
//										
//										JsonPath pgs=new JsonPath(getPost);
//										String Getmessage=pgs.get("message");
//										
//											System.out.println("Postmessage"+Getmessage);
//											Reporter.log("User retrieve data sucessfully");
//										
//										
//							//Update Post
//										 String UpdatePost=given().log().all().headers("Content-Type","application/json").param("id",PostId)
//													.headers("Authorization", a.AuthorizationToken).body("{ \r\n"
//															+ " \"postType\" : \"social\",\r\n"
//															+ " \"visibleTo\" : \"everyone\",\r\n"
//															+ " \"caption\":\"dell\" \r\n"
//															+ "}")
//													.when().patch("/api/v2/post/update/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//													System.out.println(UpdatePost);
//												JsonPath up=new JsonPath(UpdatePost);
//
//													String updatemessage=up.get("message");
//													
//														System.out.println("Postmessage"+updatemessage);
//														Reporter.log("User update sucessfully");
//														
//							//Delete Post
//														
//					String deletePost = given().log().all().headers("Content-Type","application/json").param("id", PostId)
//													.headers("Authorization", a.AuthorizationToken)
//													.when().delete("/api/v2/post/delete/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//													System.out.println(deletePost);
//													Reporter.log("Sucessfully Post deleted");											
//						    				
//			}
//				
//		@Test(priority=5)		
//		public void Refferal() {
//			
//			String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
//					.headers("Authorization", a.AuthorizationToken)
//					.when().get("/api/v2/user/profile/").then().assertThat().statusCode(200).extract().response().asString();
//					System.out.println(getpersonaldetails);
//					JsonPath Cr=new JsonPath(getpersonaldetails);
//			        String PersonalprofIdforRefferal = Cr.get("data._id");
//			        System.out.println("PersonalUserId "+PersonalprofIdforRefferal);
//			// Referral create
//			String RefferalPost=given().log().all().headers("Content-Type","multipart/form-data")
//					.headers("Authorization", a.AuthorizationToken).multiPart("postType","referral").multiPart("visibleTo","group")
//					.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
//					.multiPart("createdBy.ref_id",PersonalprofIdforRefferal).multiPart("createdBy.ref_model","personal_profile")
//					.when().post("/api/v2/referral/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//					System.out.println(RefferalPost);
//				JsonPath Rs1=new JsonPath(RefferalPost);
//		         String Refferalmessage=Rs1.get("message");
//					String RefferalId=Rs1.get("data._id");
//					System.out.println("RefferalId "+RefferalId);
//						System.out.println("Refferalmessage"+Refferalmessage);
//						Reporter.log("User Create refferal post sucessfully");
//						
//						
//						
//				// get referral
//				
//						String getRefferal = given().log().all().headers("Content-Type","application/json").param("id", RefferalId)
//								.headers("Authorization", a.AuthorizationToken).
//								when().get("/api/v2/referral/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//								System.out.println(getRefferal);
//								
//								JsonPath pgs=new JsonPath(getRefferal);
//								String GetRefferalmessage=pgs.get("message");
//								
//									System.out.println("Postmessage"+GetRefferalmessage);
//									Reporter.log("User retrieve refferal data sucessfully");
//									
//					// Update Refferal Post
//									
//					String UpdateRefferal=given().log().all().headers("Content-Type","application/json").param("id",RefferalId)
//											.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//													+ " \"postType\" : \"referral\",\r\n"
//													+ " \"visibleTo\" : \"group\",\r\n"
//													+ " \"lat\":\"18.9\",\r\n"
//													+ " \"long\":\"32.9\",\r\n"
//													+ " \"address\":\"Vijayawada\",\r\n"
//													+ " \"caption\":\"Software services \",\r\n"
//													+ " \"majorIndustry\":\"Development\",\r\n"
//													+ " \"minorIndustry\":\"services\"\r\n"
//													+ " \r\n"
//													+ "}\r\n"
//													+ "")
//											.when().patch("/api/v2/referral/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//											System.out.println(UpdateRefferal);
//										JsonPath up=new JsonPath(UpdateRefferal);
//
//											String updateRefferalmessage=up.get("message");
//											
//												System.out.println("Postmessage"+updateRefferalmessage);
//												Reporter.log("User update Refferal post sucessfully");
//												
//					//Delete 
//						String deleteRefferal = given().log().all().headers("Content-Type","application/json").param("id", RefferalId)
//											.headers("Authorization", a.AuthorizationToken)
//											.when().delete("/api/v2/referral/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//											System.out.println(deleteRefferal);
//											Reporter.log("Sucessfully Refferal Post deleted");	
//		}						
//			//Comment
//
//			    @Test(priority=6)
//			    public void Comment() {
//			    	
//			    	String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
//			    			.headers("Authorization", a.AuthorizationToken)
//			    			.when().get("/api/v2/user/profile/").then().assertThat().statusCode(200).extract().response().asString();
//			    			System.out.println(getpersonaldetails);
//			    			JsonPath comt=new JsonPath(getpersonaldetails);
//			    	        String PersonalprofIdforComment = comt.get("data._id");
//			    	        System.out.println("PersonalUserId "+PersonalprofIdforComment);
//			    	        
//			    	        String RefferalPostforComment=given().log().all().headers("Content-Type","multipart/form-data")
//			    	    			.headers("Authorization", a.AuthorizationToken).multiPart("postType","referral").multiPart("visibleTo","group")
//			    	    			.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
//			    	    			.multiPart("createdBy.ref_id",PersonalprofIdforComment).multiPart("createdBy.ref_model","personal_profile")
//			    	    			.when().post("/api/v2/referral/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//			    	    			System.out.println(RefferalPostforComment);
//			    	    		JsonPath Rs1=new JsonPath(RefferalPostforComment);
//
//			    	    			String Refferalcommentmessage=Rs1.get("message");
//			    	    			String RefferalIdcomment=Rs1.get("data._id");
//			    	    			System.out.println("RefferalIdComment "+RefferalIdcomment);
//			    	    				System.out.println("RefferalCommentmessage"+Refferalcommentmessage);       
//			    	        
//			    	        
//			    	        
//			    	
//			    	        
//			   // PostComment
//			    	  
//			    	        String PostComment=given().log().all().headers("Content-Type","application/json")
//			    	    			.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//			    	    					+ "  \"createdBy\": {\r\n"
//			    	    					+ "    \"ref_id\": \""+PersonalprofIdforComment+"\",\r\n"
//			    	    					+ "    \"ref_model\": \"personal_profile\"\r\n"
//			    	    					+ "  },\r\n"
//			    	    					+ "  \"text\": \"good\",\r\n"
//			    	    					+ "  \"feedId\": \""+RefferalIdcomment+"\",\r\n"
//			    	    					+ "  \"feedType\": \"post\",\r\n"
//			    	    					+ "  \"parentId\": \""+RefferalIdcomment+"\"\r\n"
//			    	    					+ "}")	    	    			
//			    	    			.when().post("/api/v2/comment/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//			    	    			System.out.println(PostComment);
//			    	    		JsonPath Comm=new JsonPath(PostComment);
//
//			    	    			String Commentmessage=Comm.get("message");
//			    	    			String CommentId=Comm.get("data._id");
//			    	    			System.out.println("RefferalId "+CommentId);
//			    	    				System.out.println("Comment message"+Commentmessage);
//			    	    				Reporter.log("User Create Comment sucessfully"); 
//			    	    				
//			    	 // Get Comment 
//			    	  
//			    	   	String getComment = given().log().all().headers("Content-Type","application/json")
//			    	    			.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//			    	    					+ "  \"id\": \""+CommentId+"\"\r\n"
//			    	    					+ "}").
//			    	    			when().post("/api/v2/comment/getComment").then().log().all().assertThat().statusCode(200).extract().response().asString();
//			    	    			System.out.println(getComment);
//			    	    						
//			    	    			JsonPath Getcomm=new JsonPath(getComment);
//			    	    			String GetRefferalmessage=Getcomm.get("message");
//			    	    						
//			    	    				System.out.println("commentgetmessage"+GetRefferalmessage);
//			    	    				Reporter.log("User retrieve Comment data sucessfully");
//			    	    				
//			    	// Commentcount
//			         
//			    	    	String getCommentcountuser = given().log().all().headers("Content-Type","application/json")
//			    		    	   	.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//			    		    	   			+ "  \"feedId\": \""+RefferalIdcomment+"\",\r\n"
//			    		    	   			+ "  \"parentId\": \""+RefferalIdcomment+"\"\r\n"
//			    		    	   			+ "}").
//			    		    	    			when().post("/api/v2/comment/count").then().log().all().assertThat().statusCode(200).extract().response().asString();
//			    		    	    			System.out.println(getCommentcountuser);
//			    		    	    						
//			    		    	    			JsonPath Getcommcount=new JsonPath(getComment);
//			    		    	    			String Getcountmessage=Getcommcount.get("message");
//			    		    	    						
//			    		    	    				System.out.println("Getcountmessage "+Getcountmessage);
//			    		    	    				Reporter.log("User comment count retrieve sucessfully"); 
//			    		    	    				
//			       //Delete Comment
//			    		
//			    		  	String deleteComment = given().log().all().headers("Content-Type","application/json").param("id", CommentId)
//			    								.headers("Authorization", a.AuthorizationToken)
//			    								.when().delete("/api/v2/comment/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//			    											System.out.println(deleteComment);
//			    											Reporter.log("Sucessfully Comment deleted");	    	    				
//			    }
//			    
//			    
//			    @Test(priority=7)
//			    public void Like() {
//			    	
//			    	String getpersonaldetailsForlike = given().log().all().headers("Content-Type","application/json")
//			    			.headers("Authorization", a.AuthorizationToken)
//			    			.when().get("/api/v2/user/profile/").then().assertThat().statusCode(200).extract().response().asString();
//			    			System.out.println(getpersonaldetailsForlike);
//			    			JsonPath Cr=new JsonPath(getpersonaldetailsForlike);
//			    	        String PersonalprofIdforLike = Cr.get("data._id");
//			    	        System.out.println("PersonalUserIdLike "+PersonalprofIdforLike);
//			    	        
//			    	        
//			    	        
//			     String CreatePost=given().log().all().headers("Content-Type","application/json")
//			    					.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//			    							+ "\"postType\":\"social\",\r\n"
//			    							+ "\"visibleTo\":\"everyone\",\r\n"
//			    							+ "\"createdBy\": {\r\n"
//			    							+ "             \"ref_id\":\""+PersonalprofIdforLike+"\",\r\n"
//			    							+ "             \"ref_model\":\"personal_profile\"\r\n"
//			    							+ "},\r\n"
//			    							+ "\"caption\":\"hii\",\r\n"
//			    							+ "\"majorIndustry\":\"Fashion\",\r\n"
//			    							+ "\"minorIndustry\":\"Clothing\",\r\n"
//			    							+ "\"lat\":\"12.9\",\r\n"
//			    							+ "\"long\":\"13.9\",\r\n"
//			    							+ "\"address\":\"Mysore\",\r\n"
//			    							+ "\"isRepost\":false\r\n"
//			    							+ "}")
//			    					.when().post("/api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
//			    					System.out.println(CreatePost);
//			    				JsonPath LS1=new JsonPath(CreatePost);
//
//			    					String Postmessageforlike=LS1.get("message");
//			    					String PostIdforlike=LS1.get("data._id");
//			    					System.out.println("PostIdforlike "+PostIdforlike);
//			    						System.out.println("Postmessage"+Postmessageforlike);
//			    						Reporter.log("User Create post sucessfully");
//			    						      
//			    	        
//			    	       
//			    	//Post Like				
//			    	
//			    	String Postlike=given().log().all().headers("Content-Type","application/json")
//			    			.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//			    					+ "  \"createdBy\": {\r\n"
//			    					+ "    \"ref_id\": \""+PersonalprofIdforLike+"\",\r\n"
//			    					+ "    \"ref_model\": \"personal_profile\"\r\n"
//			    					+ "  },\r\n"
//			    					+ "  \"type\": \"post\",\r\n"
//			    					+ "  \"parentId\": \""+PostIdforlike+"\"\r\n"
//			    					+ "}")	    	    			
//			    			.when().post("/api/v2/like/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//			    			System.out.println(Postlike);
//			    		JsonPath li=new JsonPath(Postlike);
//
//			    			String Likemessage=li.get("message");
//			    			String LikeId=li.get("data._id");
//			    			System.out.println("LikeId "+LikeId);
//			    				System.out.println("Like message"+Likemessage);
//			    				Reporter.log("User like sucessfully"); 
//			    				
//			    	//Like Count
//			    				String getlikecountuser= given().log().all().headers("Content-Type","application/json")
//				    		    	   	.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//				    		    	   			+ "  \"type\": \"post\",\r\n"
//				    		    	   			+ "  \"parentId\": \""+PostIdforlike+"\"\r\n"
//				    		    	   			+ "}").
//				    		    	    			when().post("/api/v2/like/count").then().log().all().assertThat().statusCode(200).extract().response().asString();
//				    		    	    			System.out.println(getlikecountuser);
//				    		    	    						
//				    		    	    			JsonPath Getlikecount=new JsonPath(getlikecountuser);
//				    		    	    			String Getcountmessage=Getlikecount.get("message");
//				    		    	    						
//				    		    	    				System.out.println("Getlikecountmessage "+Getcountmessage);
//				    		    	    				Reporter.log("User like count retrieve sucessfully"); 
//				    		    			
//			    				
//			    	//Delete Like
//			    		String deleteLike = given().log().all().headers("Content-Type","application/json").param("id", LikeId)
//										.headers("Authorization", a.AuthorizationToken)
//										.when().delete("/api/v2/like/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//													System.out.println(deleteLike);
//													Reporter.log("Sucessfully Like deleted");	    	    						
//			    				
//			    				
//			    	 }
//			    @Test(priority=8)
//			    public void Conections() {
//			    	
//			    	String getpersonaldetailsForConnections = given().log().all().headers("Content-Type","application/json")
//			    			.headers("Authorization", a.AuthorizationToken)
//			    			.when().get("/api/v2/user/profile/").then().assertThat().statusCode(200).extract().response().asString();
//			    			System.out.println(getpersonaldetailsForConnections);
//			    			JsonPath Cr=new JsonPath(getpersonaldetailsForConnections);
//			    	        String PersonalprofIdforconnections = Cr.get("data._id");
//			    	        System.out.println("PersonalUserIdLike "+PersonalprofIdforconnections);
//			    	
//			    //Connections
//			    //Connection Request
//			    	String frndConnectid = "6549ceeffbe1749a8845a173";
//			    String ConnectionRequest=given().log().all().headers("Content-Type","application/json").param("id", frndConnectid)
//						.headers("Authorization", a.AuthorizationToken)
//						.when().get("/api/v2/network/connection/request").then().log().all().assertThat().statusCode(200).extract().response().asString();
//						System.out.println(ConnectionRequest);
//					JsonPath RC=new JsonPath(ConnectionRequest);
//
//						String Requestmessage=RC.get("message");
//							System.out.println("Requestmessage"+Requestmessage);
//			
//				//Connection Accept
//				
//				 String ConnectionAccept=given().log().all().headers("Content-Type","application/json").param("id", frndConnectid)
//										.headers("Authorization", a.AuthorizationToken)
//										.when().get("/api/v2/network/connection/accept").then().log().all().assertThat().statusCode(200).extract().response().asString();
//										System.out.println(ConnectionAccept);
//									JsonPath AC=new JsonPath(ConnectionAccept);
//
//										String Acceptmessage=AC.get("message");
//											System.out.println("Acceptmessage"+Acceptmessage);
//				//Connection withdraw
//				
//											
//										    String Connectionwithdraw=given().log().all().headers("Content-Type","application/json").param("id", frndConnectid)
//													.headers("Authorization", a.AuthorizationToken)
//													.when().get("/api/v2/network/connection/withdrawal").then().log().all().assertThat().statusCode(200).extract().response().asString();
//													System.out.println(Connectionwithdraw);
//												JsonPath cr=new JsonPath(Connectionwithdraw);
//
//													String messagewithdraw=cr.get("message");
//														System.out.println("Requestmessageforwithdraw"+messagewithdraw);
//				// Connection Reject
//														
//				         		 String Connectionreject=given().log().all().headers("Content-Type","application/json").param("id",frndConnectid )
//															.headers("Authorization", a.AuthorizationToken)
//														.when().get("/api/v2/network/connection/reject").then().log().all().assertThat().statusCode(200).extract().response().asString();
//															System.out.println(Connectionreject);
//														JsonPath cw=new JsonPath(Connectionreject);
//
//																	String messagereject=cw.get("message");
//																		System.out.println("messageforwithdraw"+Connectionreject);
//																		
//			    //Connection Remove
//								
//									 String Connectionremove=given().log().all().headers("Content-Type","application/json").param("id", PersonalprofIdforconnections)
//																		.headers("Authorization", a.AuthorizationToken)
//																	.when().get("/api/v2/network/connection/remove").then().log().all().assertThat().statusCode(200).extract().response().asString();
//																System.out.println(Connectionremove);
//																	JsonPath cR=new JsonPath(Connectionremove);
//
//																String messageremove=cR.get("message");
//									           				System.out.println("messageforremove"+messageremove);											
//																		
//		       //Connection Sent
//									           				
//									String Connectionsent=given().log().all().headers("Content-Type","application/json")
//														.headers("Authorization", a.AuthorizationToken)
//																.when().get("/api/v2/network/connection/sent").then().log().all().assertThat().statusCode(200).extract().response().asString();
//															System.out.println(Connectionsent);
//																JsonPath cS=new JsonPath(Connectionsent);
//
//															String messagesent=cS.get("message");
//								           				System.out.println("messageforsent"+messagesent);
//			  //Connection Received
//								           				
//				String ConnectionReceived=given().log().all().headers("Content-Type","application/json")
//																.headers("Authorization", a.AuthorizationToken)
//																		.when().get("/api/v2/network/connection/received").then().log().all().assertThat().statusCode(200).extract().response().asString();
//																	System.out.println(ConnectionReceived);
//																		JsonPath Rc=new JsonPath(ConnectionReceived);
//
//																	String messageReceived=Rc.get("message");
//										           				System.out.println("messageforReceived"+messageReceived);
//				//Connections
//				String Connections=given().log().all().headers("Content-Type","application/json").param("id",PersonalprofIdforconnections )
//									                .headers("Authorization", a.AuthorizationToken)
//													.when().get("/api/v2/network/connections").then().log().all().assertThat().statusCode(200).extract().response().asString();
//											         System.out.println(Connections);
//													JsonPath Connectionsobj=new JsonPath(Connections);
//
//												   String messageConnections=Connectionsobj.get("message");
//										  		System.out.println("messageforConnections"+messageConnections);
//			    //Recommendations
//		       	String Recommendations=given().log().all().headers("Content-Type","application/json").param("profile","personal" )
//										                .headers("Authorization", a.AuthorizationToken)
//														.when().get("/api/v2/network/recommendations").then().log().all().assertThat().statusCode(200).extract().response().asString();
//												         System.out.println(Recommendations);
//														JsonPath R=new JsonPath(Recommendations);
//
//													   String messageRecommendations=R.get("message");
//											  		System.out.println("messageforRecommendation"+messageRecommendations);
//				   
//										  		
//		 								           				
//		}    
//			    @Test(priority=9)
//		      public void Messanger() {
//			    	
//			    	
//			    	String getpersonaldetailsForMessanger= given().log().all().headers("Content-Type","application/json")
//			    			.headers("Authorization", a.AuthorizationToken)
//			    			.when().get("/api/v2/user/profile/").then().assertThat().statusCode(200).extract().response().asString();
//			    			System.out.println(getpersonaldetailsForMessanger);
//			    			JsonPath Cr=new JsonPath(getpersonaldetailsForMessanger);
//			    	        String PersonalprofIdformessanger = Cr.get("data._id");
//			    	        System.out.println("PersonalprofIdformessanger "+PersonalprofIdformessanger);
//			    	
//			    	//post messanger
//			    	 String Postmessanger=given().log().all().headers("Content-Type","application/json")
//		 					.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//		 							+ "  \"users\": [\r\n"
//		 							+ "    \""+PersonalprofIdformessanger+"\"\r\n"
//		 							+ "  ]\r\n"
//		 							+ "}")
//		 					.when().post("/api/v2/messenger/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//		 					System.out.println(Postmessanger);
//		 					JsonPath Mess=new JsonPath(Postmessanger);
//
//							String messangerId=Mess.get("data._id");
//		   				System.out.println("messangerId  "+messangerId);
//
//		 					
//		 					
//		 					
//		 					
//		 			//Get messanger
//		 					
//		 					String Getmessanger=given().log().all().headers("Content-Type","application/json")
//					                .headers("Authorization", a.AuthorizationToken)
//									.when().get("/api/v2/messenger/").then().log().all().assertThat().statusCode(200).extract().response().asString();
//							         System.out.println(Getmessanger);
////									JsonPath Connectionsobj=new JsonPath(Connections);
//		//
////								   String messageConnections=Connectionsobj.get("message");
////						  		System.out.println("messageforConnections"+messageConnections);
//				
//		    	  //Post send message
//				  String Posttext=given().log().all().headers("Content-Type","application/json")
//							 					.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//							 							+ "    \"conversationId\":\""+messangerId+"\",\r\n"
//							 							+ "    \"text\":\"Good Morning\"\r\n"
//							 							+ "}")
//							 					.when().post("/api/v2/messenger/sendMessage").then().log().all().assertThat().statusCode(200).extract().response().asString();
//			                                    System.out.println(Posttext);
//			                                    JsonPath messageid=new JsonPath(Posttext);
//
//			                					String messageconvid=messageid.get("data[0].message._id");
//			                   				System.out.println("messageconvid  "+messageconvid);
//			                   				Reporter.log("Send message sucessfully");
//		      
//			                                    
//			     //Get Message	
//			          String Getmessage=given().log().all().headers("Content-Type","application/json").
//			                			                headers("Authorization", a.AuthorizationToken)
//			                							.when().get("/api/v2/messenger/getMessage/"+messageconvid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
//			                					         System.out.println(Getmessage); 
//			    
//			    //Get messenger converid
//			           		String messangerconv=given().log().all().headers("Content-Type","application/json").param("type","BLOCK")
//		                			                .headers("Authorization", a.AuthorizationToken)
//		                							.when().get("/api/v2/messenger/"+messangerId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
//		                					         System.out.println(messangerconv); 
//		                					         
//		        //Delete message
//		                String deletemessage = given().log().all().headers("Content-Type","application/json")
//		                						                		.headers("Authorization", a.AuthorizationToken).body("{\r\n"
//		                						                				+ "  \"messageId\": \""+messageconvid+"\",\r\n"
//		                						                				+ "  \"conversationId\": \""+messangerId+"\"\r\n"
//		                						                				+ "}")
//		                						                	.when().delete("/api/v2/messenger/deleteMessage").then().log().all().assertThat().statusCode(200).extract().response().asString();
//		                						                				System.out.println(deletemessage);
//		                						                				Reporter.log("Sucessfully message deleted");	                					         
//		          //Delete Messenger
//		            String DeleteMessenger = given().log().all().headers("Content-Type","application/json")
//		                				         .headers("Authorization", a.AuthorizationToken)
//		                				    .when().delete("/api/v2/messenger/delete/"+messangerId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
//		                				                				System.out.println(DeleteMessenger);
//		                				                				Reporter.log("Sucessfully messanger deleted");	         					         
//			                			    		           					         
//		      }
//			    	        
//			    	        
//			    	        
//			    	        
//			    	        
//			    	        
//			    	
//			    
//											
//											  
//														
//													
//						
//						
//						
//						
//						
//			
//			
//			
//			
//			
//			
//
//			
//			
//
//			
//				
//				
//				
//				
//				
//				
//				
//				
//				
//				
//				
//				
//				
//				
//				
//			
//				
//			*/
//			
//			//public void teardown() {
//			//extents.flush();
//											//}
//
//											
//						}
//				
//			
//					
//						
//						
//						
//						
//						
//						
//						
//						
//						
//						
//						
//						
//						
//						
//						
//						
//						
//						
//						
//				
//			
//			
//
//			
//
//
//
//	}
//
//}
