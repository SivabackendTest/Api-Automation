package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PersonalprofileRecommandation {
	public String CreaterecommId;

	AuthorizationToken a=new AuthorizationToken();
	Personal P=new Personal();
	@Test(priority=1)
	public void CreateRecommandation(){
			
			RestAssured.baseURI="http://hcpdev.curd.network:3000";
			// TODO Auto-generated method stub
			 Response Createrecommandation = given().log().all().headers("Content-Type","application/json")
					.header("email",a.mail).body("{\r\n"
							+ "  \"type\": \"recommendation\",\r\n"
							+ "  \"personalId\": \"66d6d9569f0b6535b27c2d09\",\r\n"
							+ "  \"relationship\": \"Dairy\",\r\n"
							+ "  \"position\": \"biscuit\",\r\n"
							+ "  \"caption\": \"India\",\r\n"
							+ "  \"status\": \"pending\"\r\n"
							+ "}").headers("Authorization", a.AuthorizationToken)
			.when().post("/api/v2/recommendation/create");
			 String CreaterecommId = Createrecommandation.then().contentType(ContentType.JSON).extract().path("data._id");
			 String Businessmessage = Createrecommandation.then().contentType(ContentType.JSON).extract().path("message");
 System.out.println(CreaterecommId);
	Assert.assertEquals("SUCCESS",Businessmessage );
	


				   Reporter.log("Endpoint :/api/v2/recommendation/create");
			        Reporter.log("StatusCode :200");
				
				Reporter.log("Personal Recommndation created");
	}
	@Test(priority=2)
	public void UpdateRecommandation(){
			
			RestAssured.baseURI="http://hcpdev.curd.network:3000";
			// TODO Auto-generated method stub
			  String Updaterecommandation = given().log().all().headers("Content-Type","application/json")
					.header("email",a.mail).body("{\r\n"
							+ "  \"personalId\": \"66d6d9569f0b6535b27c2d09\",\r\n"
							+ "  \"relationship\": \"Dairy\",\r\n"
							+ "  \"position\": \"biscuit\",\r\n"
							+ "  \"caption\": \"India\",\r\n"
							+ "  \"status\": \"accept\"\r\n"
							+ "}").headers("Authorization", a.AuthorizationToken)
			.when().put("/api/v2/recommendation/update").then().log().all().assertThat().statusCode(200).extract().response().asString();
 System.out.println(Updaterecommandation);


				   Reporter.log("Endpoint :/api/v2/recommendation/create");
			        Reporter.log("StatusCode :200");
				
				Reporter.log("Personal Recommndation created");
	}
	@Test(priority=3)
	public void DeleteRecommandation() {
		

		RestAssured.baseURI="http://hcpdev.curd.network:3000";
		// TODO Auto-generated method stub
		 String Createrecommandationfordelete = given().log().all().headers("Content-Type","application/json")
				.header("email",a.mail).body("{\r\n"
						+ "  \"type\": \"recommendation\",\r\n"
						+ "  \"personalId\": \"66d6d9569f0b6535b27c2d09\",\r\n"
						+ "  \"relationship\": \"Dairy\",\r\n"
						+ "  \"position\": \"biscuit\",\r\n"
						+ "  \"caption\": \"India\",\r\n"
						+ "  \"status\": \"pending\"\r\n"
						+ "}").headers("Authorization", a.AuthorizationToken)
		.when().post("/api/v2/recommendation/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
		 JsonPath Idrecomn=new JsonPath(Createrecommandationfordelete);
			String Perrecomdelete=Idrecomn.get("data._id");

		
		String deleteRecommandation = given().log().all().headers("Content-Type","application/json").param("id",Perrecomdelete)
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().delete("/api/v2/recommendation/delete").then().log().all().assertThat().statusCode(200).extract().response().asString();
				System.out.println(deleteRecommandation);
				JsonPath jd1=new JsonPath(deleteRecommandation);
				String deleterecomm=jd1.get("message");
				Assert.assertEquals("SUCCESS",deleterecomm );

				
				Reporter.log("Endpoint :/api/v2/recommendation/delete");
		        Reporter.log("StatusCode :200");
				Reporter.log("Sucessfully deleted Recommandation");
	

}
	@Test(priority=4)
	public void getbusiness() {
		
			String getrecommandation = given().log().all().headers("Content-Type","application/json")
					.params("personalId",P.PersonalprofileId).params("status", "pending")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("/api/v2/recommendation/get").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getrecommandation);
					
					JsonPath js9=new JsonPath(getrecommandation);
					
									String businessgetMessage=js9.get("message");
									System.out.println("businessgetapi message"+businessgetMessage);
									Assert.assertEquals("SUCCESS",businessgetMessage );

					Reporter.log("Endpoint :/api/v2/recommendation/get");
			        Reporter.log("StatusCode :200");
						Reporter.log("Retrieve business profile sucessful");}
	}
