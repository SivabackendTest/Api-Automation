package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Notification {
	AuthorizationToken a=new AuthorizationToken();

	@Test(priority=1)
	public void getNotification() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

			 String getnotification = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("skip","0").param("limit", "10")
					.when().get("/api/v2/notification/get-all").then().log().all().assertThat().statusCode(200).extract().response().asString();
			 JsonPath Jn=new JsonPath(getnotification);
				
				String notificationMessage=Jn.get("message");
//				String restotalnotification=Jn.get("data.totalNotification");
//				String unreadnotification=Jn.get("data.unreadNotification");	
					Assert.assertEquals("SUCCESS",notificationMessage );
			
					Reporter.log("Endpoint :/api/v2/notification/get-all");
			        Reporter.log("StatusCode :200");
			      

						Reporter.log("User Retrieve notification data sucessful");
						}
	@Test(priority=2)
	public void ReadNotification() {
	
			
			 Response getnotification1 = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("skip","0").param("limit", "10")
					.when().get("/api/v2/notification/get-all");
			
					
					 String notificationId1 = getnotification1.then().contentType(ContentType.JSON).extract().path("data.notifications[1]._id");
		String readnotification= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).param("id",notificationId1 )
			.when().patch("/api/v2/notification/read").then().log().all().assertThat().statusCode(200).extract().response().asString();
			 JsonPath Jnr=new JsonPath(readnotification);
			 System.out.println(readnotification);
				
				String readmessage=Jnr.get("message");
				boolean readgmessagestatus=Jnr.get("data.isRead");
	 
			Assert.assertEquals("SUCCESS",readmessage );
			
			Reporter.log("Endpoint :/api/v2/notification/read");
	        Reporter.log("StatusCode :200");
			Reporter.log("User read notification Sucessfully");
}
	@Test(priority=3)
	public void readallNotification() {
		
			String allnotificationread = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("skip","0").param("limit", "10")
					.when().get("/api/v2/notification/read-all").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(allnotificationread);
			JsonPath Jnar=new JsonPath(allnotificationread);
			String allreadmessage=Jnar.get("message");
			String allreadgmessagestatus=Jnar.get("data.message");
 
		
					
									Assert.assertEquals("SUCCESS",allreadmessage );
						Assert.assertEquals("Read Successfully",allreadgmessagestatus );
						Reporter.log("Endpoint :/api/v2/notification/read-all");
				        Reporter.log("StatusCode :200");
						Reporter.log("User read all notification Sucessfully");
					 
	
}
	@Test(priority=4)
	public void OpenNotification() {
	
			
			 String getnotification2 = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("skip","0").param("limit", "10")
					.when().get("/api/v2/notification/get-all")
					.then().log().all().assertThat().statusCode(200).extract().response().asString();
			
			 JsonPath Jn1=new JsonPath(getnotification2);
				
				String notificationIdread=Jn1.get("data.notifications[1]._id");
				System.out.println(notificationIdread);
		
String Opennotification= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).param("id",notificationIdread )
			.when().patch("/api/v2/notification/open").then().log().all().assertThat().statusCode(200).extract().response().asString();

       JsonPath Jopen=new JsonPath(Opennotification);

          String notificationopen=Jopen.get("message");
          boolean notificationopenstaus=Jopen.get("data.isOpened");
System.out.println(notificationopenstaus);
			
			 
			Assert.assertEquals("SUCCESS",notificationopen );
			Assert.assertTrue(notificationopenstaus,"true" );
			
			Reporter.log("Endpoint :/api/v2/notification/open");
	        Reporter.log("StatusCode :200");
			Reporter.log("User read notification Sucessfully");
	}
	@Test(priority=5)
	public void BadgecountNotification() {
		
			 Response Badgecount= given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("/api/v2/notification/get-badge");
			
					
					 String notificationbadgemessage = Badgecount.then().contentType(ContentType.JSON).extract().path("message");	
						Assert.assertEquals("SUCCESS",notificationbadgemessage );
						Reporter.log("Endpoint :/api/v2/notification/get-badge");
				        Reporter.log("StatusCode :200");
						Reporter.log("User retrieve badge countdata Sucessfully");
					 
	
}
	
}
	
	
	
