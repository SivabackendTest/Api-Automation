package Apimethods;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Referral{
	AuthorizationToken a=new AuthorizationToken();

	@Test(priority=1)
	public void Refferal() throws InterruptedException {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
		String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.buyertoken).header("email",a.buyermail)
				.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(getpersonaldetails);
				JsonPath Cr=new JsonPath(getpersonaldetails);
		        String PersonalprofIdforRefferal = Cr.get("data._id");
		        System.out.println("PersonalUserId "+PersonalprofIdforRefferal);
		// Referral create
		String RefferalPost=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.buyermail)
				.headers("Authorization", a.buyertoken).multiPart("postType","referral").multiPart("visibleTo","my_network")
				.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
				.multiPart("createdBy.ref_id",PersonalprofIdforRefferal).multiPart("createdBy.ref_model","personal_profile")
				.multiPart("referralExpiry","2024-06-30 11:55").multiPart("industry","3D Printing").multiPart("lat","16.87")
				.multiPart("long","82.78").multiPart("address","Banglore")
				.when().post("api/v2/referral").then().log().all().assertThat().statusCode(200).extract().response().asString();
				System.out.println(RefferalPost);
			JsonPath Rs1=new JsonPath(RefferalPost);
	         String Refferalmessage=Rs1.get("message");
				String RefferalId=Rs1.get("data._id");
				System.out.println("RefferalId "+RefferalId);
				Assert.assertEquals("SUCCESS",Refferalmessage );

					System.out.println("Refferalmessage"+Refferalmessage);
					Reporter.log("api/v2/referral");
					Reporter.log("statusCode 200");
					Reporter.log("User Create refferal post sucessfully");
					
					
	}	
		@Test(priority=2)
		public void Getreferral() {
			String getpersonaldetailsforGet = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.buyertoken).header("email",a.buyermail)
					.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getpersonaldetailsforGet);
					JsonPath Cr1=new JsonPath(getpersonaldetailsforGet);
			        String PersonalprofIdforRefferalretrieve = Cr1.get("data._id");
			        System.out.println("PersonalUserIdforretrieve "+PersonalprofIdforRefferalretrieve);
			String RefferalPostget=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.buyermail)
					.headers("Authorization", a.buyertoken).multiPart("postType","referral").multiPart("visibleTo","my_network")
					.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
					.multiPart("createdBy.ref_id",PersonalprofIdforRefferalretrieve).multiPart("createdBy.ref_model","personal_profile")
					.multiPart("referralExpiry","2024-06-30 11:55").multiPart("industry","3D Printing").multiPart("lat","16.87")
					.multiPart("long","82.78").multiPart("address","Banglore")
					.when().post("api/v2/referral").then().log().all().assertThat().statusCode(200).extract().response().asString();
					System.out.println(RefferalPostget);
				JsonPath Rs2=new JsonPath(RefferalPostget);
		         String Refferalmessage1=Rs2.get("message");
					Assert.assertEquals("SUCCESS",Refferalmessage1 );

					String RefferalId1=Rs2.get("data._id");
					System.out.println("RefferalId "+RefferalId1);
		
			// get referral
			
					String getRefferal = given().log().all().headers("Content-Type","application/json").param("id", RefferalId1)
							.headers("Authorization", a.buyertoken).header("email",a.buyermail).
							when().get("api/v2/referral").then().log().all().assertThat().statusCode(200).extract().response().asString();
							System.out.println(getRefferal);
							
							JsonPath pgs=new JsonPath(getRefferal);
							String GetRefferalmessage=pgs.get("message");
								System.out.println("Postmessage"+GetRefferalmessage);
								Reporter.log("api/v2/referral");
								Reporter.log("statusCode 200");
								
								Reporter.log("User retrieve refferal data sucessfully");
		}
								
				// Update Refferal Post
			@Test(priority=3)	
			public void Updatereferral() throws InterruptedException {
				String getpersonaldetailsforUpdate = given().log().all().headers("Content-Type","application/json")
						.headers("Authorization", a.buyertoken).header("email",a.buyermail)
						.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
						System.out.println(getpersonaldetailsforUpdate);
						JsonPath Cr1=new JsonPath(getpersonaldetailsforUpdate);
				        String PersonalprofIdforRefferalUpdate = Cr1.get("data._id");
				        System.out.println("PersonalUserIdforretrieve "+PersonalprofIdforRefferalUpdate);
				String RefferalPostget=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.buyermail)
						.headers("Authorization", a.buyertoken).multiPart("postType","referral").multiPart("visibleTo","my_network")
						.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
						.multiPart("createdBy.ref_id",PersonalprofIdforRefferalUpdate).multiPart("createdBy.ref_model","personal_profile")
						.multiPart("referralExpiry","2024-06-30 11:55").multiPart("industry","3D Printing").multiPart("lat","16.87")
						.multiPart("long","82.78").multiPart("address","Banglore")
						.when().post("api/v2/referral").then().log().all().assertThat().statusCode(200).extract().response().asString();
						System.out.println(RefferalPostget);
					JsonPath Rs3=new JsonPath(RefferalPostget);
			         String Refferalmessage=Rs3.get("message");
						String RefferalId2=Rs3.get("data._id");
						System.out.println("RefferalId "+RefferalId2);
				String UpdateRefferal=given().log().all().headers("Content-Type","application/json").header("email",a.buyermail).param("id",RefferalId2)
										.headers("Authorization", a.buyertoken).body("{\r\n"
												+ " \"postType\" : \"referral\",\r\n"
												+ " \"visibleTo\" : \"mynetwork\",\r\n"
												+ " \"lat\":\"18.9\",\r\n"
												+ " \"long\":\"32.9\",\r\n"
												+ " \"address\":\"Vijayawada\",\r\n"
												+ " \"caption\":\"Software services \",\r\n"
												+ " \"majorIndustry\":\"Development\",\r\n"
												+ " \"minorIndustry\":\"services\"\r\n"
												+ " \r\n"
												+ "}\r\n"
												+ "")
										.when().patch("/api/v2/referral/").then().log().all().assertThat().statusCode(200).extract().response().asString();
										System.out.println(UpdateRefferal);
									JsonPath up=new JsonPath(UpdateRefferal);

										String updateRefferalmessage=up.get("message");
										Assert.assertEquals("SUCCESS",updateRefferalmessage );

										
											System.out.println("Postmessage"+updateRefferalmessage);
											Reporter.log("api/v2/referral");
											Reporter.log("statusCode 200");
											Reporter.log("User update Refferal post sucessfully");
											
											Thread.sleep(6000); 
			}	
			
				//Delete 
					/*String deleteRefferal = given().log().all().headers("Content-Type","application/json").param("id", RefferalId)
										.headers("Authorization", a.AuthorizationToken).header("email",mail)
										.when().delete("/api/v2/referral/").then().log().all().assertThat().statusCode(200).extract().response().asString();
										System.out.println(deleteRefferal);
										Reporter.log("Sucessfully Refferal Post deleted");	*/
				//	
		//Referbusiness	
			@Test(priority=4)
			public void Referbusiness() {
				
				String getpersonaldetailsforReferrer = given().log().all().headers("Content-Type","application/json")
						.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail)
						.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
						System.out.println(getpersonaldetailsforReferrer);
						JsonPath Cr1=new JsonPath(getpersonaldetailsforReferrer);
				        String PersonalprofIdforRefferer = Cr1.get("data._id");
				        System.out.println("PersonalUserIdforrefer "+PersonalprofIdforRefferer);
				        
				        String getpersonaldetailsforBuyer = given().log().all().headers("Content-Type","application/json")
								.headers("Authorization", a.buyertoken).header("email",a.buyermail)
								.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
								System.out.println(getpersonaldetailsforBuyer);
								JsonPath Crb1=new JsonPath(getpersonaldetailsforReferrer);
						        String PersonalprofIdforBuyer = Crb1.get("data._id");
						        System.out.println("PersonalUserIdforrefer "+PersonalprofIdforBuyer);
				String RefferalPostget=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.buyermail)
						.headers("Authorization", a.buyertoken).multiPart("postType","referral").multiPart("visibleTo","my_network")
						.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
						.multiPart("createdBy.ref_id",PersonalprofIdforRefferer).multiPart("createdBy.ref_model","personal_profile")
						.multiPart("referralExpiry","2024-06-30 11:55").multiPart("industry","3D Printing").multiPart("lat","16.87")
						.multiPart("long","82.78").multiPart("address","Banglore")
						.when().post("api/v2/referral").then().log().all().assertThat().statusCode(200).extract().response().asString();
						System.out.println(RefferalPostget);
					JsonPath Rs4=new JsonPath(RefferalPostget);
			         String Refferalmessage=Rs4.get("message");
						String RefferalId3=Rs4.get("data._id");
						System.out.println("RefferalId "+RefferalId3);
				
		String referbusinessComment=given().log().all().headers("Content-Type","application/json")
							    	    			.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail)
							    	    			.body("{\r\n"
							    	    					+ "  \"createdBy\": {\r\n"
							    	    					+ "    \"ref_id\": \""+PersonalprofIdforBuyer+"\",\r\n"
							    	    					+ "    \"ref_model\": \"personal_profile\"\r\n"
							    	    					+ "  },\r\n"
							    	    					+ "  \"mention\":[\r\n"
							    	    					+ "    {\r\n"
							    	    					+ "    \"index\": 0,\r\n"
							    	    					+ "    \"profileId\": \""+a.Businessid+"\",\r\n"
							    	    					+ "    \"profileType\": \"business_profile\"\r\n"
							    	    					+ "}\r\n"
							    	    					+ "],\r\n"
							    	    					+ "  \"text\":\"hello\",\r\n"
							    	    					+ "\"feedId\": \""+RefferalId3+"\",\r\n"
							    	    					+ "\"feedType\": \"referral\",\r\n"
							    	    					+ "\"postType\": \"referral\"\r\n"
							    	    					
							    	    					+ "}")	    	    			
							    	    			.when().post("api/v2/comment/").then().log().all().assertThat().statusCode(200).extract().response().asString();
							    	    			System.out.println(referbusinessComment);
							    	    			JsonPath referB=new JsonPath(referbusinessComment);
							   			         String Referecommentmessage=referB.get("message");
							   			         String CommentId = referB.get("data._id");
													Assert.assertEquals("SUCCESS",Referecommentmessage );


							    	    			Reporter.log("api/v2/comment/");
							    					Reporter.log("statusCode 200");
							    	    			Reporter.log("Business refer to Buyer Sucessfully");
							    	    			
							    	    			String Createbuyernotes = given().log().all().headers("Content-Type","application/json")
							    	    					.headers("Authorization", a.buyertoken).header("email",a.buyermail).body("{\r\n"
							    	    							+ "  \"referralId\": \""+RefferalId3+"\",\r\n"
							    	    							+ "  \"referrerId\":\""+PersonalprofIdforRefferer+"\",\r\n"
							    	    							+ "  \"receiverIds\": [\r\n"
							    	    							+ "    \""+a.Businessid+"\"\r\n"
							    	    							+ "    \r\n"
							    	    							+ "  ],\r\n"
							    	    							+ "  \"note\": \"Hey , I’m looking for a dairy gfarm copany and you have been referrd to me. I saw your profile, can we connect?\",\r\n"
							    	    							+ "  \"createdBy\": {\r\n"
							    	    							+ "    \"ref_id\": \""+PersonalprofIdforBuyer+"\",\r\n"
							    	    							+ "    \"ref_model\": \"personal_profile\"\r\n"
							    	    							+ "  },\r\n"
							    	    							+ "  \"commentId\": \""+CommentId+"\"\r\n"
							    	    							+ "}").
							    	    				when().post("api/v2/referral/create-buyer-notes").then().log().all().assertThat().statusCode(200).extract().response().asString();
							    	    			JsonPath BNotes=new JsonPath(Createbuyernotes);
							    	    		    String Createnotemessage=BNotes.get("message");
							    	    				Assert.assertEquals("SUCCESS",Createnotemessage );
							    	    				Reporter.log("api/v2/referral/create-buyer-notes");
							    	    				Reporter.log("statusCode 200");
							    	    			             
							    	    			Reporter.log("Seller Created Buyernotes Sucessfully");
							    	    					
							    	    			           //Get buyernotes
							    	    			String GetBuyernotes = given().log().all().headers("Content-Type","application/json").header("email",a.sellermail).headers("Authorization", a.sellermail).body("{\r\n"
							    	    					+ "  \"referralId\": \""+RefferalId3+"\",\r\n"
							    	    					+ "  \"receiverId\": \""+a.Businessid+"\",\r\n"
							    	    					+ "  \"createdBy\": {\r\n"
							    	    					+ "    \"ref_id\": \"PersonalprofIdforBuyer\",\r\n"
							    	    					+ "    \"ref_model\": \"personal_profile\"\r\n"
							    	    					+ "  }\r\n"
							    	    					+ "}").
							    	    				when().post("api/v2/referral/get-buyer-notes").then().log().all().assertThat().statusCode(200).extract().response().asString();
							    	    			JsonPath GetBNotes=new JsonPath(Createbuyernotes);
							    	    		    String Getnotemessage=GetBNotes.get("message");
							    	    				Assert.assertEquals("SUCCESS",Getnotemessage );
							    	    				Reporter.log("api/v2/referral/get-buyer-notes");
							    	    				Reporter.log("statusCode 200");
							    	    			
							    	    			Reporter.log("User Retrieve Buyer Notes Sucessfully");			    	    			
							    	    			
			}
			@Test(priority=5)
			public void getworkcenter() {
		//workcenter
		String getworkcenter = given().log().all().headers("Content-Type","application/json").param("skip","0").param("limit", "3")
				.param("type", "allLead").headers("Authorization", a.SellerToken).header("email",a.sellermail).
													when().get("/api/v2/referral/business").then().log().all().assertThat().statusCode(200).extract().response().asString();
													System.out.println(getworkcenter);
													
													JsonPath getworkcentermess=new JsonPath(getworkcenter);
								   			         String getworkcentermessage=getworkcentermess.get("message");
														Assert.assertEquals("SUCCESS",getworkcentermessage );

													Reporter.log("/api/v2/referral/business");
							    					Reporter.log("statusCode 200");
							    	    			Reporter.log("Workcenter details retrieve sucessfully");
													
			}
			@Test(priority=6)
			public void ClosedBusiness() {
				String getClosedBusinee = given().log().all().headers("Content-Type","application/json").param("skip","0").param("limit", "3").param("businessId", a.Businessid)
						.param("type", "all").headers("Authorization", a.SellerToken).header("email",a.sellermail).
															when().get("/api/v2/referral/closedBusiness").then().log().all().assertThat().statusCode(200).extract().response().asString();
															System.out.println(getClosedBusinee);
															
															JsonPath getclosedBmess=new JsonPath(getClosedBusinee);
										   			         String getCbusinessmessage=getclosedBmess.get("message");
																Assert.assertEquals("SUCCESS",getCbusinessmessage );

															Reporter.log("/api/v2/referral/closedBusiness");
									    					Reporter.log("statusCode 200");
									    	    			Reporter.log("Workcenter closed Business deatails retrieve sucessfully");
				
			}
			@Test(priority=7)
			public void GetreferralCount() {
			String getRefferalCount = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.buyertoken).header("email",a.buyermail).
					when().get("/api/v2/referral/activityCount").then().log().all().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getRefferalCount);
					
					JsonPath ReferralCount=new JsonPath(getRefferalCount);
  			         String Countofreferral=ReferralCount.get("message");
						Assert.assertEquals("SUCCESS",Countofreferral );

					Reporter.log("/api/v2/referral/activityCount");
					Reporter.log("statusCode 200");
	    			Reporter.log("Referral Count details retrieve sucessfully");
					
					
			}
			
			@Test(priority=8)
			public void Setpercentage() {
		//Setpercentage
	String setpercentage = given().log().all().headers("Content-Type","application/json")
						.headers("Authorization", a.SellerToken).header("email",a.sellermail).body("{\r\n"
								+ "  \"businessId\": \""+a.Businessid+"\",\r\n"
								+ "  \"percentage\": \"0.1\",\r\n"
								+ "  \"value\": \"10\"\r\n"
								+ "}").
						when().post("api/v2/referral/create-percentage").then().log().all().assertThat().statusCode(200).extract().response().asString();
	JsonPath spb=new JsonPath(setpercentage);
       String setpercentagemessage=spb.get("message");
		Assert.assertEquals("SUCCESS",setpercentagemessage );

	Reporter.log("api/v2/referral/create-percentage");
	Reporter.log("statusCode 200");
  
	Reporter.log("Reward percentage set Sucessfully");
			}
			@Test(priority=9)
			public void Getpercentage() {
	//Getpercentage
	String Getpercentage = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.SellerToken).header("email",a.sellermail).param("id",a.Businessid).
		when().get("api/v2/referral/get-percentage").then().log().all().assertThat().statusCode(200).extract().response().asString();
	
	JsonPath Gpb=new JsonPath(Getpercentage);
    String Getpercentagemessage=Gpb.get("message");
		Assert.assertEquals("SUCCESS",Getpercentagemessage );

	
	Reporter.log("api/v2/referral/get-percentage");
	Reporter.log("statusCode 200");
  
	Reporter.log("Retrieve Reward percentage sucessfully");
			}
			@Test(priority=10)
			public void Getpercentageunset() {
				String Getunsetpercentage = given().log().all().headers("Content-Type","application/json")
						.headers("Authorization", a.SellerToken).header("email",a.sellermail).param("id",a.Businessid).
					when().get("/api/v2/referral/get-percentage-unset").then().log().all().assertThat().statusCode(200).extract().response().asString();
				
				JsonPath Gpuset=new JsonPath(Getunsetpercentage);
			    String Getunsetpercentagemessage=Gpuset.get("message");
					Assert.assertEquals("SUCCESS",Getunsetpercentagemessage );

				
				Reporter.log("/api/v2/referral/get-percentage-unset");
				Reporter.log("statusCode 200");
			  
				Reporter.log("Retrieve Reward percentage sucessfully");
			}
			
			
			
			
			
			@Test(priority=11)
			public void Referraldashboard() {
	//Referral dashboard
				String getpersonaldetailsforDashboard = given().log().all().headers("Content-Type","application/json")
						.headers("Authorization", a.buyertoken).header("email",a.buyermail)
						.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
						System.out.println(getpersonaldetailsforDashboard);
						JsonPath Cr5=new JsonPath(getpersonaldetailsforDashboard);
				        String PersonalprofIdfordashboard = Cr5.get("data._id");
				        System.out.println("PersonalUserIdfordashboard "+PersonalprofIdfordashboard);
				String RefferalPostget=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.buyermail)
						.headers("Authorization", a.buyertoken).multiPart("postType","referral").multiPart("visibleTo","my_network")
						.multiPart("caption","Looking for indirect referral").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
						.multiPart("createdBy.ref_id",PersonalprofIdfordashboard).multiPart("createdBy.ref_model","personal_profile")
						.multiPart("referralExpiry","2024-06-30 11:55").multiPart("industry","3D Printing").multiPart("lat","16.87")
						.multiPart("long","82.78").multiPart("address","Banglore")
						.when().post("api/v2/referral").then().log().all().assertThat().statusCode(200).extract().response().asString();
						System.out.println(RefferalPostget);
					JsonPath Rs5=new JsonPath(RefferalPostget);
			         String Refferalmessage=Rs5.get("message");
			         
						String RefferalId4=Rs5.get("data._id");
						System.out.println("RefferalId "+RefferalId4);
						
	String Getdashboard = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.SellerToken).header("email",a.sellermail).param("id",a.Businessid).
		when().get("api/v2/referral/dashboard").then().log().all().assertThat().statusCode(200).extract().response().asString();
	JsonPath Gdashboard=new JsonPath(Getdashboard);
    String Getdashboardmessage=Gdashboard.get("message");
		Assert.assertEquals("SUCCESS",Getdashboardmessage );
		Reporter.log("api/v2/referral/dashboard");
		Reporter.log("statusCode 200");
	  
		Reporter.log("Referral dashboard data retrieve sucessfully");

			
	//Create buyer notes
		
		String getpersonaldetailsforclosedeal = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail)
				.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(getpersonaldetailsforclosedeal);
				JsonPath Closereferrer=new JsonPath(getpersonaldetailsforclosedeal);
		        String PersonalprofIdforcloseRefferer = Closereferrer.get("data._id");
				JsonPath ClosereferrerName=new JsonPath(getpersonaldetailsforclosedeal);

		        String ReferrerName=ClosereferrerName.get("name");
		        System.out.println("PersonalUserIdforreferclose "+PersonalprofIdforcloseRefferer);
		        
		       
		
	
			
//referralRemove
	/*String Removereferral=given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.buyertoken).header("email",mail).param("id",RefferalId).
		when().post("api/v2/referral/remove").then().log().all().assertThat().statusCode(200).extract().response().asString();
*///Updatestatues
	String updatestatusreferral=given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.buyertoken).header("email",a.buyermail).body("{\r\n"
					+ "  \"sendReward\": \"false\",\r\n"
					+ "  \"status\": \"reported\",\r\n"
					+ "  \"report\": {\r\n"
					+ "    \"type\": \"heyy\",\r\n"
					+ "    \"text\": \"heyy\",\r\n"
					+ "    \"status\": \"pending\",\r\n"
					+ "    \"resolution\": \"heyy\"\r\n"
					+ "  }\r\n"
					+ "}").
		when().patch("/api/v2/referral/updateStatus?id="+RefferalId4+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
	//Close deal
	

			String closedeal = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.buyertoken).header("email",a.buyermail).param("id",RefferalId4).
					body("{\r\n"
							+ "  \"status\": \"close\",\r\n"
							+ "  \"reason\": \"good\",\r\n"
							+ "  \"closeDeal\": [\r\n"
							+ "    {\r\n"
							+ "      \"dealClosedBy\": \"seller\",\r\n"
							+ "      \"referrerList\": [\r\n"
							+ "        {\r\n"
							+ "          \"referrerName\": \""+ReferrerName+"\",\r\n"
							+ "          \"userId\": \""+PersonalprofIdforcloseRefferer+"\",\r\n"
							+ "          \"image\": \"\"\r\n"
							+ "        }\r\n"
							+ "      ],\r\n"
							+ "      \"businessId\": \""+a.Businessid+"\",\r\n"
							+ "      \"businessName\": \""+a.BusinessName+"\",\r\n"
							+ "      \"currencyType\": \"USD\",\r\n"
							+ "      \"businessValue\": \"100\",\r\n"
							+ "      \"businessImage\": \"\"\r\n"
							+ "    }\r\n"
							+ "  ]\r\n"
							+ "}")
				.when().patch("/api/v2/referral/closeDeal?id="+RefferalId4+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
			
			JsonPath cdeal=new JsonPath(closedeal);
		    String Closedealmessage=cdeal.get("message");
				Assert.assertEquals("SUCCESS",Closedealmessage );
				Reporter.log("api/v2/referral/closeDeal");
				Reporter.log("statusCode 200");
			
			Reporter.log("Referral Deal Sucessfully");
			// Get Referral post
			
			
			
			// Report Closure
	
			String Reportclosure=given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.buyertoken).header("email",a.buyermail).body("{\r\n"
							+ "  \"reportedClosure\": [\r\n"
							+ "    {\r\n"
							+ "      \"closedBy\": \"buyer\",\r\n"
							+ "      \"status\": \"open\",\r\n"
							+ "      \"reason\": \"open\",\r\n"
							+ "      \"businessId\": \""+a.Businessid+"\"\r\n"
							+ "    }\r\n"
							+ "  ]\r\n"
							+ "}").
				when().patch("/api/v2/referral/reportedClosure?id="+RefferalId4+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
			JsonPath RClosure=new JsonPath(Reportclosure);
		    String Closuremessage=RClosure.get("message");  
				Assert.assertEquals("SUCCESS",Closuremessage );
				Reporter.log("/api/v2/referral/reportedClosure");
				Reporter.log("statusCode 200");
			
			
			}
			
			@Test(priority=12)
			public void GetJob() {
					String getJobApi = given().log().all().headers("Content-Type","application/json").param("skip","0").param("limit", "3")
							.param("type", "allLeads").headers("Authorization", a.SellerToken).header("email",a.sellermail).
																when().get("/api/v2/referral/job").then().log().all().assertThat().statusCode(200).extract().response().asString();
																System.out.println(getJobApi);
																
																JsonPath getJobDetails=new JsonPath(getJobApi);
											   			         String getjobmessage=getJobDetails.get("message");
																	Assert.assertEquals("SUCCESS",getjobmessage );

																Reporter.log("/api/v2/referral/job");
										    					Reporter.log("statusCode 200");
										    	    			Reporter.log("Workcenter  job referral deatails retrieve sucessfully");
					
				
			}
			@Test(priority=13)
			public void ClosedJOB() {
				String getClosedJob = given().log().all().headers("Content-Type","application/json").param("skip","0").param("limit", "3")
						.param("type", "all").headers("Authorization", a.SellerToken).header("email",a.sellermail).
															when().get("/api/v2/referral/closedJob").then().log().all().assertThat().statusCode(200).extract().response().asString();
															System.out.println(getClosedJob);
															
															JsonPath getclosedjobmess=new JsonPath(getClosedJob);
										   			         String getCjobmessage=getclosedjobmess.get("message");
																Assert.assertEquals("SUCCESS",getCjobmessage );

															Reporter.log("/api/v2/referral/closedJob");
									    					Reporter.log("statusCode 200");
									    	    			Reporter.log("Workcenter closed Business deatails retrieve sucessfully");
				
			}
			
			
			@Test(priority=14)
			public void DirectreferralCreate() {
			//Directreferral
				
				String getpersonaldetailscreatedirectref = given().log().all().headers("Content-Type","application/json")
						.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail)
						.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
						System.out.println(getpersonaldetailscreatedirectref);
						JsonPath Cref=new JsonPath(getpersonaldetailscreatedirectref);
				        String PersonalprofIdforDirectrefe = Cref.get("data._id");	
				
				
				
				
	String getbuyerdirect = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.buyertoken).header("email",a.buyermail)
			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getbuyerdirect);
			JsonPath cpr=new JsonPath(getbuyerdirect);
	        String Personalbuyerdirect = cpr.get("data._id");
	        System.out.println("PersonalUserId "+Personalbuyerdirect);
	        

	String Createdirectreferral = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail).body("{\r\n"
					+ "  \"postType\": \"directReferral\",\r\n"
					+ "  \"createdBy\": {\r\n"
					+ "    \"ref_id\": \""+PersonalprofIdforDirectrefe+"\",\r\n"
					+ "    \"ref_model\": \"personal_profile\"\r\n"
					+ "  },\r\n"
					+ "  \"buyerType\": \"internal\",\r\n"
					+ "  \"sellerType\": \"external\",\r\n"
					+ "  \"buyer\": {\r\n"
					+ "    \"ref_id\": \""+Personalbuyerdirect+"\",\r\n"
					+ "    \"ref_model\": \"personal_profile\",\r\n"
					+ "    \"message\": \"Hi , since you were looking for a bikes shop, I'm referring one.\",\r\n"
					+ "    \"mention\": [\r\n"
					+ "      {\r\n"
					+ "        \"index\": 6,\r\n"
					+ "        \"profileId\": \""+Personalbuyerdirect+"\",\r\n"
					+ "        \"profileType\": \"personal_profile\"\r\n"
					+ "      }\r\n"
					+ "    ]\r\n"
					+ "  },\r\n"
					+ "  \"seller\": {\r\n"
					+ "    \"ref_id\": \""+a.Businessid+"\",\r\n"
					+ "    \"ref_model\": \"business_profile\",\r\n"
					+ "    \"message\": \"Hi, I'm referring your shop to my friend here who's looking for some bikes.\",\r\n"
					+ "    \"mention\": [\r\n"
					+ "      {\r\n"
					+ "        \"index\": 6,\r\n"
					+ "        \"profileId\": \""+a.Businessid+"\",\r\n"
					+ "        \"profileType\": \"business_profile\"\r\n"
					+ "      }\r\n"
					+ "    ]\r\n"
					+ "  }\r\n"
					+ " \r\n"
					+ "}\r\n"
					+ "").
		when().post("/api/v2/referral/directReferral").then().log().all().assertThat().statusCode(200).extract().response().asString();
	JsonPath Dr=new JsonPath(Createdirectreferral);
    String DirectReferralmessage=Dr.get("message");
    String Directreferralid=Dr.get("[0].data._id");
		Assert.assertEquals("SUCCESS",DirectReferralmessage );
		Reporter.log("/api/v2/referral/directReferral");
		Reporter.log("statusCode 200");
	
	Reporter.log("Direct Referral Created Sucessfully");
	
	
	
			}
	
											
			}									
							



