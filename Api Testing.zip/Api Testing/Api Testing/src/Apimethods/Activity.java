package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Activity {
	AuthorizationToken a=new AuthorizationToken(); 
	Personal p=new Personal();
	@Test(priority=1)
		public void Getpersonalactivity() throws InterruptedException {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

		String getpersonalActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
				.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "all")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("/api/v2/activity/get-personal-activity").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(getpersonalActivity);
				
				JsonPath JA1=new JsonPath(getpersonalActivity);
				
								String businessgetMessage=JA1.get("message");
								System.out.println("businessgetapi message"+businessgetMessage);
								Assert.assertEquals("SUCCESS",businessgetMessage );
								
			String getcreatedpersonalActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
										.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "created")
										.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
										.when().get("/api/v2/activity/get-personal-activity").then().assertThat().statusCode(200).extract().response().asString();
										System.out.println(getcreatedpersonalActivity);
										
										JsonPath JE1=new JsonPath(getcreatedpersonalActivity);
										
			                                 String PersonalcreatedMessage=JE1.get("message");
														System.out.println("personalCreatedapi message"+PersonalcreatedMessage);
														Assert.assertEquals("SUCCESS",PersonalcreatedMessage );
														
	String getcommentedpersonalActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
																.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "created")
																.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
																.when().get("/api/v2/activity/get-personal-activity").then().assertThat().statusCode(200).extract().response().asString();
																System.out.println(getcommentedpersonalActivity);
																
																JsonPath JE2=new JsonPath(getcommentedpersonalActivity);
																
																				String PersonalcommentedapiMessage=JE2.get("message");
																				System.out.println("personalCommentedapi message"+PersonalcommentedapiMessage);
																				Assert.assertEquals("SUCCESS",PersonalcommentedapiMessage );								
																					
String getlikededpersonalActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
																						.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "created")
																						.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
																						.when().get("/api/v2/activity/get-personal-activity").then().assertThat().statusCode(200).extract().response().asString();
																						System.out.println(getlikededpersonalActivity);
																						
																						JsonPath JE3=new JsonPath(getlikededpersonalActivity);
																						
																										String PersonallikedapiMessage=JE3.get("message");
																										System.out.println("personalCommentedapi message"+PersonallikedapiMessage);
																										Assert.assertEquals("SUCCESS",PersonallikedapiMessage );								
		
String getrepostpersonalActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
									.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "created")
									.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
								   .when().get("/api/v2/activity/get-personal-activity").then().assertThat().statusCode(200).extract().response().asString();
								     System.out.println(getrepostpersonalActivity);
																												
								JsonPath JE4=new JsonPath(getrepostpersonalActivity);
																												
							String PersonalrepostapiMessage=JE4.get("message");
							System.out.println("personalCommentedapi message"+PersonalrepostapiMessage);
							Assert.assertEquals("SUCCESS",PersonalrepostapiMessage );
String getmentionedpersonalActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
									.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "created")
									.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
								   .when().get("/api/v2/activity/get-personal-activity").then().assertThat().statusCode(200).extract().response().asString();
								     System.out.println(getmentionedpersonalActivity);
																												
								JsonPath JE5=new JsonPath(getmentionedpersonalActivity);
																												
							String PersonalmentionedapiMessage=JE5.get("message");
							System.out.println("personalCommentedapi message"+PersonalmentionedapiMessage);
							Assert.assertEquals("SUCCESS",PersonalmentionedapiMessage );							
							
																																	
				Reporter.log("Endpoint :/api/v2/activity/get-personal-activity");
		        Reporter.log("StatusCode :200");
					Reporter.log("Retrieved personal profile activity sucessfully");
	}
	@Test(priority=2)
	public void Getsocialpost() throws InterruptedException {
	RestAssured.baseURI="http://hcpdev.curd.network:3000";

	String getsocialpostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
			.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "all")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("/api/v2/activity/social-post").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getsocialpostActivity);
			
			JsonPath JA2=new JsonPath(getsocialpostActivity);
			
							String businessgetMessage=JA2.get("message");
							System.out.println("businessgetapi message"+businessgetMessage);
							Assert.assertEquals("SUCCESS",businessgetMessage );
	String getsocialcreatedpostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
									.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "created")
									.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
									.when().get("/api/v2/activity/social-post").then().assertThat().statusCode(200).extract().response().asString();
									System.out.println(getsocialcreatedpostActivity);
									
									JsonPath Jsp1=new JsonPath(getsocialcreatedpostActivity);
									
										String CreatedpostMessage=Jsp1.get("message");
													System.out.println("socialcreatedapi message"+CreatedpostMessage);
													Assert.assertEquals("SUCCESS",CreatedpostMessage );
	String getsocialcommentedpostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
															.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "commented")
															.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
															.when().get("/api/v2/activity/social-post").then().assertThat().statusCode(200).extract().response().asString();
															System.out.println(getsocialcommentedpostActivity);
															
															JsonPath Jsp2=new JsonPath(getsocialcommentedpostActivity);
															
																			String CommentedpostMessage=Jsp2.get("message");
																			System.out.println("socialcommentedapi message"+CommentedpostMessage);
																			Assert.assertEquals("SUCCESS",CommentedpostMessage );
 String getsociallikepostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
																					.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "liked")
																					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
																					.when().get("/api/v2/activity/social-post").then().assertThat().statusCode(200).extract().response().asString();
																					System.out.println(getsociallikepostActivity);
																					
																					JsonPath Jsp3=new JsonPath(getsociallikepostActivity);
																					
																									String likedpostMessage=Jsp3.get("message");
																									System.out.println("sociallikeapi message"+likedpostMessage);
																									Assert.assertEquals("SUCCESS",likedpostMessage );

String getsocialrepostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
								.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "repost")
								.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
								.when().get("/api/v2/activity/social-post").then().assertThat().statusCode(200).extract().response().asString();
									System.out.println(getsocialrepostActivity);
																												
									JsonPath Jsp4=new JsonPath(getsocialrepostActivity);
																												
									String socialrepostMessage=Jsp4.get("message");
									System.out.println("socialrepostapi message"+socialrepostMessage);
									Assert.assertEquals("SUCCESS",socialrepostMessage );
																									
			Reporter.log("Endpoint :/api/v2/activity/social-post");
	        Reporter.log("StatusCode :200");
				Reporter.log("Retrieved social post activity sucessfully");
}
	@Test(priority=3)
	public void Getprofessionalpost() throws InterruptedException {
	RestAssured.baseURI="http://hcpdev.curd.network:3000";

	String getprofessionalpostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
			.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "all")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("/api/v2/activity/professional-post").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getprofessionalpostActivity);
			
			JsonPath JA3=new JsonPath(getprofessionalpostActivity);
			
							String professionalallactivityMessage=JA3.get("message");
							System.out.println("professional all activity message"+professionalallactivityMessage);
							Assert.assertEquals("SUCCESS",professionalallactivityMessage );

			String getprofessionalcreatedpostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
					.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "created")
									.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
									.when().get("/api/v2/activity/professional-post").then().assertThat().statusCode(200).extract().response().asString();
									System.out.println(getprofessionalcreatedpostActivity);
									
									JsonPath JA10=new JsonPath(getprofessionalcreatedpostActivity);
									
													String professionalcreatedMessage=JA10.get("message");
													System.out.println("professionalcreated activity message"+professionalcreatedMessage);
													Assert.assertEquals("SUCCESS",professionalcreatedMessage );	
						String getprofessionalcommentedpostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
															.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "created")
																			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
																			.when().get("/api/v2/activity/professional-post").then().assertThat().statusCode(200).extract().response().asString();
																			System.out.println(getprofessionalcommentedpostActivity);
																			
																			JsonPath JA11=new JsonPath(getprofessionalcommentedpostActivity);
																			
																							String professionalcommentedMessage=JA11.get("message");
																							System.out.println("professionalcommented activity message"+professionalcommentedMessage);
																							Assert.assertEquals("SUCCESS",professionalcreatedMessage );	
															
			
						String getprofessionallikepostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
																.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "created")
													.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
														.when().get("/api/v2/activity/professional-post").then().assertThat().statusCode(200).extract().response().asString();
														System.out.println(getprofessionallikepostActivity);
																													
													JsonPath JA12=new JsonPath(getprofessionallikepostActivity);
																													
												 String professionallikeMessage=JA11.get("message");
												System.out.println("professionalcommented activity message"+professionallikeMessage);
											Assert.assertEquals("SUCCESS",professionallikeMessage );	
																									
		String getprofessionalrepostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
													.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "created")
										.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
											.when().get("/api/v2/activity/professional-post").then().assertThat().statusCode(200).extract().response().asString();
											System.out.println(getprofessionalrepostActivity);
																										
										JsonPath JA13=new JsonPath(getprofessionalrepostActivity);
																										
									 String professionalrepostMessage=JA13.get("message");
									System.out.println("professionalrepost activity message"+professionalrepostMessage);
								Assert.assertEquals("SUCCESS",professionalrepostMessage );																									
			Reporter.log("Endpoint :/api/v2/activity/professional-post");
	        Reporter.log("StatusCode :200");
				Reporter.log("Retrieved professional post activity sucessfully");
}
	@Test(priority=4)
	public void Getaskforreferralactivity() throws InterruptedException {
	RestAssured.baseURI="http://hcpdev.curd.network:3000";

	String getaskforreferralpostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
			.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "created")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("/api/v2/activity/ask-for-referral").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getaskforreferralpostActivity);
			
			JsonPath JA4=new JsonPath(getaskforreferralpostActivity);
			
							String getreferralactivityMessage=JA4.get("message");
							System.out.println(" getreferralactivity Created Message"+getreferralactivityMessage);
							Assert.assertEquals("SUCCESS",getreferralactivityMessage );
							
							String getaskforreferralpostmentionActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
									.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "mentioned")
									.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
									.when().get("/api/v2/activity/ask-for-referral").then().assertThat().statusCode(200).extract().response().asString();
									System.out.println(getaskforreferralpostmentionActivity);
									
									JsonPath JA6=new JsonPath(getaskforreferralpostmentionActivity);
									
													String getreferralactivitymentionMessage=JA6.get("message");
													System.out.println(" getreferralactivity Mention Message"+getreferralactivitymentionMessage);
													Assert.assertEquals("SUCCESS",getreferralactivitymentionMessage );

													
													String getaskforreferralRepostpostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
															.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid).param("type", "reposted")
															.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
															.when().get("/api/v2/activity/ask-for-referral").then().assertThat().statusCode(200).extract().response().asString();
															System.out.println(getaskforreferralRepostpostActivity);
															
															JsonPath JA7=new JsonPath(getaskforreferralRepostpostActivity);
															
																			String getreferralactivityRepostMessage=JA7.get("message");
																			System.out.println(" getreferralactivity Created Message"+getreferralactivityRepostMessage);
																			Assert.assertEquals("SUCCESS",getreferralactivityRepostMessage );

													

			Reporter.log("Endpoint :/api/v2/activity/ask-for-referral");
	        Reporter.log("StatusCode :200");
				Reporter.log("Retrieved ask for a referral post activity sucessfully");
}	
	@Test(priority=5)
	public void Getreferfriedactivity() throws InterruptedException {
	RestAssured.baseURI="http://hcpdev.curd.network:3000";

	String getreferfriendpostActivity = given().log().all().headers("Content-Type","application/json").param("skip", "0")
			.param("limit", "5").param("personalId",p.PersonalprofileId).param("userId", p.Personalprofileuserid)
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("/api/v2/activity/refer-friend").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getreferfriendpostActivity);
			
			JsonPath JA5=new JsonPath(getreferfriendpostActivity);
			
							String getreferralactivityMessage=JA5.get("message");
							System.out.println(" getreferralactivity Created Message"+getreferralactivityMessage);
							Assert.assertEquals("SUCCESS",getreferralactivityMessage );

			Reporter.log("Endpoint :/api/v2/activity/refer-friend");
	        Reporter.log("StatusCode :200");
				Reporter.log("Retrieved refer friend post activity sucessfully");
}		        
}

