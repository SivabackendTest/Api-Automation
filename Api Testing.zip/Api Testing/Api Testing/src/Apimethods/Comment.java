package Apimethods;

import org.testng.Reporter;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.given;

public class Comment {
	AuthorizationToken a=new AuthorizationToken();
@Test(priority=1)

	public void CommentApi() {
 		RestAssured.baseURI="http://hcpdev.curd.network:3000";

		String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
    			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
    			System.out.println(getpersonaldetails);
    			JsonPath comt=new JsonPath(getpersonaldetails);
    	        String PersonalprofIdforComment = comt.get("data._id");
    	        System.out.println("PersonalUserId "+PersonalprofIdforComment);
    	        
    	        String PostforComment=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
    					.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","everyone")
    					.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
    					.multiPart("createdBy.ref_id",PersonalprofIdforComment).multiPart("createdBy.ref_model","personal_profile").multiPart("isRepost","false")
    					.when().post("api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();		System.out.println(PostforComment);
    	    		JsonPath Rs1=new JsonPath(PostforComment);

    	    			String postcommentmessage=Rs1.get("message");
    	    			String postIdcomment=Rs1.get("data._id");
    	    			System.out.println("postIdComment "+postIdcomment);
    	    				System.out.println("postCommentmessage"+postcommentmessage);       

	  String PostComment=given().log().all().headers("Content-Type","application/json")
  			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
  					+ "  \"createdBy\": {\r\n"
  					+ "    \"ref_id\": \""+PersonalprofIdforComment+"\",\r\n"
  					+ "    \"ref_model\": \"personal_profile\"\r\n"
  					+ "  },\r\n"
  					+ "  \"text\": \"good\",\r\n"
  					+ "  \"feedId\": \""+postIdcomment+"\",\r\n"
  					+ "  \"feedType\": \"post\"\r\n"
  					+ "}")	    	    			
  			.when().post("api/v2/comment").then().log().all().assertThat().statusCode(200).extract().response().asString();
  			System.out.println(PostComment);
  		JsonPath Comm=new JsonPath(PostComment);

  			String Commentmessage=Comm.get("message");
  			String CommentId=Comm.get("data._id");
  			System.out.println("postId "+CommentId);
  				System.out.println("Comment message"+Commentmessage);
  				Reporter.log("api/v2/comment");
				Reporter.log("statusCode 200");
  				Reporter.log("User Create Comment sucessfully"); 
  				
// Get Comment 

 	String getComment = given().log().all().headers("Content-Type","application/json")
  			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
  					+ "  \"id\": \""+CommentId+"\"\r\n"
  					+ "}").
  			when().post("/api/v2/comment/getComment").then().log().all().assertThat().statusCode(200).extract().response().asString();
  			System.out.println(getComment);
  						
  			JsonPath Getcomm=new JsonPath(getComment);
  			String GetRefferalmessage=Getcomm.get("message");
  						
  				System.out.println("commentgetmessage"+GetRefferalmessage);
  				Reporter.log("/api/v2/comment/getComment");
				Reporter.log("statusCode 200");
  				Reporter.log("User retrieve Comment data sucessfully");
  				
// Commentcount

  	String getCommentcountuser = given().log().all().headers("Content-Type","application/json")
	    	   	.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
	    	   			+ "  \"feedId\": \""+postIdcomment+"\"\r\n"
	    	   			+ "}").
	    	    			when().post("api/v2/comment/count").then().log().all().assertThat().statusCode(200).extract().response().asString();
	    	    			System.out.println(getCommentcountuser);
	    	    						
	    	    			JsonPath Getcommcount=new JsonPath(getComment);
	    	    			String Getcountmessage=Getcommcount.get("message");
	    	    						
	    	    				System.out.println("Getcountmessage "+Getcountmessage);
	    	    				Reporter.log("api/v2/comment/count");
	    	    				Reporter.log("statusCode 200");
	    	    				Reporter.log("User comment count retrieve sucessfully"); 
	    	    				
//Delete Comment
	
	  	String deleteComment = given().log().all().headers("Content-Type","application/json").param("id", CommentId)
							.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
							.when().delete("api/v2/comment").then().log().all().assertThat().statusCode(200).extract().response().asString();
										System.out.println(deleteComment);
			
										Reporter.log("api/v2/comment");
			    	    				Reporter.log("statusCode 200");
										Reporter.log("Sucessfully Comment deleted");	    	    				
}



}
