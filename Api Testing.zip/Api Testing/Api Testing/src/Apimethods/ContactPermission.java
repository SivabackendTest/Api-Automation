package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class ContactPermission {
AuthorizationToken a=new AuthorizationToken();
	
	@Test(priority=1)
	public void CreateInfluencer() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

		String CreateContactpermission = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
				.headers("Authorization", a.AuthorizationToken)
				.body("{\r\n"
						+ "  \"phonebook\": {\r\n"
						+ "    \"contactSync\": \"false\",\r\n"
						+ "    \"bulkInvite\": \"false\"\r\n"
						+ "  },\r\n"
						+ "  \"gmail\": {\r\n"
						+ "    \"contactSync\": \"false\",\r\n"
						+ "    \"bulkInvite\": \"false\"\r\n"
						+ "  },\r\n"
						+ "  \"instagram\": {\r\n"
						+ "    \"contactSync\": \"false\",\r\n"
						+ "    \"bulkInvite\": \"false\"\r\n"
						+ "  },\r\n"
						+ "  \"linkedIn\": {\r\n"
						+ "    \"contactSync\": \"false\",\r\n"
						+ "    \"bulkInvite\": \"false\"\r\n"
						+ "  },\r\n"
						+ "  \"facebook\": {\r\n"
						+ "    \"contactSync\": \"false\",\r\n"
						+ "    \"bulkInvite\": \"false\"\r\n"
						+ "  },\r\n"
						+ "  \"x\": {\r\n"
						+ "    \"contactSync\": \"false\",\r\n"
						+ "    \"bulkInvite\": \"false\"\r\n"
						+ "  },\r\n"
						+ "  \"youtube\": {\r\n"
						+ "    \"contactSync\": \"false\",\r\n"
						+ "    \"bulkInvite\": \"false\"\r\n"
						+ "  }\r\n"
						+ "}")

				.when().post("/api/v2/contactPermission/create-permission").then().log().all().assertThat().statusCode(200).extract().response().asString();
				System.out.println(CreateContactpermission);
				
				JsonPath Conp=new JsonPath(CreateContactpermission);
				String Contactpermissionmessage=Conp.get("message");
				 String Contactpermissionidforuse = Conp.get("data._id");
System.out.println(Contactpermissionidforuse);
				Assert.assertEquals("SUCCESS",Contactpermissionmessage );
				
				Reporter.log("Endpoint :api/v2/contactPermission/create-permission");
		        Reporter.log("StatusCode :200");
				Reporter.log("User Created Contact sync permission sucessfully");
				
//Update contactPermission
				String updateContactsync= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
						.headers("Authorization", a.AuthorizationToken).body("{\r\n"
								+ "  \"phonebook\": {\r\n"
								+ "    \"contactSync\": \"true\",\r\n"
								+ "    \"bulkInvite\": \"false\"\r\n"
								+ "  },\r\n"
								+ "  \"gmail\": {\r\n"
								+ "    \"contactSync\": \"false\",\r\n"
								+ "    \"bulkInvite\": \"false\"\r\n"
								+ "  },\r\n"
								+ "  \"instagram\": {\r\n"
								+ "    \"contactSync\": \"false\",\r\n"
								+ "    \"bulkInvite\": \"false\"\r\n"
								+ "  },\r\n"
								+ "  \"linkedIn\": {\r\n"
								+ "    \"contactSync\": \"false\",\r\n"
								+ "    \"bulkInvite\": \"false\"\r\n"
								+ "  },\r\n"
								+ "  \"facebook\": {\r\n"
								+ "    \"contactSync\": \"false\",\r\n"
								+ "    \"bulkInvite\": \"false\"\r\n"
								+ "  },\r\n"
								+ "  \"x\": {\r\n"
								+ "    \"contactSync\": \"false\",\r\n"
								+ "    \"bulkInvite\": \"false\"\r\n"
								+ "  },\r\n"
								+ "  \"youtube\": {\r\n"
								+ "    \"contactSync\": \"false\",\r\n"
								+ "    \"bulkInvite\": \"false\"\r\n"
								+ "  }\r\n"
								+ "}")
					
						.when().put("/api/v2/contactPermission/update?id="+Contactpermissionidforuse+"").then().assertThat().statusCode(200).extract().response().asString();
						System.out.println(updateContactsync);

						JsonPath Patchcontactsync=new JsonPath(updateContactsync);
						String updatecontactsyncmessage=Patchcontactsync.get("message");
						Assert.assertEquals("SUCCESS",updatecontactsyncmessage );

						Reporter.log("Endpoint :api/v2/contactPermission/update");
						Reporter.log("StatusCode :200");
						Reporter.log("profile influencer details update sucessfully");
				
}
	@Test(priority=2)
	public void GetContactsync() {
		
			String getsync  = given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("api/v2/contactPermission/get-permission").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getsync);
					
					JsonPath PCon=new JsonPath(getsync);
					
									String GetcontactsyncMessage=PCon.get("message");
									System.out.println("businessgetapi message"+GetcontactsyncMessage);
									Assert.assertEquals("SUCCESS",GetcontactsyncMessage );

					Reporter.log("Endpoint :/api/v2/contactPermission/get-permission");
			        Reporter.log("StatusCode :200");
						Reporter.log("User Retrieve Contact sync details sucessful");
}
@Test(priority=3)
public void DeleteContactsync() {
	String getsyncfordelete  = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("api/v2/contactPermission/get-permission").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getsyncfordelete);
			JsonPath Pcontactidfordelete=new JsonPath(getsyncfordelete);
			 String Contactpermissionidfordelete = Pcontactidfordelete.get("data._id");

			System.out.println(Contactpermissionidfordelete);
			
	String deletecontactsync = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().delete("/api/v2/contactPermission/delete?id="+Contactpermissionidfordelete+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(deletecontactsync);
			JsonPath jd=new JsonPath(deletecontactsync);
			String syncdelete=jd.get("message");
			Assert.assertEquals("SUCCESS",syncdelete );


			Reporter.log("Endpoint :/api/v2/contactPermission/delete");
			Reporter.log("StatusCode :200");
			Reporter.log("Sucessfully deleted contact sync details");	
}
}