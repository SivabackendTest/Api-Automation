package Apimethods;

import static io.restassured.RestAssured.given;

import java.util.Scanner;

import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Network {

	AuthorizationToken a=new AuthorizationToken();
	@Test(priority=1)
public void useronboarding() throws InterruptedException {
	
//		//Post-Signup
		//Reporter.log("String date = new java.text.SimpleDateFormat(\"MM/dd/yyyy HH:mm:ss\").format(new java.util.Date (epoch*1000))");
		String mail = "charlies2.curd@yopmail.com";
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
		String Postsignup=given().log().all().header("Content-Type","application/json")
	.body(Payload.postsignup(mail, "GCmFiZvjHJbkaMNCqnDUIbGekc43"))
		.when().post("/api/v2/auth/post-signup").then().log().all().assertThat().statusCode(200).extract().asString();
		System.out.println(Postsignup);
		JsonPath b=new JsonPath(Postsignup);
		String path="data.email";
		String path1="data.uid";
			String signinEmail=b.getString(path);
			System.out.println("email"+signinEmail);
			String signinuid=b.getString(path1);
			System.out.println("Uid"+signinuid);
			Reporter.log("User signup sucessfully");
	//	
		//sign-in
		//RestAssured.baseURI="http://hcpdev.curd.network:3000";
		String Signin = given().log().all().header("Content-Type","application/json").headers("Authorization", a.AuthorizationToken)
		.body("{\r\n"
				+ "  \"email\": \""+signinEmail+"\",\r\n"
				+ "  \"uid\": \""+signinuid+"\",\r\n"
				+ "  \"device\": {\r\n"
				+ "    \"token\": \"deL5_IVSR5Sskgu40DvT3l:APA91bEvwltlTHUybBeWqzOkN1c7jr24fibJDPcY_E-HMRSOThqDzeyElo--8szEQ1NEbVOciE25IO4x8fk6skvhYFicng8IE4hHmB81bp3mrNFCY2RPfwSOo3IIlnHlbkzDP451ScDt\",\r\n"
				+ "    \"os_sdk\": \"34\",\r\n"
				+ "    \"os_version\": \"14\",\r\n"
				+ "    \"isPhysicalDevice\": \"true\",\r\n"
				+ "    \"ip\": \"124.23.24.174\",\r\n"
				+ "    \"os_type\": \"Android\",\r\n"
				+ "    \"app_version\": \"1.10.3\"\r\n"
				+ "  }\r\n"
				+ "}\r\n"
				+ "").when().post("/api/v2/auth/post-signin").then().log().all().assertThat().statusCode(200).extract().asString();
	
		
		//SendOtp
		String sendotpresponse = given().log().all().headers("Content-Type","application/json").headers("Authorization", a.AuthorizationToken)
		.body("{\r\n"
				+ "    \"email\":\""+signinEmail+"\"\r\n"
				+ "}")
		.when().post("api/v2/auth/verify-email").then().assertThat().
		statusCode(200).extract().response().asString();
		System.out.println(sendotpresponse);
	JsonPath js=new JsonPath(sendotpresponse);
	String path2="data.code";
		String postcode=js.getString(path2);
		System.out.println("code"+postcode);
//		
			Scanner sc=new Scanner(System.in);
			int otp = sc.nextInt();
			System.out.println("Enter OTP:"+otp);
			Reporter.log("An OTP has been sent to your device, valid for the next 5 minutes");
			
		//verifyotp
		given().log().all().headers("Content-Type","application/json").headers("Authorization", a.AuthorizationToken)
		.body("{\r\n"
				+ "    \"email\": \""+signinEmail+"\",\r\n"
				+ "    \"otp\": \""+otp+"\",\r\n"
				+ "    \"code\": \""+postcode+"\"\r\n"
				+ "}")
		.when().post("api/v2/auth/confirm-email").then().log().all().assertThat().statusCode(200);
		Reporter.log("Verification Successful");
		//Email-Exist
		given().log().all().header("Content-Type","application/json")
		.body("{\r\n"
				+ "    \"email\":\""+signinEmail+"\"\r\n"
				+ "}")
			.when().post("/api/v2/auth/email-exist").then().log().all().assertThat().statusCode(200);
		//Reset password
		given().log().all().header("Content-Type","application/json")
		.body("{\r\n"
				+ "  \"email\": \""+signinEmail+"\",\r\n"
				+ "  \"password\": \"Ana123@\"\r\n"
				+ "}")
			.when().post("api/v2/auth/reset-password").then().log().all().assertThat().statusCode(200); }
	
		
	
	
}
