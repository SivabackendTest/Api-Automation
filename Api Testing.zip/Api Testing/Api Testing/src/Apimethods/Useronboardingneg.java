package Apimethods;

import static io.restassured.RestAssured.given;

import java.io.File;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
public class Useronboardingneg extends Reusableclass {
	@Test(priority=1)
	public void postsignupwithresigsteredemail() {
		String mail = "anudrada1569@yopmail.com";
		String localid = "oHwMBrOghiW6BVblnh5p3DtCBKV2";
//		String name = mail.substring(0,4);
//		System.out.println(name);
//		String Username = mail.substring(4,11);
//		System.out.println(Username);

		 
		Reusableclass r=new Reusableclass();
	    r.singup(mail, localid);
	     }
	@Test(priority=2)
	public void postsignupwithblackemail() {
		String mail = "      ";
		String localid = "oHwMBrOghiW6BVblnh5p3DtCBKV2";

		 
		Reusableclass r=new Reusableclass();
	    r.withoutemail(mail, localid);
	    
		
	}
	@Test(priority=3)
	public void postsignupwithoutlocalid() {
		String mail = "anudrada1569@yopmail.com";
		String localid = "     ";

		 
		Reusableclass r=new Reusableclass();
	    r.singup(mail, localid);
	    
		
	}
	@Test(priority=4)
	public void signinwithwrongmailid() {
		String mail = "anudrada1569@yopmail.com";
		String localid = "sA4drWFUoDMDxNm3zNPjRK2gW9n2";

		 
		Reusableclass r=new Reusableclass();
	    r.signinwithwrongid(mail, localid);
	    
	}
	@Test(priority=5)
	public void signinwithoutlocalid() {
		String mail = "swamy123@yopmail.com";
		String localid = "";

		 
		Reusableclass r=new Reusableclass();
	    r.signin(mail, localid);
	}
	@Test(priority=6)
	public void signinwithoutmail() {
		String mail = "";
		String localid = "sA4drWFUoDMDxNm3zNPjRK2gW9n2";

		 
		Reusableclass r=new Reusableclass();
	    r.signin(mail, localid);
	}
	@Test(priority=7)
	public void Sendotpwithoutmail() {
		String Email = " ";
		Reusableclass r=new Reusableclass();
	    r.SendOtp(Email);
	}
	@Test(priority=8)
	public void Sendotpwithinvalidmail() {
		String Email = "@yopmail.com";
		Reusableclass r=new Reusableclass();
	    r.SendOtp(Email);
	}
	@Test(priority=9)
	public void Sendotpwithspecialchar() {
		String Email = "**@yopmail.com ";
		Reusableclass r=new Reusableclass();
	    r.SendOtp(Email);
	}
	@Test(priority=10)
	public void Otpallblack() {
	String Email = "";
			String otp = "";
					String postcode = "";
		Reusableclass r=new Reusableclass();
	    r.VerifyOtp(Email, otp, postcode);
	
}
	@Test(priority=11)
	public void Otpwithvalidcode() {
	String Email = "venkata123@yopmail.com";
			String otp = "";
					//String postcode = "";
		Reusableclass r=new Reusableclass();
	    r.validcodeotp(Email, otp);
}
	@Test(priority=12)
	public void Otpwithinvalidotp() {
	String Email = "venkata123@yopmail.com";
			String otp = "112215";
					//String postcode = "";
		Reusableclass r=new Reusableclass();
	    r.invalidotp(Email, otp);
}
	@Test(priority=13)
	public void withoutsetpassword() {
	String Email = "venkata123@yopmail.com";
		String Password = "";
		Reusableclass r=new Reusableclass();
	    r.emptysetpassword(Email, Password);
}
	@Test(priority=14)
	public void withoutmailsetpassword() {
	String Email = "";
		String Password = "Anasu@125";
		Reusableclass r=new Reusableclass();
	    r.emptysetpassword(Email, Password);
}
	@Test(priority=15)
	public void setpasswordnonexistingUser() {
	String Email = "SivaDec25@yopmail.com";
		String Password = "Anasu@125";
		Reusableclass r=new Reusableclass();
	    r.setpasswordnonexistingUser(Email, Password);
}
	@Test(priority=16)
	public void setpasswordinvalidmail() {
	String Email = "@yopmail.com";
		String Password = "Anasu@125";
		Reusableclass r=new Reusableclass();
	    r.emptysetpassword(Email, Password);
}
	@Test(priority=17)
	public void setpasswordwithnulldata() {
	String Email = "";
		String Password = "";
		Reusableclass r=new Reusableclass();
	    r.emptysetpassword(Email, Password);
}	
	@Test(priority=18)
	public void Existingemailwithnull() {
	String Email = "";
		Reusableclass r=new Reusableclass();
	    r.ExistingEmail(Email);
}		
	@Test(priority=19)
	public void ExistingEmailnotregister() {
	String Email = "sivaDec36@yopmail.com";
		Reusableclass r=new Reusableclass();
	    r.ExistingEmailnonexistinguser(Email);
}			
	@Test(priority=20)
	public void ExistingEmailinvalidemailformat() {
	String Email = "@yopmail.com";
		Reusableclass r=new Reusableclass();
	    r.ExistingEmail(Email);
}
	@Test(priority=21)
	public void Createprofilewithnulldata() {
	String name = "";
	String Username="";
	String designation="";
		Reusableclass r=new Reusableclass();
	    r.Createprofile(name, Username, designation);
}	
	@Test(priority=22)
	public void Createprofilewithinvalidname() {
	String name = "12345";
	String Username="Raju";
	String designation="Tester";
		Reusableclass r=new Reusableclass();
	    r.Createprofile(name, Username, designation);
}	
	@Test(priority=23)
	public void CreateprofilewithinvalidUsername() {
	String name = "Raju";
	String Username="";
	String designation="Tester";
		Reusableclass r=new Reusableclass();
	    r.Createprofile(name, Username, designation);
}	
	@Test(priority=24)
	public void Createprofilewithnulldesignation() {
	String name = "Tanuku";
	String Username="Rajama";
	String designation="";
		Reusableclass r=new Reusableclass();
	    r.Createprofile(name, Username, designation);
}		
		
	@Test(priority=25)
	public void Createprofilewithnullusername() {
	String name = "tanuku";
	String Username="";
	String designation="Tester";
		Reusableclass r=new Reusableclass();
	    r.Createprofile(name, Username, designation);
}		
	@Test(priority=26)
	public void Createprofilewithnullname() {
	String name = "";
	String Username="raji45";
	String designation="Tester";
		Reusableclass r=new Reusableclass();
	    r.Createprofile(name, Username, designation);
}					
	@Test(priority=27)
	public void Createprofilewithvideo() {
	String name = "";
	String Username="raji45";
	String designation="";
 String image = "D:\\testNG\\Api Testing\\Image\\SampleVideo_720x480_1mb.mp4";
		Reusableclass r=new Reusableclass();
	    r.Createprofilewithimage(name, Username, designation, image);
}	
	@Test(priority=28)
	public void Createprofilewithpdf() {
	String name = "";
	String Username="raji45";
	String designation="Tester";
 String image = "D:\\testNG\\Api Testing\\Image\\sample (1).pdf";
		Reusableclass r=new Reusableclass();
	    r.Createprofilewithimage(name, Username, designation, image);
}	
	@Test(priority=29)
	public void Createprofilewithimage() {
	String name = "";
	String Username="";
	String designation="";
 String image = "D:\\testNG\\Api Testing\\Image\\test 2.jpg";
		Reusableclass r=new Reusableclass();
	    r.Createprofilewithimage(name, Username, designation, image);
}		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
