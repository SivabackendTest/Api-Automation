package Apimethods;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

public class Personal {
public String awardid;
	AuthorizationToken a=new AuthorizationToken();
	public String PersonalprofileId="66f15b83fdcc16f3f232e381";
	public String Personalprofileuserid="66d6d9569f0b6535b27c2d09";
	String name = a.mail.substring(0,4);

	String Username = a.mail.substring(4,12);
	
	@Test(priority=1)
	public void personal() throws InterruptedException {
	
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
	String CreatePersonalprofile = given().log().all().headers("Content-Type","multipart/form-data").multiPart("name",name)
	.multiPart("userName",Username).multiPart("designation","Analyst").multiPart("lat","80.60")
	.multiPart("long","16.50").multiPart("address","rajamandry")
	.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
	.when().post("api/v2/user/profile").then().log().all().assertThat().statusCode(200).extract().response().asString();
System.out.println(CreatePersonalprofile);
Reporter.log("Endpoint :api/v2/user/profile");
Reporter.log("StatusCode :200");
Reporter.log("User created personal profile sucessfully");

String Updateuserpersonalinterests = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
.body("{\r\n"
		+ "  \"majorPersonalInterest\": [\r\n"
		+ "    \"Aviation\",\r\n"
		+ "    \"Ballet\",\r\n"
		+ "\"Bars\"\r\n"
		+ "  ],\r\n"
		+ "  \r\n"
		+ "  \"majorProfessionalInterest\": [\r\n"
		+ "    \"Animation\"\r\n"
		+ "  ]\r\n"
		+ "  \r\n"
		+ "}")
	.headers("Authorization", a.AuthorizationToken)
.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
	}
		
	@Test(priority=2)
//Retrieve Personal profile details
	public void Getpersonaldetails() throws InterruptedException {
 Response getpersonaldetails = given().log().all().headers("Content-Type","application/json")
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
		.when().get("/api/v2/user/profile/");
 PersonalprofileId = getpersonaldetails.then().contentType(ContentType.JSON).extract().path("data._id");
 Personalprofileuserid = getpersonaldetails.then().contentType(ContentType.JSON).extract().path("data.userId");

 String Personalprofilemessage = getpersonaldetails.then().contentType(ContentType.JSON).extract().path("message");

		System.out.println(PersonalprofileId);
		
        System.out.println("PersonalId "+PersonalprofileId);
		Assert.assertEquals("SUCCESS",Personalprofilemessage );

        Reporter.log("Endpoint :api/v2/user/profile");
        Reporter.log("StatusCode :200");
        Reporter.log("User Personal data retrieve sucessfully"); 
        
        
	}
	@Test(priority=3)
	public void Updatepersonalprofile() {
        
 //Update basicPersonal Profile
        String basicupdatepersonalprofile = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
				.body("{\r\n"
						+ "    \"type\": \"basic\",\r\n"
						+ "    \"name\": \""+name+"\",\r\n"
						+ "    \"phone\": \""+a.Phonenumber+"\",\r\n"
						+ "    \"gender\": \""+a.Gender+"\"\r\n"
						+ "}")
				.headers("Authorization", a.AuthorizationToken)
				.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(basicupdatepersonalprofile);
				
				JsonPath jp=new JsonPath(basicupdatepersonalprofile);
				
				String UpdatebasicdetailsMessage=jp.get("message");
				String UpdatedName=jp.get("data.name");
				String UpdatedPhonenumber=jp.get("data.phone");
				String UpdatedGender=jp.get("data.gender");
				System.out.println("Updatebasicdetails message"+UpdatebasicdetailsMessage);
				Assert.assertEquals("SUCCESS",UpdatebasicdetailsMessage );
				Assert.assertEquals(name,UpdatedName );
				Assert.assertEquals(a.Phonenumber,UpdatedPhonenumber );
				Assert.assertEquals(a.Gender,UpdatedGender );

				 Reporter.log("Endpoint :api/v2/user/profile");
			        Reporter.log("StatusCode :200");
				Reporter.log("Updated personal profile details sucessfully");
	}
	//	Update skillPersonal Profile
	@Test(priority=4)
	public void skillUpdate() {
				String Skillupdatepersonalprofile = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
						.body("{\r\n"
								+ "    \"type\":\"skill\",\r\n"
								+ "    \"skill\":\""+a.Skill+"\"\r\n"
								+ "}")
						.headers("Authorization", a.AuthorizationToken)
						.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
						System.out.println(Skillupdatepersonalprofile);
						
						JsonPath jSkil=new JsonPath(Skillupdatepersonalprofile);
						
						String UpdatebasicdetailsMessage=jSkil.get("message");
						String Updatedskill=jSkil.get("data.skill[0]");
						Assert.assertEquals(a.Skill,Updatedskill );
						Assert.assertEquals("SUCCESS",UpdatebasicdetailsMessage );
						
						   Reporter.log("Endpoint :api/v2/user/profile");
					        Reporter.log("StatusCode :200");
						Reporter.log("Updated personal profile skills sucessfully");
	}
	@Test(priority=5)
	public void Updatelink() {
	//update linkpersoanl Profile
						String linkupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
								.header("email",a.mail)
								.body("{\r\n"
										+ "    \"type\":\"link\",\r\n"
										+ "    \"link\": {\r\n"
										+ "    \"x\": \"www.twitterlink.com\",\r\n"
										+ "    \"fb\": \"www.fblink.com\",\r\n"
										+ "    \"ig\": \"www.intragramlink.com\",\r\n"
										+ "    \"ln\": \"www.linkedinlink.com\"\r\n"
										+ "\r\n"
										+ "  }}")
								.headers("Authorization", a.AuthorizationToken)
								.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
								System.out.println(linkupdatepersonalprofile);
								   Reporter.log("Endpoint :api/v2/user/profile");
							        Reporter.log("StatusCode :200");
								Reporter.log("Updated personal profile links sucessfully");	
	}
	@Test(priority=6)
	public void Updateaward() {
// Update award
			String awardupdatepersonalprofile = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
										.body("{\r\n"
												+ "    \"type\": \"award\",\r\n"
												+ "    \"title\": \""+a.Awardtitle+"\",\r\n"
												+ "    \"received\": \""+a.Received+"\",\r\n"
												+ "    \"organization\": \""+a.Organization+"\"\r\n"
												+ "}")
										.headers("Authorization", a.AuthorizationToken)
										.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
										System.out.println(awardupdatepersonalprofile);
										   Reporter.log("Endpoint :api/v2/user/profile");
									        Reporter.log("StatusCode :200");
										Reporter.log("Updated personal profile awards sucessfully");				
										JsonPath award=new JsonPath(awardupdatepersonalprofile);
										String awardtitle = award.get("data.awards[0].title");
										String Organization = award.get("data.awards[0].organization");

								        String awardid = award.get("data.awards[0]._id");
										Assert.assertEquals(a.Organization,Organization );
										Assert.assertEquals(a.Awardtitle,awardtitle );

								        System.out.println("AwardId "+awardid);
	}
//Update Education	
	@Test(priority=7)
	public void UpdateEducation() {
				String Educationupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
						.header("email",a.mail)
												.body("{\r\n"
														+ "    \"type\": \"education\",\r\n"
														+ "    \"institute\": \""+a.institute+"\",\r\n"
														+ "    \"degree\": \""+a.degree+"\",\r\n"
														+ "    \"startDate\": \""+a.Startdate+"\",\r\n"
														+ "    \"endDate\": \""+a.enddate+"\"\r\n"
														+ "}")
												.headers("Authorization", a.AuthorizationToken)
												.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
												System.out.println(Educationupdatepersonalprofile);
												   Reporter.log("Endpoint :api/v2/user/profile");
											        Reporter.log("StatusCode :200");
												Reporter.log("Updated personal profile Education sucessfully");				
												JsonPath Education=new JsonPath(Educationupdatepersonalprofile);
												String UpdatedInstitute=Education.get("data.educations[0].institute");
												String UpdatedDegree=Education.get("data.educations[0].degree");
										        String Educationid = Education.get("data.educations[0]._id");
										        Assert.assertEquals(a.institute,UpdatedInstitute );
												Assert.assertEquals(a.degree,UpdatedDegree );

										        System.out.println("EducationId "+Educationid);
//update Experience										   
	}
	@Test(priority=8)
	public void AddExperience() {
										        
String Experienceupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
		                                 .header("email",a.mail)
														.body("{\r\n"
																+ "    \"type\": \"experience\",\r\n"
																+ "    \"organization\": \""+a.Organization+"\",\r\n"
																+ "    \"position\": \""+a.position+"\",\r\n"
																+ "    \"startDate\": \""+a.Startdate+"\",\r\n"
																+ "    \"endDate\": \""+a.enddate+"\"\r\n"
																+ "}")
														.headers("Authorization", a.AuthorizationToken)
														.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
														System.out.println(Experienceupdatepersonalprofile);
														   Reporter.log("Endpoint :api/v2/user/profile");
													        Reporter.log("StatusCode :200");
														Reporter.log("Updated personal profile Experience sucessfully");				
														JsonPath Experience=new JsonPath(Experienceupdatepersonalprofile);
												        String Experienceid = Experience.get("data.educations[0]._id");
												    String Expcompany =Experience.get("data.experiences[0].organization");
												       String Position= Experience.get("data.experiences[0].position");
												        System.out.println("EducationId "+Experienceid);
												        Assert.assertEquals(a.Organization,Expcompany );
														Assert.assertEquals(a.position,Position );

	}
	@Test(priority=9)
	public void UpdateInterest() {
    //Patch User Interest
           String Updateuserinterests = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
						.body("{\r\n"
								+ "  \"majorPersonalInterest\": [\r\n"
								+ "    \"Aviation\",\r\n"
								+ "    \"Ballet\",\r\n"
								+ "\"Bars\"\r\n"
								+ "  ],\r\n"
								+ "  \r\n"
								+ "  \"majorProfessionalInterest\": [\r\n"
								+ "    \"Animation\"\r\n"
								+ "  ]\r\n"
								+ "  \r\n"
								+ "}")
							.headers("Authorization", a.AuthorizationToken)
.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
																									        
//Post influencer
//           String Influencer = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
//					.body("{\r\n"
//							+ "  \"comment\": \"product make you want to share it with everyone around you. Just one bite is all it takes!\",\r\n"
//							+ "  \"link\": {\r\n"
//							+ "    \"x\": \"www.twitterlink.com\",\r\n"
//							+ "    \"fb\": \"www.fblink.com\",\r\n"
//							+ "    \"ig\": \"www.intragramlink.com\",\r\n"
//							+ "    \"ln\": \"www.linkedinlink.com\",\r\n"
//							+ "    \"custom1\": \"www.customlink.com\"\r\n"
//							+ "  }\r\n"
//							+ "}")
//						.headers("Authorization", a.AuthorizationToken)
//.when().post("api/v2/user/influencer-request").then().assertThat().statusCode(200).extract().response().asString();
// Get influencer
           given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("api/v2/user/influencer-request").then().assertThat().statusCode(200).extract().response().asString();
       
           
//Own analytics
           given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("period","30")
			.when().get("api/v2/user/own-analytics").then().log().all().assertThat().statusCode(200).extract().response().asString();
                 
}
	@Test(priority=10)
	public void Getuserforfollowreview() {
		  given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("skip","0").param("limit","5")
			.when().get("/api/v2/user/getUserForFollowReview").then().log().all().assertThat().statusCode(200).extract().response().asString();
	}
	@Test(priority=11)
	public void OwnViewmentions() {
		  given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("skip","0").param("limit","5")
			.param("postType", "social")
			.when().get("/api/v2/user/own-view-mention").then().log().all().assertThat().statusCode(200).extract().response().asString();
	}
	@Test(priority=12)
	public void Otheractivity() {
		
		String CreatePersonalprofileforother = given().log().all().headers("Content-Type","multipart/form-data").multiPart("name",name)
				.multiPart("userName",Username).multiPart("designation","Analyst").multiPart("lat","80.60")
				.multiPart("long","16.50").multiPart("address","rajamandry")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().post("api/v2/user/profile").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(CreatePersonalprofileforother);
			
			JsonPath gp4=new JsonPath(CreatePersonalprofileforother);
	        String PersonalprofIdforothers= gp4.get("data._id");
			
		  given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("id",PersonalprofIdforothers)
			.param("type", "social")
			.when().get("/api/v2/user/other-activity").then().log().all().assertThat().statusCode(200).extract().response().asString();
	} 
	@Test(priority=13)
	public void Ownviewreferral() {
		  given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("skip","0")
			.param("limit", "5").param("type", "all").param("status", "open")
			.when().get("/api/v2/user/own-view-referral").then().log().all().assertThat().statusCode(200).extract().response().asString();
	} 
	@Test(priority=14)
	public void Ownviewreaction() {
		  given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("skip","0")
			.param("limit", "5")
			.when().get("/api/v2/user/own-view-reaction").then().log().all().assertThat().statusCode(200).extract().response().asString();
	} 
}
