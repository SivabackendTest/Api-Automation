package Apimethods;

import java.util.Scanner;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.ValidatableResponse;

public class useronboarding {
	
	
//	ExtentReports extents=new ExtentReports();
//	ExtentSparkReporter spark=new ExtentSparkReporter("target/Spark.html");
//	@BeforeSuite
//	public void beforeResponse() {
//		spark.config().setTheme(Theme.DARK);
//		spark.config().setDocumentTitle("ApiReport");
//		extents.attachReporter(spark);}
//		
		//PrintStream out = new PrintStream(new FileOutputStream("UseronboardingNegative.txt"));
	    //    System.setOut(out);
	        
//	        RequestSpecification myRequest = RestAssured.given()
//	                .filter(new ResponseLoggingFilter())
//	                .filter(new RequestLoggingFilter());
		
		
		
	//}
	
	AuthorizationToken a=new AuthorizationToken();
	@Test(priority=1)
public void useronboarding() throws InterruptedException {
	//public static void main(String[] args) throws MalformedURLException, URISyntaxException {
		// TODO Auto-generated method stub
//given,when,then
		//System.setProperty("webdriver.chrome.driver", "");
	//	WebDriver driver=new ChromeDriver();
	 
		//RestAssured.baseURI="https://identitytoolkit.googleapis.com";
//		String bearer=given().log().all().queryParam("key","AIzaSyBnjKx9NOENM-sc13cwjVNsDVShDWsR5Hk")
//		.body("{\"email\":\"rajuoct5000@yopmail.com\",\"password\":\"Curd@123\",\"returnSecuteToken\":true}")
//		.when().post("https://identitytoolkit.googleapis.com/v1/accounts:signUp").asString();
//		JsonPath js= new JsonPath(bearer);
//		String Token = js.getString("bearer");
//
//		//Post-Signup
		//Reporter.log("String date = new java.text.SimpleDateFormat(\"MM/dd/yyyy HH:mm:ss\").format(new java.util.Date (epoch*1000))");
		
		
		//String name = mail.substring(0,4);
	//	System.out.println(name);
		//String Username = mail.substring(4,11);
		//System.out.println(Username);
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
		String Postsignup=given().log().all().header("Content-Type","application/json").header("email",a.mail)
	.body(Payload.postsignup(a.mail, a.LocalId)).headers("Authorization", a.AuthorizationToken)
		.when().post("api/v2/auth/post-signup").then().log().all().assertThat().statusCode(200).extract().asString();
		System.out.println(Postsignup);
		JsonPath b=new JsonPath(Postsignup);
        String Signupmessage=b.get("message");
		Assert.assertEquals("User Created.",Signupmessage );


		String path="data.email";
		String path1="data.uid";
			String signinEmail=b.getString(path);
			
			System.out.println("email"+signinEmail);
			String signinuid=b.getString(path1);
			System.out.println("Uid"+signinuid);
			Reporter.log("Endpoint: api/v2/auth/post-signup");
			Reporter.log("statusCode 201");
			Reporter.log("User signup sucessfully");

	}
		//sign-in
		//RestAssured.baseURI="http://hcpdev.curd.network:3000";
@Test(priority=2)
public void Signin() {
		String Signin = given().log().all().header("Content-Type","application/json").header("email",a.mail).headers("Authorization", a.AuthorizationToken)
		.body("{\r\n"
				+ "  \"email\": \""+a.mail+"\",\r\n"
				+ "  \"uid\": \""+a.LocalId+"\",\r\n"
				+ "  \"device\": {\r\n"
				+ "    \"token\": \"deL5_IVSR5Sskgu40DvT3l:APA91bEvwltlTHUybBeWqzOkN1c7jr24fibJDPcY_E-HMRSOThqDzeyElo--8szEQ1NEbVOciE25IO4x8fk6skvhYFicng8IE4hHmB81bp3mrNFCY2RPfwSOo3IIlnHlbkzDP451ScDt\",\r\n"
				+ "    \"os_sdk\": \"34\",\r\n"
				+ "    \"os_version\": \"14\",\r\n"
				+ "    \"isPhysicalDevice\": \"true\",\r\n"
				+ "    \"ip\": \"124.23.24.174\",\r\n"
				+ "    \"os_type\": \"Android\",\r\n"
				+ "    \"app_version\": \"1.10.3\"\r\n"
				+ "  }\r\n"
				+ "}\r\n"
				+ "").when().post("/api/v2/auth/post-signin").then().log().all().assertThat().statusCode(200).extract().asString();
		JsonPath in=new JsonPath(Signin);
        String Signupmessage=in.get("message");
		Assert.assertEquals("SUCCESS",Signupmessage );

		
		Reporter.log("Endpoint: api/v2/auth/post-signin");
		Reporter.log("statusCode 200");
		Reporter.log("User signin sucessfully");
	}
	@Test(priority=3)
	public void Sendotp() {
		//SendOtp
		String sendotpresponse = given().log().all().header("Content-Type","application/json").header("Authorization", a.AuthorizationToken)
		.header("email",a.mail).body("{\r\n"
				+ "    \"email\":\""+a.mail+"\",\r\n"
				+ "    \"type\": \"CRAPWD\"\r\n"
				+ "}")
		.when().post("api/v2/auth/verify-email").then().assertThat().
		
		statusCode(200).extract().response().asString();
		System.out.println(sendotpresponse);
	JsonPath js=new JsonPath(sendotpresponse);
	String Sendotpmessage = js.get("message");
	Assert.assertEquals("SUCCESS",Sendotpmessage );

	String path2="data.code";
		String postcode=js.getString(path2);
		System.out.println("code"+postcode);
		Reporter.log("Endpoint: api/v2/auth/verify-email");
		Reporter.log("statusCode 200");
		
			Reporter.log("An OTP has been sent to your device, valid for the next 5 minutes");
	}
	@Test(priority=4)
	public void verifyotp() {
		//verifyotp
		
		String sendotpresponse = given().header("Content-Type","application/json").header("Authorization", a.AuthorizationToken)
				.header("email",a.mail).body("{\r\n"
						+ "    \"email\":\""+a.mail+"\",\r\n"
						+ "    \"type\": \"CRAPWD\"\r\n"
						+ "}")
				.when().post("api/v2/auth/verify-email").then().assertThat().
				
				statusCode(200).extract().response().asString();
		JsonPath Vs=new JsonPath(sendotpresponse);
		String path21="data.code";
			String postcodeverify=Vs.getString(path21);
		
			String otp="112233";
		String Confirmotp = given().log().all().header("Content-Type","application/json").header("Authorization", a.AuthorizationToken)
		.headers("email",a.mail).body("{\r\n"
				+ "    \"email\": \""+a.mail+"\",\r\n"
				+ "    \"otp\": \""+otp+"\",\r\n"
				+ "    \"code\": \""+postcodeverify+"\"\r\n"
				+ "}")
		.when().post("api/v2/auth/confirm-email").then().log().all().assertThat().statusCode(200).extract().response().asString();
		
		JsonPath in=new JsonPath(Confirmotp);
        String confirmmessage=in.get("message");
		Assert.assertEquals("SUCCESS",confirmmessage );

		
		Reporter.log("Endpoint: api/v2/auth/confirmemail");
		Reporter.log("statusCode 200");
		
		Reporter.log("Verification Successful");
	}
	@Test(priority=5)
	public void Emailexist() {
	
		//Email-Exist
		String EmailExistCheck = given().log().all().header("Content-Type","application/json").header("email",a.mail).headers("Authorization", a.AuthorizationToken)
		.body("{\r\n"
				+ "    \"email\":\""+a.mail+"\"\r\n"
				+ "}")
			.when().post("/api/v2/auth/email-exist").then().log().all().assertThat().statusCode(200).extract().response().asString();
		
		JsonPath ex=new JsonPath(EmailExistCheck);
        String Emailcheckmessage=ex.get("message");
        String Respmessage = ex.get("data.message");
        
		Assert.assertEquals("SUCCESS",Emailcheckmessage );

		
		Reporter.log("Endpoint: api/v2/auth/email-exist ");
		Reporter.log("statusCode 200");
		
		Reporter.log(Respmessage);
	}
		@Test(priority=6)
		public void Resetpassword() {
		
		//Reset password
		String Resetpassword=given().log().all().header("Content-Type","application/json").header("email",a.mail).headers("Authorization", a.AuthorizationToken)
		.body("{\r\n"
				+ "  \"email\": \""+a.mail+"\",\r\n"
				+ "  \"password\": \"Anasur@123\"\r\n"
				+ "}")
			.when().post("api/v2/auth/reset-password").then().log().all().assertThat().statusCode(200).extract().response().asString();
		
		JsonPath RS=new JsonPath(Resetpassword);
        String Changepasswordmessage=RS.get("message");
        String Resetpasswordmessage = RS.get("data.message");
        
		Assert.assertEquals("SUCCESS",Changepasswordmessage );
		Reporter.log("Endpoint: api/v2/auth/reset-password");
		Reporter.log("statusCode 200");
		
		Reporter.log(Resetpasswordmessage);
		}
		@Test(priority=5)
		public void GetUser() {
		
		
			given().log().all().header("Content-Type","application/json").header("email",a.mail).headers("Authorization", a.AuthorizationToken)
				.when().get("/api/v2/auth/user").then().log().all().assertThat().statusCode(200);
			Reporter.log("Endpoint: /api/v2/auth/user ");
			Reporter.log("statusCode 200");
			
			Reporter.log("User Details Retrieve Sucessfully");
		}
		@Test(priority=9)
		public void DeleteAccount() {
		String deleteAccount = given().log().all().headers("Content-Type","application/json").param("email", a.mail)
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().delete("/api/v2/auth/delete-user").then().log().all().assertThat().statusCode(200).extract().response().asString();
				System.out.println(deleteAccount);
				Reporter.log("/api/v2/auth/delete-user");
				Reporter.log("statusCode 200");
				Reporter.log("User Account deleted  Sucessfully");	
		}
		@Test(priority=7)
		public void LoggedIn(){
		
		
			given().log().all().header("Content-Type","application/json").header("email",a.mail).headers("Authorization", a.AuthorizationToken)
				.when().get("/api/v2/auth/loggedIn").then().log().all().assertThat().statusCode(200);
			Reporter.log("Endpoint: /api/v2/auth/loggedIn ");
			Reporter.log("statusCode 200");
			
			Reporter.log("Retrieve LoggedIn  details Successfully");
		
		}
	/*	@Test(priority=8)
		public void Logout(){
		
		
			given().log().all().header("Content-Type","application/json").header("email",a.mail).headers("Authorization", a.AuthorizationToken)
			.body("{\r\n"
					+ "  \"device\": {\r\n"
					+ "    \"token\": \"ecoTOhI1QcSTkzZZ2CXS0o:APA91bHwazKGXME3bJOpxeoKGRWYXro7d_2kpX9I0lEOCF9WBj9Iwyu7ktXBV3sdC9ppoLny_XxDHyLB9FT7QWZMju4o9h1jOYy2AC6vB8jvnZxJ_QOkMgw1HYcHwWXaMQ27aWNt8IOz\"\r\n"
					+ "  }\r\n"
					+ "}")
			.when().post("/api/v2/auth/logout").then().log().all().assertThat().statusCode(200);
			Reporter.log("Endpoint: /api/v2/auth/logout ");
			Reporter.log("statusCode 200");
			
			Reporter.log("Retrieve LoggedIn  details Successfully");
		
		}*/
			
}
	//Logout
/*	given().log().all().header("Content-Type","application/json").header("email",a.mail)
	.header("Authorization", a.AuthorizationToken)
	.body("{\r\n"
			+ "     \"device\": {\r\n"
			+ "            \"token\": \"deL5_IVSR5Sskgu40DvT3:APA91bEvwltlTHUybBeWqzOkN1DPcY_E-HMRSOThqDzeyElo--8szEQ1NEbVOciE25IO4x8fk6skvhYFicng8IE4hHmB81bp3mrNFCY2RPfwSOo3IIlnHlbkzDP451ScDt\"\r\n"
			+ " }}")
		.when().post("api/v2/auth/logout").then().log().all().assertThat().statusCode(200);*/
	//Delete
	/*given().log().all().header("Content-Type","application/json").header("email",mail).param("email",a.mail)
	.header("Authorization", a.AuthorizationToken)
	
		.when().delete("api/v2/auth/delete-user").then().log().all().assertThat().statusCode(200);*/
	
/*	@Test(priority=2)
		public void personal() throws InterruptedException {
			//Create personal Profile
	String name = mail.substring(0,4);
			System.out.println(name);
			String Username = mail.substring(4,12);
			System.out.println(Username);
			RestAssured.baseURI="http://hcpdev.curd.network:3000";
		String CreatePersonalprofile = given().log().all().headers("Content-Type","multipart/form-data").multiPart("name",name)
		.multiPart("userName",Username).multiPart("designation","Analyst")
		.headers("Authorization", a.AuthorizationToken).header("email",mail)
		.when().post("api/v2/user/profile").then().log().all().assertThat().statusCode(200).extract().response().asString();
	System.out.println(CreatePersonalprofile);
	Reporter.log("User created personal profile sucessfully");
	
	//Retrieve Personal profile details
	String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",mail)
			.when().get("/api/v2/user/profile/").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getpersonaldetails);
			JsonPath gp2=new JsonPath(getpersonaldetails);
	        String PersonalprofId = gp2.get("data._id");
	        System.out.println("PersonalUserId "+PersonalprofId);
	        
	        Thread.sleep(5000);
	        
	 //Update basicPersonal Profile
	        String basicupdatepersonalprofile = given().log().all().headers("Content-Type","application/json").header("email",mail)
					.body("{\r\n"
							+ "    \"type\": \"basic\",\r\n"
							+ "    \"name\": \""+name+"\",\r\n"
							+ "    \"phone\": \"7896479514\",\r\n"
							+ "    \"gender\": \"female\"\r\n"
							+ "}")
					.headers("Authorization", a.AuthorizationToken)
					.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(basicupdatepersonalprofile);
					Reporter.log("Updated basic personal profile sucessfully");
		//	Update skillPersonal Profile
					String Skillupdatepersonalprofile = given().log().all().headers("Content-Type","application/json").header("email",mail)
							.body("{\r\n"
									+ "    \"type\":\"skill\",\r\n"
									+ "    \"skill\":\"manual\"\r\n"
									+ "}")
							.headers("Authorization", a.AuthorizationToken)
							.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
							System.out.println(Skillupdatepersonalprofile);
							Reporter.log("Updated personal profile skills sucessfully");
		//update linkpersoanl Profile
							String linkupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
									.header("email",mail)
									.body("{\r\n"
											+ "    \"type\":\"link\",\r\n"
											+ "    \"link\":\"www.js.com\"\r\n"
											+ "}")
									.headers("Authorization", a.AuthorizationToken)
									.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
									System.out.println(linkupdatepersonalprofile);
									Reporter.log("Updated personal profile links sucessfully");				
 // Update award
				String awardupdatepersonalprofile = given().log().all().headers("Content-Type","application/json").header("email",mail)
											.body("{\r\n"
													+ "    \"type\": \"award\",\r\n"
													+ "    \"title\": \"IEEE\",\r\n"
													+ "    \"received\": \"10-10-2022\",\r\n"
													+ "    \"organization\": \"Indian\"\r\n"
													+ "}")
											.headers("Authorization", a.AuthorizationToken)
											.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
											System.out.println(awardupdatepersonalprofile);
											Reporter.log("Updated personal profile awards sucessfully");				
											JsonPath award=new JsonPath(awardupdatepersonalprofile);
									        String awardid = gp2.get("data.awards[0]._id");
									        System.out.println("AwardId "+awardid);
	//Update Education								       
					String Educationupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
							.header("email",mail)
													.body("{\r\n"
															+ "    \"type\": \"education\",\r\n"
															+ "    \"institute\": \"gbp school\",\r\n"
															+ "    \"degree\": \"Mba\",\r\n"
															+ "    \"startDate\": \"05-06-2021\",\r\n"
															+ "    \"endDate\": \"07-06-2023\"\r\n"
															+ "}")
													.headers("Authorization", a.AuthorizationToken)
													.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
													System.out.println(Educationupdatepersonalprofile);
													Reporter.log("Updated personal profile Education sucessfully");				
													JsonPath Education=new JsonPath(Educationupdatepersonalprofile);
											        String Educationid = Education.get("data.educations[0]._id");
											        System.out.println("EducationId "+Educationid);	
	//update Experience										   
											      
											        
	String Experienceupdatepersonalprofile = given().log().all().headers("Content-Type","application/json")
			                                 .header("email",mail)
															.body("{\r\n"
																	+ "    \"type\": \"experience\",\r\n"
																	+ "    \"organization\": \"TCS\",\r\n"
																	+ "    \"position\": \"Analyst\",\r\n"
																	+ "    \"startDate\": \"05-05-2019\",\r\n"
																	+ "    \"endDate\": \"06-09-2023\"\r\n"
																	+ "}")
															.headers("Authorization", a.AuthorizationToken)
															.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
															System.out.println(Experienceupdatepersonalprofile);
															Reporter.log("Updated personal profile Experience sucessfully");				
															JsonPath Experience=new JsonPath(Educationupdatepersonalprofile);
													        String Experienceid = Experience.get("data.educations[0]._id");
													        System.out.println("EducationId "+Experienceid);
	    //Patch User Interest
	           String Updateuserinterests = given().log().all().headers("Content-Type","application/json").header("email",mail)
							.body("{\r\n"
									+ "  \"majorPersonalInterest\": [\r\n"
									+ "    \"Music\",\r\n"
									+ "    \"Movies\"\r\n"
									+ "  ],\r\n"
									+ "  \"subPersonalInterest\": [\r\n"
									+ "    \"Horror movies\",\r\n"
									+ "    \"Jazz music\"\r\n"
									+ "  ],\r\n"
									+ "  \"majorProfessionalInterest\": [\r\n"
									+ "    \"Health care\"\r\n"
									+ "    \r\n"
									+ "  ],\r\n"
									+ "  \"subProfessionalInterest\": [\r\n"
									+ "    \"Dental\"\r\n"
									+ "    \r\n"
									+ "  ]\r\n"
									+ "}")
								.headers("Authorization", a.AuthorizationToken)
	.when().patch("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
																										        
	//Post influencer
	           String Influencer = given().log().all().headers("Content-Type","application/json").header("email",mail)
						.body("{\r\n"
								+ "  \"comment\": \"product make you want to share it with everyone around you. Just one bite is all it takes!\",\r\n"
								+ "  \"link\": {\r\n"
								+ "    \"x\": \"www.twitterlink.com\",\r\n"
								+ "    \"fb\": \"www.fblink.com\",\r\n"
								+ "    \"ig\": \"www.intragramlink.com\",\r\n"
								+ "    \"ln\": \"www.linkedinlink.com\",\r\n"
								+ "    \"custom1\": \"www.customlink.com\"\r\n"
								+ "  }\r\n"
								+ "}")
							.headers("Authorization", a.AuthorizationToken)
.when().post("api/v2/user/influencer-request").then().assertThat().statusCode(200).extract().response().asString();
	// Get influencer
	           given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",mail)
				.when().get("api/v2/user/influencer-request").then().assertThat().statusCode(200).extract().response().asString();
           
	           
	//Own analytics
	           given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",mail).param("period","30")
				.when().get("api/v2/user/own-analytics").then().log().all().assertThat().statusCode(200).extract().response().asString();
                     
	}
	@Test(priority=3)
	
		public void General() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
//			  String PostInterest=given().log().all().headers("Content-Type","application/json").header("email",mail).param("name", "jarigame")
//							.headers("Authorization", a.AuthorizationToken)
//.when().post("api/v2/req-interest").then().assertThat().statusCode(200).extract().response().asString();
//			  System.out.println(PostInterest);
//		
		//Get personal interests
		given().log().all().headers("Content-Type","application/json").header("email",mail)
		.headers("Authorization", a.AuthorizationToken)
.when().get("api/v2/personal-interests").then().log().all().assertThat().statusCode(200).extract().response().asString();	
	//get professional interest
		
		given().log().all().headers("Content-Type","application/json").header("email",mail)
		.headers("Authorization", a.AuthorizationToken)
.when().get("api/v2/professional-interests").then().log().all().assertThat().statusCode(200).extract().response().asString();	
		
}
		
		
		
			@Test(priority=4)
		public void Createbusinessprofile(){
			//String AuthorizationToken = "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IjlhNTE5MDc0NmU5M2JhZTI0OWIyYWE3YzJhYTRlMzA2M2UzNDFlYzciLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vY3VyZC1uZXR3b3JrLS0tZGV2IiwiYXVkIjoiY3VyZC1uZXR3b3JrLS0tZGV2IiwiYXV0aF90aW1lIjoxNjk2NzY5MDU3LCJ1c2VyX2lkIjoiWnVZa0c2M052b2VzSzlGdjlGTEROV0VkUDlXMiIsInN1YiI6Ilp1WWtHNjNOdm9lc0s5RnY5RkxETldFZFA5VzIiLCJpYXQiOjE2OTY3NjkwNTcsImV4cCI6MTY5Njc3MjY1NywiZW1haWwiOiJzaXZhb2N0ODJAeW9wbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsImZpcmViYXNlIjp7ImlkZW50aXRpZXMiOnsiZW1haWwiOlsic2l2YW9jdDgyQHlvcG1haWwuY29tIl19LCJzaWduX2luX3Byb3ZpZGVyIjoicGFzc3dvcmQifX0.0UVayjE4NBRvgNr8EgtyVrfJnEfGw8UirlvAuglkg-eHcuVitboM-tVyATkBM79WGo3qjU8zdEA2SGtMkLmFrPDykyWYoyn3Oua0GQQKEhBv9_uNgWRuUITa8xKjxp0Dobzv5PiLvG3KR6DgZxxbKOTM0ASreW101MS06XsJe4aeWGyNYP3N-glDFM0vHANlgKFFNZwMCHz9kUNTmTplOL9xdYkL98y1mTUbZrQNnTPw83j9Cr_ycDaycICd_cVFKGVKjxCeD8Is1Ru8WCYw330pGiMS9-eFpJGB-BpwgGvwpS4Nx92VG_APyJw5GuyduYVSo5U0VCldSbgoQ05b-A";
					//Scanner s=new Scanner(System.in);
			//String AuthorizationToken = s.next();
			//System.out.println(AuthorizationToken);
			RestAssured.baseURI="http://hcpdev.curd.network:3000";
			// TODO Auto-generated method stub
			String Createbusiness = given().log().all().headers("Content-Type","multipart/form-data").header("email",mail).multiPart("businessName","fashiontech")
			.multiPart("tagline","space ao").multiPart("description","electronics").multiPart("industry","semi")
			.headers("Authorization", a.AuthorizationToken)
			.when().post("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(Createbusiness);
			JsonPath js1=new JsonPath(Createbusiness);

				String businessid=js1.get("data[0]._id");
				System.out.println("businessid"+businessid);
				Reporter.log("Business profile created");
				

			String getbusiness = given().log().all().headers("Content-Type","application/json").param("id", businessid)
					.headers("Authorization", a.AuthorizationToken).header("email",mail)
					.when().get("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(getbusiness);
					
						Reporter.log("Retrieve business profile sucessful");

					//update businessprofile
					String updatebusiness = given().log().all().headers("Content-Type","application/json").header("email",mail).param("id", businessid)
							.body("{\r\n"
									+ "    \"type\": \"basic\",\r\n"
									+ "    \"businessName\": \"Softwareorg\",\r\n"
									+ "    \"tagline\": \" Helpdesk Tag\",\r\n"
									+ "    \"address\": \"bangalore\",\r\n"
									+ "    \"lat\": \"12.6\",\r\n"
									+ "    \"long\": \"12.1\",\r\n"
									+ "    \"website\": \"www.tech.com\"\r\n"
									+ "}")
							.headers("Authorization", a.AuthorizationToken)
							.when().patch("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
							System.out.println(updatebusiness);
							Reporter.log("Updated business profile sucessfully");
//							Scanner e=new Scanner(System.in);
//							String busid1 = e.next();
//							System.out.println("id:"+busid1);
					//Delete businessprofile
							String deletebusiness = given().log().all().headers("Content-Type","application/json").param("id", businessid)
									.headers("Authorization", a.AuthorizationToken).header("email",mail)
									.when().delete("api/v2/businessProfile").then().log().all().assertThat().statusCode(200).extract().response().asString();
									System.out.println(deletebusiness);
									Reporter.log("Sucessfully deleted business account");
		}
		
		//follow
		@Test(priority=5)
		public void Follow(){
			String followId = "654a0845b81bb724efa0ba24";
		  String Createfollow=given().log().all().headers("Content-Type","application/json").
				  header("email",mail)
				.headers("Authorization", a.AuthorizationToken).body("{\r\n"
						+ "  \"following\": \"65cc8b3b7bf14281d483d9f1\",\r\n"
						+ "  \"ref_model\": \"personal_profile\"\r\n"
						+ "}")
				.when().post("api/v2/network/follow").then().log().all().assertThat().statusCode(200).extract().response().asString();
				System.out.println(Createfollow);
			JsonPath Fs1=new JsonPath(Createfollow);

				String followmessage=Fs1.get("data.message");
					System.out.println("folliwermessage"+followmessage);
					Reporter.log("User followed sucessfully");
					
					
					String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
							.headers("Authorization", a.AuthorizationToken).header("email",mail)
							.when().get("/api/v2/user/profile/").then().assertThat().statusCode(200).extract().response().asString();
							System.out.println(getpersonaldetails);
							JsonPath fp2=new JsonPath(getpersonaldetails);
					        String PersonalprofIdfollow = fp2.get("data._id");
					        System.out.println("PersonalUserId "+PersonalprofIdfollow);
					
					
					 String Createfollow1=given().log().all().headers("Content-Type","application/json").
							  header("email",buyermail)
							.headers("Authorization", a.buyertoken).body("{\r\n"
									+ "  \"following\": \""+PersonalprofIdfollow+"\",\r\n"
									+ "  \"ref_model\": \"personal_profile\"\r\n"
									+ "}")
							.when().post("api/v2/network/follow").then().log().all().assertThat().statusCode(200).extract().response().asString();
							System.out.println(Createfollow1);
			
					

					String followingofUser = given().log().all().headers("Content-Type","application/json")
							.headers("Authorization", a.AuthorizationToken).header("email",mail)
							.when().get("api/v2/network/followings").then().log().all().assertThat().statusCode(200).extract().response().asString();
							System.out.println(followingofUser);
							JsonPath Fs2=new JsonPath(followingofUser);
							 String followerUser = "data.message";
								String following=Fs2.getString(followerUser);
								System.out.println("meassage"+following);
								Reporter.log("following retrieve sucessfully");
								
								
					String followersofUser = given().log().all().headers("Content-Type","application/json")
									.headers("Authorization", a.AuthorizationToken).header("email",mail)
										.when().get("api/v2/network/followers").then().log().all().assertThat().statusCode(200).extract().response().asString();
										System.out.println(followersofUser);
										JsonPath Fs3=new JsonPath(followersofUser);
										 String followers= "data.message";
											String Userfollowers=Fs3.getString(followers);
											System.out.println("meassage"+Userfollowers);
											Reporter.log("following retrieve sucessfully");	
											
							String Managenetwork = given().log().all().headers("Content-Type","application/json")
													.headers("Authorization", a.AuthorizationToken).header("email",mail)
													.when().get("api/v2/network/manage-network").then().log().all().assertThat().statusCode(200).extract().response().asString();
													System.out.println(Managenetwork);
													JsonPath Fs4=new JsonPath(Managenetwork);
													 String UserManagenetwork= "data.message";
														String UserallManagenetwork=Fs4.getString(UserManagenetwork);
														System.out.println("meassage"+UserallManagenetwork);
														Reporter.log("User Getting all data");						
											
				    String unfollow = given().log().all().headers("Content-Type","application/json")
																.headers("Authorization", a.AuthorizationToken).header("email",mail).body("{\r\n"
																		+ "  \"following\": \"65cc8b3b7bf14281d483d9f1\",\r\n"
																		+ "  \"ref_model\": \"personal_profile\"\r\n"
																		+ "}")
																.when().delete("/api/v2/network/follow").then().log().all().assertThat().statusCode(200).extract().response().asString();
																System.out.println(unfollow);
																Reporter.log("Sucessfully unfollow");
									
		}
		@Test(priority=6)
		public void Post() {
		String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
		.headers("Authorization", a.AuthorizationToken).header("email",mail)
		.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(getpersonaldetails);
		JsonPath cp=new JsonPath(getpersonaldetails);
        String PersonalprofIdforpost = cp.get("data._id");
        System.out.println("PersonalUserId "+PersonalprofIdforpost);

		 String CreatePost=given().log().all().headers("Content-Type","multipart/form-data").header("email",mail)
					.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","everyone")
					.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
					.multiPart("createdBy.ref_id",PersonalprofIdforpost).multiPart("createdBy.ref_model","personal_profile").multiPart("isRepost","false")
					.when().post("api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(CreatePost);
				JsonPath Fs1=new JsonPath(CreatePost);

					String Postmessage=Fs1.get("message");
					String PostId=Fs1.get("data._id");
					System.out.println("PostId "+PostId);
						System.out.println("Postmessage"+Postmessage);
						Reporter.log("User Create post sucessfully");
						
						//getpost
						
						String getPost = given().log().all().headers("Content-Type","application/json")
								.headers("Authorization", a.AuthorizationToken)
								.header("email",mail).body("{\r\n"
										+ "  \"id\": \""+PostId+"\",\r\n"
										+ "  \"postType\": \"social\"\r\n"
										+ "}")
								.when().post("api/v2/post/getPost").then().log().all().assertThat().statusCode(200).extract().response().asString();
								System.out.println(getPost);
								
								JsonPath pgs=new JsonPath(getPost);
								String Getmessage=pgs.get("message");
								
									System.out.println("Postmessage"+Getmessage);
									Reporter.log("User retrieve data sucessfully");
								
								
					//Update Post
								 String UpdatePost=given().log().all().headers("Content-Type","application/json").param("id",PostId)
											.headers("Authorization", a.AuthorizationToken).header("email",mail).body("{ \r\n"
													+ " \"postType\" : \"social\",\r\n"
													+ " \"visibleTo\" : \"everyone\",\r\n"
													+ " \"caption\":\"dell\" \r\n"
													+ "}")
											.when().patch("api/v2/post/update").then().log().all().assertThat().statusCode(200).extract().response().asString();
											System.out.println(UpdatePost);
										JsonPath up=new JsonPath(UpdatePost);

											String updatemessage=up.get("message");
											
												System.out.println("Postmessage"+updatemessage);
												Reporter.log("User update sucessfully");
												
				//Removepost
		/*String removePost = given().log().all().headers("Content-Type","application/json")
														.headers("Authorization", a.AuthorizationToken)
														.header("email",mail).param("id", PostId)
														.when().post("api/v2/post/remove").then().log().all().assertThat().statusCode(200).extract().response().asString();
														System.out.println(removePost);*/
																			
												
												
					//Delete Post
												
/*			String deletePost = given().log().all().headers("Content-Type","application/json").param("id", PostId)
											.headers("Authorization", a.AuthorizationToken).header("email",mail)
											.when().delete("api/v2/post/delete").then().log().all().assertThat().statusCode(200).extract().response().asString();
											System.out.println(deletePost);
											Reporter.log("Sucessfully Post deleted");											
				    				
	}
		
	//Comment
      @Test(priority=7)
	    public void Comment() {
	    	
	    	String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
	    			.headers("Authorization", a.AuthorizationToken).header("email",mail)
	    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
	    			System.out.println(getpersonaldetails);
	    			JsonPath comt=new JsonPath(getpersonaldetails);
	    	        String PersonalprofIdforComment = comt.get("data._id");
	    	        System.out.println("PersonalUserId "+PersonalprofIdforComment);
	    	        
	    	        String PostforComment=given().log().all().headers("Content-Type","multipart/form-data").header("email",mail)
	    					.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","everyone")
	    					.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
	    					.multiPart("createdBy.ref_id",PersonalprofIdforComment).multiPart("createdBy.ref_model","personal_profile").multiPart("isRepost","false")
	    					.when().post("api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();		System.out.println(PostforComment);
	    	    		JsonPath Rs1=new JsonPath(PostforComment);

	    	    			String postcommentmessage=Rs1.get("message");
	    	    			String postIdcomment=Rs1.get("data._id");
	    	    			System.out.println("postIdComment "+postIdcomment);
	    	    				System.out.println("postCommentmessage"+postcommentmessage);       
	    	        
	    	        
	    	        
	    	
	    	        
	   // PostComment
	    	  
	    	        String PostComment=given().log().all().headers("Content-Type","application/json")
	    	    			.headers("Authorization", a.AuthorizationToken).header("email",mail).body("{\r\n"
	    	    					+ "  \"createdBy\": {\r\n"
	    	    					+ "    \"ref_id\": \""+PersonalprofIdforComment+"\",\r\n"
	    	    					+ "    \"ref_model\": \"personal_profile\"\r\n"
	    	    					+ "  },\r\n"
	    	    					+ "  \"text\": \"good\",\r\n"
	    	    					+ "  \"feedId\": \""+postIdcomment+"\",\r\n"
	    	    					+ "  \"feedType\": \"post\"\r\n"
	    	    					+ "}")	    	    			
	    	    			.when().post("api/v2/comment").then().log().all().assertThat().statusCode(200).extract().response().asString();
	    	    			System.out.println(PostComment);
	    	    		JsonPath Comm=new JsonPath(PostComment);

	    	    			String Commentmessage=Comm.get("message");
	    	    			String CommentId=Comm.get("data._id");
	    	    			System.out.println("postId "+CommentId);
	    	    				System.out.println("Comment message"+Commentmessage);
	    	    				Reporter.log("User Create Comment sucessfully"); 
	    	    				
	    	 // Get Comment 
	    	  
	    	   	String getComment = given().log().all().headers("Content-Type","application/json")
	    	    			.headers("Authorization", a.AuthorizationToken).header("email",mail).body("{\r\n"
	    	    					+ "  \"id\": \""+CommentId+"\"\r\n"
	    	    					+ "}").
	    	    			when().post("/api/v2/comment/getComment").then().log().all().assertThat().statusCode(200).extract().response().asString();
	    	    			System.out.println(getComment);
	    	    						
	    	    			JsonPath Getcomm=new JsonPath(getComment);
	    	    			String GetRefferalmessage=Getcomm.get("message");
	    	    						
	    	    				System.out.println("commentgetmessage"+GetRefferalmessage);
	    	    				Reporter.log("User retrieve Comment data sucessfully");
	    	    				
	    	// Commentcount
	         
	    	    	String getCommentcountuser = given().log().all().headers("Content-Type","application/json")
	    		    	   	.headers("Authorization", a.AuthorizationToken).header("email",mail).body("{\r\n"
	    		    	   			+ "  \"feedId\": \""+postIdcomment+"\"\r\n"
	    		    	   			+ "}").
	    		    	    			when().post("api/v2/comment/count").then().log().all().assertThat().statusCode(200).extract().response().asString();
	    		    	    			System.out.println(getCommentcountuser);
	    		    	    						
	    		    	    			JsonPath Getcommcount=new JsonPath(getComment);
	    		    	    			String Getcountmessage=Getcommcount.get("message");
	    		    	    						
	    		    	    				System.out.println("Getcountmessage "+Getcountmessage);
	    		    	    				Reporter.log("User comment count retrieve sucessfully"); 
	    		    	    				
	       //Delete Comment
	    		
	    		  	String deleteComment = given().log().all().headers("Content-Type","application/json").param("id", CommentId)
	    								.headers("Authorization", a.AuthorizationToken).header("email",mail)
	    								.when().delete("api/v2/comment").then().log().all().assertThat().statusCode(200).extract().response().asString();
	    											System.out.println(deleteComment);
	    											Reporter.log("Sucessfully Comment deleted");	    	    				
	    }
	    
	    
	    @Test(priority=8)
	    public void Like() throws InterruptedException {
	    	
	    	String getpersonaldetailsForlike = given().log().all().headers("Content-Type","application/json")
	    			.headers("Authorization", a.AuthorizationToken).header("email",mail)
	    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
	    			System.out.println(getpersonaldetailsForlike);
	    			JsonPath Crl=new JsonPath(getpersonaldetailsForlike);
	    	        String PersonalprofIdforLike = Crl.get("data._id");
	    	        System.out.println("PersonalUserIdLike "+PersonalprofIdforLike);
	    	        
	    	        
	    	        
	     String CreatePostlike=given().log().all().headers("Content-Type","multipart/form-data").header("email",mail)
					.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","everyone")
					.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
					.multiPart("createdBy.ref_id",PersonalprofIdforLike).multiPart("createdBy.ref_model","personal_profile").multiPart("isRepost","false")
					.when().post("api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();		
	   
	    	System.out.println(CreatePostlike);
	    				JsonPath LS1=new JsonPath(CreatePostlike);

	    					String Postmessageforlike=LS1.get("message");
	    					String PostIdforlike=LS1.get("data._id");
	    					System.out.println("PostIdforlike "+PostIdforlike);
	    						System.out.println("Postmessage"+Postmessageforlike);
	    						Reporter.log("User Create post sucessfully");
	    						   Thread.sleep(3000);   
	    	        
	    	       
	    	//Post Like				
	    	
	    	String Postlike=given().log().all().headers("Content-Type","application/json")
	    			.headers("Authorization", a.AuthorizationToken).header("email",mail).body("{\r\n"
	    					+ "  \"createdBy\": {\r\n"
	    					+ "    \"ref_id\": \""+PersonalprofIdforLike+"\",\r\n"
	    					+ "    \"ref_model\": \"personal_profile\"\r\n"
	    					+ "  },\r\n"
	    					+ "  \"type\": \"post\",\r\n"
	    					+ "  \"postType\": \"professional\",\r\n"
	    					+ "  \"feedId\": \""+PostIdforlike+"\",\r\n"
	    					+ "  \"parentId\": \""+PostIdforlike+"\"\r\n"
	    					+ "}")	    	    			
	    			.when().post("api/v2/like").then().log().all().assertThat().statusCode(200).extract().response().asString();
	    			System.out.println(Postlike);
	    		JsonPath li=new JsonPath(Postlike);

	    			String Likemessage=li.get("message");
	    			String LikeId=li.get("data._id");
	    			System.out.println("LikeId "+LikeId);
	    				System.out.println("Like message"+Likemessage);
	    				Reporter.log("User like sucessfully"); 
	    				
	    	//Like Count
	    				String getlikecountuser= given().log().all().headers("Content-Type","application/json")
		    		    	   	.headers("Authorization", a.AuthorizationToken).header("email",mail).body("{\r\n"
		    		    	   			+ "  \"type\": \"post\",\r\n"
		    		    	   			+ "  \"parentId\": \""+PostIdforlike+"\"\r\n"
		    		    	   			+ "}").
		    		    	    			when().post("api/v2/like/count").then().log().all().assertThat().statusCode(200).extract().response().asString();
		    		    	    			System.out.println(getlikecountuser);
		    		    	    						
		    		    	    			JsonPath Getlikecount=new JsonPath(getlikecountuser);
		    		    	    			String Getcountmessage=Getlikecount.get("message");
		    		    	    						
		    		    	    				System.out.println("Getlikecountmessage "+Getcountmessage);
		    		    	    				Reporter.log("User like count retrieve sucessfully"); 
		    		    			
	    				
	    	//Delete Like
	    		String deleteLike = given().log().all().headers("Content-Type","application/json").param("id", LikeId)
								.headers("Authorization", a.AuthorizationToken).header("email",mail)
								.when().delete("api/v2/like").then().log().all().assertThat().statusCode(200).extract().response().asString();
											System.out.println(deleteLike);
											Reporter.log("Sucessfully Like deleted");	    	    						
	    				
	    				
	    	 }
	    @Test(priority=9)
	    public void Conections() {
	    	
	    	String getpersonaldetailsForConnections = given().log().all().headers("Content-Type","application/json")
	    			.headers("Authorization", a.AuthorizationToken).header("email",mail)
	    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
	    			System.out.println(getpersonaldetailsForConnections);
	    			JsonPath Cr=new JsonPath(getpersonaldetailsForConnections);
	    	        String PersonalprofIdforconnections = Cr.get("data._id");
	    	        System.out.println("personid "+PersonalprofIdforconnections);
	    	
	    	        String getpersonaldetailsForfriendConnection = given().log().all().headers("Content-Type","application/json")
	    	    			.headers("Authorization", a.buyertoken).header("email",buyermail)
	    	    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
	    	    			System.out.println(getpersonaldetailsForConnections);
	    	    			JsonPath Connect=new JsonPath(getpersonaldetailsForfriendConnection);
	    	    	        String Friend1 = Connect.get("data._id");
	    	    	        System.out.println("friend1"+Friend1);
	    	    	        String getpersonalForfriendConnection2 = given().log().all().headers("Content-Type","application/json")
	    	    	    			.headers("Authorization", a.SellerToken).header("email",sellermail)
	    	    	    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
	    	    	    			System.out.println(getpersonaldetailsForConnections);
	    	    	    			JsonPath Connect1=new JsonPath(getpersonaldetailsForfriendConnection);
	    	    	    	        String Friend2 = Connect.get("data._id");
	    	    	    	        System.out.println("friend1"+Friend2);
	    	    	    	
	    //Connections
	    //Connection Request
	    	
	    String ConnectionRequest=given().log().all().headers("Content-Type","application/json").param("id",Friend1 )
				.headers("Authorization", a.AuthorizationToken).header("email",mail)
				.when().get("api/v2/network/connection/request").then().log().all().assertThat().statusCode(200).extract().response().asString();
				System.out.println(ConnectionRequest);
			JsonPath RC=new JsonPath(ConnectionRequest);

				String Requestmessage=RC.get("message");
					System.out.println("Requestmessage"+Requestmessage);
					Reporter.log("Connection request sent sucessfully");
	
		//Connection Accept
		
		 String ConnectionAccept=given().log().all().headers("Content-Type","application/json").param("id", PersonalprofIdforconnections)
								.headers("Authorization", a.buyertoken).header("email",buyermail)
								.when().get("api/v2/network/connection/accept").then().log().all().assertThat().statusCode(200).extract().response().asString();
								System.out.println(ConnectionAccept);
							JsonPath AC=new JsonPath(ConnectionAccept);

								String Acceptmessage=AC.get("message");
									System.out.println("Acceptmessage"+Acceptmessage);
									Reporter.log("Conection Accept Sucessfully");
		//Connection withdraw
			String ConnectionRequest1=given().log().all().headers("Content-Type","application/json").param("id",Friend2 )
											.headers("Authorization", a.AuthorizationToken).header("email",mail)
											.when().get("api/v2/network/connection/request").then().log().all().assertThat().statusCode(200).extract().response().asString();
											System.out.println(ConnectionRequest1);
					
		
									
								    String Connectionwithdraw=given().log().all().headers("Content-Type","application/json").param("id", Friend1)
											.headers("Authorization", a.AuthorizationToken).header("email",mail)
											.when().get("api/v2/network/connection/withdrawal").then().log().all().assertThat().statusCode(200).extract().response().asString();
											System.out.println(Connectionwithdraw);
										JsonPath cr=new JsonPath(Connectionwithdraw);

											String messagewithdraw=cr.get("message");
												System.out.println("Requestmessageforwithdraw"+messagewithdraw);
												Reporter.log("Connection withdraw Sucessfully");
		// Connection Reject
												
		         		 String Connectionreject=given().log().all().headers("Content-Type","application/json").param("id",Friend1 )
													.headers("Authorization", a.buyertoken).header("email",buyermail)
												.when().get("api/v2/network/connection/reject").then().log().all().assertThat().statusCode(200).extract().response().asString();
													System.out.println(Connectionreject);
												JsonPath cw=new JsonPath(Connectionreject);

															String reject=cw.get("message");
																System.out.println("messageforwithdraw"+reject);
																Reporter.log("Connection Reject Sucessfully");		
																
	    //Connection Remove
						
							 String Connectionremove=given().log().all().headers("Content-Type","application/json").param("id", PersonalprofIdforconnections)
																.headers("Authorization", a.AuthorizationToken).header("email",mail)
															.when().get("/api/v2/network/connection/remove").then().log().all().assertThat().statusCode(200).extract().response().asString();
														System.out.println(Connectionremove);
															JsonPath cR=new JsonPath(Connectionremove);

														String messageremove=cR.get("message");
							           				System.out.println("messageforremove"+messageremove);	
							           				Reporter.log("Connection Remove Sucessfully");
																
       //Connection Sent
							           				
							String Connectionsent=given().log().all().headers("Content-Type","application/json")
												.headers("Authorization", a.AuthorizationToken).header("email",mail)
														.when().get("api/v2/network/connection/sent").then().log().all().assertThat().statusCode(200).extract().response().asString();
													System.out.println(Connectionsent);
														JsonPath cS=new JsonPath(Connectionsent);

													String messagesent=cS.get("message");
						           				System.out.println("messageforsent"+messagesent);
	  //Connection Received
						           				
		String ConnectionReceived=given().log().all().headers("Content-Type","application/json")
														.headers("Authorization", a.AuthorizationToken).header("email",mail)
																.when().get("/api/v2/network/connection/received").then().log().all().assertThat().statusCode(200).extract().response().asString();
															System.out.println(ConnectionReceived);
																JsonPath Rc=new JsonPath(ConnectionReceived);

															String messageReceived=Rc.get("message");
								           				System.out.println("messageforReceived"+messageReceived);
		//Connections
		String Connections=given().log().all().headers("Content-Type","application/json").param("id",PersonalprofIdforconnections )
							                .headers("Authorization", a.AuthorizationToken).header("email",mail)
											.when().get("/api/v2/network/connections").then().log().all().assertThat().statusCode(200).extract().response().asString();
									         System.out.println(Connections);
											JsonPath Connectionsobj=new JsonPath(Connections);

										   String messageConnections=Connectionsobj.get("message");
								  		System.out.println("messageforConnections"+messageConnections);
	    //Recommendations
       	String Recommendations=given().log().all().headers("Content-Type","application/json").param("profile","personal" )
								                .headers("Authorization", a.AuthorizationToken).header("email",mail)
												.when().get("api/v2/network/recommendations").then().log().all().assertThat().statusCode(200).extract().response().asString();
										         System.out.println(Recommendations);
												JsonPath R=new JsonPath(Recommendations);

											   String messageRecommendations=R.get("message");
									  		System.out.println("messageforRecommendation"+messageRecommendations);
									  		Reporter.log("User Retrieve Recommandation Sucessfully");
		   
								  		
 								           				
}    
	    @Test(priority=9)
      public void Messanger() {
	    	
	    	
	    	String getpersonaldetailsForMessanger= given().log().all().headers("Content-Type","application/json")
	    			.headers("Authorization", a.AuthorizationToken).header("email",mail)
	    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
	    			System.out.println(getpersonaldetailsForMessanger);
	    			JsonPath Crm=new JsonPath(getpersonaldetailsForMessanger);
	    	        String PersonalprofIdformessanger = Crm.get("data._id");
	    	        System.out.println("PersonalprofIdformessanger "+PersonalprofIdformessanger);
	    	
	    	//post messanger
	    	 String Postmessanger=given().log().all().headers("Content-Type","application/json")
 					.headers("Authorization", a.AuthorizationToken).header("email",mail).body("{\r\n"
 							+ "  \"users\": [\r\n"
 							+ "    \""+PersonalprofIdformessanger+"\"\r\n"
 							+ "  ]\r\n"
 							+ "}")
 					.when().post("api/v2/messenger").then().log().all().assertThat().statusCode(200).extract().response().asString();
 					System.out.println(Postmessanger);
 					JsonPath Mess=new JsonPath(Postmessanger);

					String messangerId=Mess.get("data._id");
   				System.out.println("messangerId  "+messangerId);

 					
 					
 					
 					
 			//Get messanger
 					
 					String Getmessanger=given().log().all().headers("Content-Type","application/json")
			                .headers("Authorization", a.AuthorizationToken).header("email",mail)
							.when().get("api/v2/messenger").then().log().all().assertThat().statusCode(200).extract().response().asString();
					         System.out.println(Getmessanger);
//							JsonPath Connectionsobj=new JsonPath(Connections);
//
//						   String messageConnections=Connectionsobj.get("message");
//				  		System.out.println("messageforConnections"+messageConnections);
		
    	  //Post send message
		  String Posttext=given().log().all().headers("Content-Type","application/json")
					 					.headers("Authorization", a.AuthorizationToken).header("email",mail).body("{\r\n"
					 							+ "    \"conversationId\":\""+messangerId+"\",\r\n"
					 							+ "    \"text\":\"Good Morning\"\r\n"
					 							+ "}")
					 					.when().post("/api/v2/messenger/sendMessage").then().log().all().assertThat().statusCode(200).extract().response().asString();
	                                    System.out.println(Posttext);
	                                    JsonPath messageid=new JsonPath(Posttext);

	                					String messageconvid=messageid.get("data[0].message._id");
	                   				System.out.println("messageconvid  "+messageconvid);
	                   				Reporter.log("Send message sucessfully");
      
	                                    
	     //Get Message	
	          String Getmessage=given().log().all().headers("Content-Type","application/json").
	                			                headers("Authorization", a.AuthorizationToken).header("email",mail)
	                							.when().get("/api/v2/messenger/getMessage/"+messageconvid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
	                					         System.out.println(Getmessage); 
	    
	    //Get messenger converid
	           		String messangerconv=given().log().all().headers("Content-Type","application/json").param("type","BLOCK")
                			                .headers("Authorization", a.AuthorizationToken).header("email",mail)
                							.when().get("/api/v2/messenger/"+messangerId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
                					         System.out.println(messangerconv); 
        //Readmessage
                	String Readmessage=	given().log().all().headers("Content-Type","application/json").param("conversationId",messangerId)
			                .headers("Authorization", a.AuthorizationToken).header("email",mail)
							.when().get("api/v2/messenger/readMessage").then().log().all().assertThat().statusCode(200).extract().response().asString();
					         System.out.println(Readmessage); 
			         
                					         
        //Delete message
                String deletemessage = given().log().all().headers("Content-Type","application/json")
                						                		.headers("Authorization", a.AuthorizationToken).header("email",mail).body("{\r\n"
                						                				+ "  \"messageId\": \""+messageconvid+"\",\r\n"
                						                				+ "  \"conversationId\": \""+messangerId+"\"\r\n"
                						                				+ "}")
                						                	.when().delete("/api/v2/messenger/deleteMessage").then().log().all().assertThat().statusCode(200).extract().response().asString();
                						                				System.out.println(deletemessage);
                						                				Reporter.log("Sucessfully message deleted");	                					         
          //Delete Messenger
           /* String DeleteMessenger = given().log().all().headers("Content-Type","application/json")
                				         .headers("Authorization", a.AuthorizationToken).header("email",mail)
                				    .when().delete("api/v2/messenger/delete"+messangerId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
                				                				System.out.println(DeleteMessenger);
                				                				Reporter.log("Sucessfully messanger deleted");*/	         					         
	                			    		           					         
      
	    	        
   	        
	    	        
	    	        
	    	        
	    	        
	    	
	    
									
									  
												
											
				
				
				
				
				
	
	
	
	
	
	

	
	

	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
		
	
	
	//public void teardown() {
	//extents.flush();
									//}

		
	
			
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
		
	
	

	


