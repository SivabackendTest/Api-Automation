package Apimethods;

import static io.restassured.RestAssured.given;

import java.io.File;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Groups {
	AuthorizationToken a=new AuthorizationToken();

	@Test(priority=1)
	public void  CreateSocialpublicGroup() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

        File groupimage=new File("C:\\Users\\CURD Automation\\Downloads\\addressProofFront.png");

String CreateGroup= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("name","Spring social" ).multiPart("category", "social")
			.multiPart("privacy","public").multiPart("description","allsoftware").multiPart("interest","sports").multiPart("image",groupimage)
			.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

       JsonPath CG=new JsonPath(CreateGroup);

          String Creategroupmessage=CG.get("message");
          String GroupId = CG.get("data._id");
          String Groupname = CG.get("data.name");
          String Groupcategory=CG.get("data.category");
          String Groupprivacy=CG.get("data.privacy");
          String Groupdescription=CG.get("data.description");
          
			
			 
			Assert.assertEquals("SUCCESS",Creategroupmessage );
			Assert.assertEquals(Groupname,"Spring social" );
			Assert.assertEquals(Groupcategory ,"social");
			Assert.assertEquals(Groupprivacy,"public" );
			Assert.assertEquals(Groupdescription,"allsoftware" );

			Reporter.log("Endpoint :/api/v2/group/");
	        Reporter.log("StatusCode :200");
			Reporter.log("User Created public social group sucessfully ");
	}
	@Test(priority=2)
	public void  Createprofessional() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
        File groupimage=new File("C:\\Users\\CURD Automation\\Downloads\\addressProofFront.png");


String CreateprofessionalGroup= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("name","Spring Professional" ).multiPart("category", "professional")
			.multiPart("privacy","public").multiPart("description","allsoftware").multiPart("interest","sports").multiPart("image",groupimage)
			.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

       JsonPath CGp=new JsonPath(CreateprofessionalGroup);

          String Createprofessionalgroupmessage=CGp.get("message");
          String GroupprofessionalId = CGp.get("data._id");
          String Groupprofessionalname = CGp.get("data.name");
          String Groupprofessionalcategory=CGp.get("data.category");
          String Groupprofessionalprivacy=CGp.get("data.privacy");
          String GroupProfessionaldescription=CGp.get("data.description");
          
			Assert.assertEquals("SUCCESS",Createprofessionalgroupmessage );
			Assert.assertEquals(Groupprofessionalname,"Spring Professional" );
			Assert.assertEquals(Groupprofessionalcategory ,"professional");
			Assert.assertEquals(Groupprofessionalprivacy,"public" );
			Assert.assertEquals(GroupProfessionaldescription,"allsoftware" );

			Reporter.log("Endpoint :/api/v2/group/");
	        Reporter.log("StatusCode :200");
			Reporter.log("User Created public professional group Sucessfully");		
	}
	@Test(priority=3)
	public void  Createprivateprofessional() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";
        File groupimage=new File("C:\\Users\\CURD Automation\\Downloads\\addressProofFront.png");


String CreateprivateprofessionalGroup= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("name","Spring private Professional" ).multiPart("category", "professional")
			.multiPart("privacy","private").multiPart("description","allsoftware").multiPart("interest","sports").multiPart("image",groupimage)
			.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

       JsonPath CGp=new JsonPath(CreateprivateprofessionalGroup);

          String Createprivateprofessionalgroupmessage=CGp.get("message");
          String privateGroupprofessionalId = CGp.get("data._id");
          String privateGroupprofessionalname = CGp.get("data.name");
          String privateGroupprofessionalcategory=CGp.get("data.category");
          String privateGroupprofessionalprivacy=CGp.get("data.privacy");
          String privateGroupProfessionaldescription=CGp.get("data.description");
          
			Assert.assertEquals("SUCCESS",Createprivateprofessionalgroupmessage );
			Assert.assertEquals(privateGroupprofessionalname,"Spring private Professional" );
			Assert.assertEquals(privateGroupprofessionalcategory ,"professional");
			Assert.assertEquals(privateGroupprofessionalprivacy,"private" );
			Assert.assertEquals(privateGroupProfessionaldescription,"allsoftware" );

			Reporter.log("Endpoint :/api/v2/group/");
	        Reporter.log("StatusCode :200");
			Reporter.log("User Created public professional group Sucessfully");	
	}
	@Test(priority=4)
	public void  CreateSocialprivateGroup() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

        File privategroupimage=new File("C:\\Users\\CURD Automation\\Downloads\\addressProofFront.png");

String CreateprivateGroup= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("name","Spring social private" ).multiPart("category", "social")
			.multiPart("privacy","private").multiPart("description","allsoftware").multiPart("interest","sports").multiPart("image",privategroupimage)
			.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

       JsonPath CGpri=new JsonPath(CreateprivateGroup);

          String Createprivategroupmessage=CGpri.get("message");
          String privateGroupId = CGpri.get("data._id");
          String privateGroupname = CGpri.get("data.name");
          String privateGroupcategory=CGpri.get("data.category");
          String privateGroupprivacy=CGpri.get("data.privacy");
          String privateGroupdescription=CGpri.get("data.description");
          
			
			 
			Assert.assertEquals("SUCCESS",Createprivategroupmessage );
			Assert.assertEquals(privateGroupname,"Spring social private" );
			Assert.assertEquals(privateGroupcategory ,"social");
			Assert.assertEquals(privateGroupprivacy,"private" );
			Assert.assertEquals(privateGroupdescription,"allsoftware" );

			Reporter.log("Endpoint :/api/v2/group/");
	        Reporter.log("StatusCode :200");
			Reporter.log("User Created public social group sucessfully ");
	}
	@Test(priority=5)
	public void  GetGroup() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";


String CreateGroupforget= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("name","Siva social" ).multiPart("category", "social")
			.multiPart("privacy","public").multiPart("description","allsoftware").multiPart("interest","sports")
			.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

       JsonPath CGg=new JsonPath(CreateGroupforget);

          String getGroupId = CGg.get("data._id");
	
          String Getgroup= given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail).param("groupId", getGroupId)
					.when().get("/api/v2/group/").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(Getgroup);
					 JsonPath CGGet=new JsonPath(Getgroup);

			          String Createprivategroupmessage=CGGet.get("message");
			          String responseGroupId = CGGet.get("data._id");
						Assert.assertEquals(getGroupId,responseGroupId );				
	}
	@Test(priority=6)
	public void  UpdateGroup() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";


String CreateGroupforget= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("name","Siva social" ).multiPart("category", "social")
			.multiPart("privacy","public").multiPart("description","allsoftware").multiPart("interest","sports")
			.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

       JsonPath CGg=new JsonPath(CreateGroupforget);

          String getGroupId = CGg.get("data._id");
	
          String Updategroup= given().log().all().headers("Content-Type","application/json")
					.headers("Authorization", a.AuthorizationToken).header("email",a.mail).
					multiPart("name","Siva info social" ).multiPart("category", "social")
					.multiPart("privacy","public").multiPart("description","allsoftware").multiPart("interest","sports")
					.when().get("/api/v2/group/?groupId="+getGroupId+"").then().assertThat().statusCode(200).extract().response().asString();
					System.out.println(Updategroup);
					 JsonPath CGGet=new JsonPath(Updategroup);

			          String Createprivategroupmessage=CGGet.get("message");
			          String responseGroupId = CGGet.get("data._id");
						Assert.assertEquals(getGroupId,responseGroupId );
					
					
	}

	@Test(priority=7)
	public void  Addmember() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";


String CreateGroupforget= given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
			
			.headers("Authorization", a.AuthorizationToken).multiPart("name","Siva social" ).multiPart("category", "social")
			.multiPart("privacy","public").multiPart("description","allsoftware").multiPart("interest","sports")
			.when().post("/api/v2/group/").then().log().all().assertThat().statusCode(200).extract().response().asString();

       JsonPath CGg=new JsonPath(CreateGroupforget);

          String getGroupId = CGg.get("data._id");
	
 
						String Addmemberingroup= given().log().all().headers("Content-Type","application/json").header("email",a.mail)
											.headers("Authorization", a.AuthorizationToken).param("groupId",getGroupId).param("member_id",a.Memberid)
								.when().post("/api/v2/group/admin/").then().log().all().assertThat().statusCode(200).extract().response().asString();

					       JsonPath Groupmem=new JsonPath(Addmemberingroup);
					       
					
					
	}


}