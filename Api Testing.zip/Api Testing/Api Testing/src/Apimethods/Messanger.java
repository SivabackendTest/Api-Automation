package Apimethods;
import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
public class Messanger {
	AuthorizationToken a=new AuthorizationToken();

 @Test(priority=1)
public void postmessage() {
  
	String getpersonaldetailsForMessanger= given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getpersonaldetailsForMessanger);
			JsonPath Crm=new JsonPath(getpersonaldetailsForMessanger);
	        String PersonalprofIdformessanger = Crm.get("data._id");
	        System.out.println("PersonalprofIdformessanger "+PersonalprofIdformessanger);
	
	//post messanger
	 String Postmessanger=given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
						+ "  \"users\": [\r\n"
						+ "    \""+PersonalprofIdformessanger+"\"\r\n"
						+ "  ]\r\n"
						+ "}")
				.when().post("api/v2/messenger").then().log().all().assertThat().statusCode(200).extract().response().asString();
				System.out.println(Postmessanger);
				JsonPath Mess=new JsonPath(Postmessanger);

			String messangerId=Mess.get("data._id");
			                  String Messangermesssasge = Mess.get("message");
			System.out.println("messangerId  "+messangerId);
			Assert.assertEquals("SUCCESS",Messangermesssasge );

			Reporter.log("api/v2/messenger");
			Reporter.log("statusCode 200");
			//Reporter.log("User Messanger sucessfully");
				
				
				
				
		//Get messanger
				
				String Getmessanger=given().log().all().headers("Content-Type","application/json")
	                .headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("api/v2/messenger").then().log().all().assertThat().statusCode(200).extract().response().asString();
			         System.out.println(Getmessanger);
					JsonPath Connectionsobj=new JsonPath(Getmessanger);

				   String messageConnections=Connectionsobj.get("message");
					Assert.assertEquals("SUCCESS",messageConnections );
					Reporter.log("api/v2/messenger");
					Reporter.log("statusCode 200");
					Reporter.log("User data retrieve sucessfully");
		  		System.out.println("messageforConnections"+messageConnections);

  //Post send message
  String Posttext=given().log().all().headers("Content-Type","application/json")
			 					.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
			 							+ "    \"conversationId\":\""+messangerId+"\",\r\n"
			 							+ "    \"text\":\"Good Morning\"\r\n"
			 							+ "}")
			 					.when().post("/api/v2/messenger/sendMessage").then().log().all().assertThat().statusCode(200).extract().response().asString();
                                System.out.println(Posttext);
                                JsonPath messageid=new JsonPath(Posttext);

            					String messageconvid=messageid.get("data[0].message._id");
            					String sentmessagestatus = messageid.get("message");
               				System.out.println("messageconvid  "+messageconvid);
               				Assert.assertEquals("SUCCESS",sentmessagestatus );
        					Reporter.log("/api/v2/messenger/sendMessage");
        					Reporter.log("statusCode 200");
               				Reporter.log("User Send message sucessfully");

                                
 //Get Message	
      String Getmessage=given().log().all().headers("Content-Type","application/json").
            			                headers("Authorization", a.AuthorizationToken).header("email",a.mail)
            							.when().get("/api/v2/messenger/getMessage/"+messageconvid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
            					         System.out.println(Getmessage); 
                                         JsonPath Getmessageobj=new JsonPath(Posttext);
                                         String Getmessagestatus = Getmessageobj.get("message");
                                         Reporter.log("/api/v2/messenger/getMessage/");
                     					Reporter.log("statusCode 200");
                            				Reporter.log("User retrieve Send message data sucessfully");


//Get messenger converid
       		String messangerconv=given().log().all().headers("Content-Type","application/json").param("type","BLOCK")
        			                .headers("Authorization", a.AuthorizationToken).header("email",a.mail)
        							.when().get("/api/v2/messenger/"+messangerId+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
        					         System.out.println(messangerconv); 
//Readmessage
        	String Readmessage=	given().log().all().headers("Content-Type","application/json")
	                .headers("Authorization", a.AuthorizationToken).header("email",a.mail)
					.when().get("/api/v2/messenger/readMessage/"+messageconvid+"").then().log().all().assertThat().statusCode(200).extract().response().asString();
			         System.out.println(Readmessage); 
			         JsonPath Readmessageobj=new JsonPath(Posttext);
                     String readmessagestatus = Readmessageobj.get("message");
        				Assert.assertEquals("SUCCESS",readmessagestatus );

                     Reporter.log("/api/v2/messenger/getMessage/");
 					Reporter.log("statusCode 200");
        				Reporter.log("User retrieve Send message data sucessfully");
	         
        					         
//Delete message
        String deletemessage = given().log().all().headers("Content-Type","application/json")
        						                		.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
        						                				+ "  \"messageId\": \""+messageconvid+"\",\r\n"
        						                				+ "  \"conversationId\": \""+messangerId+"\"\r\n"
        						                				+ "}")
        						                	.when().delete("/api/v2/messenger/deleteMessage").then().log().all().assertThat().statusCode(200).extract().response().asString();
        						                				System.out.println(deletemessage);
        						                				JsonPath deletemessageobj=new JsonPath(Posttext);
        						                                String Deletemessagestatus = deletemessageobj.get("message");
        						                   				Assert.assertEquals("SUCCESS",Deletemessagestatus );

        						                                Reporter.log("/api/v2/messenger/deleteMessage");
        						            					Reporter.log("statusCode 200");

        						                				Reporter.log("Sucessfully message deleted");	                					         
  //Delete Messenger
    String DeleteMessenger = given().log().all().headers("Content-Type","application/json")
        				         .headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
        				         		+ "  \"conversationIds\": [\r\n"
        				         		+ "    \""+messangerId+"\"\r\n"
        				         		+ "    \r\n"
        				         		+ "  ]\r\n"
        				         		+ "}")
        				    .when().post("api/v2/messenger/delete/").then().log().all().assertThat().statusCode(200).extract().response().asString();
        				                				System.out.println(DeleteMessenger);
        				                				JsonPath deletemessangerobj=new JsonPath(Posttext);
						                                String Deletemessangerstatus = deletemessangerobj.get("message");
						                   				Assert.assertEquals("SUCCESS",Deletemessangerstatus );

						                                Reporter.log("api/v2/messenger/delete");
						            					Reporter.log("statusCode 200");

        				                				Reporter.log("Sucessfully messanger deleted");	         					         
            			    		           					         

}}
