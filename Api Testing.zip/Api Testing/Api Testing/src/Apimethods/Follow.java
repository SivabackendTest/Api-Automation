package Apimethods;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Follow {
	AuthorizationToken a=new AuthorizationToken();


	@Test(priority=1)
	public void Follow(){
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

	
	  String Createfollow=given().log().all().headers("Content-Type","application/json").
			  header("email",a.mail)
			.headers("Authorization", a.AuthorizationToken).body("{\r\n"
					+ "  \"following\": \""+a.FollowId+"\",\r\n"
					+ "  \"ref_model\": \"personal_profile\"\r\n"
					+ "}")
			.when().post("api/v2/network/follow").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(Createfollow);
		JsonPath Fs1=new JsonPath(Createfollow);

			String followmessage=Fs1.get("message");
				System.out.println("followermessage"+followmessage);
				
				Assert.assertEquals("SUCCESS",followmessage ); 

				Reporter.log("api/v2/network/follow");
				Reporter.log("statusCode 200");
				Reporter.log("User followed sucessfully");
				
	
				String getpersonaldetails = given().log().all().headers("Content-Type","application/json")
						.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
						.when().get("/api/v2/user/profile/").then().assertThat().statusCode(200).extract().response().asString();
						System.out.println(getpersonaldetails);
						JsonPath fp2=new JsonPath(getpersonaldetails);
				        String PersonalprofIdfollow = fp2.get("data._id");
				        System.out.println("PersonalUserId "+PersonalprofIdfollow);
				
				
				 String Createfollow1=given().log().all().headers("Content-Type","application/json").
						  header("email",a.buyermail)
						.headers("Authorization", a.buyertoken).body("{\r\n"
								+ "  \"following\": \""+PersonalprofIdfollow+"\",\r\n"
								+ "  \"ref_model\": \"personal_profile\"\r\n"
								+ "}")
						.when().post("api/v2/network/follow").then().log().all().assertThat().statusCode(200).extract().response().asString();
						System.out.println(Createfollow1);
		
	}
	@Test(priority=2)
	public void Followings() {

				String followingofUser = given().log().all().headers("Content-Type","application/json")
						.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
						.when().get("api/v2/network/followings").then().log().all().assertThat().statusCode(200).extract().response().asString();
						System.out.println(followingofUser);
						JsonPath Fs2=new JsonPath(followingofUser);
						 String followerUser = "message";
							String following=Fs2.getString(followerUser);
							System.out.println("meassage"+following);
							Assert.assertEquals("SUCCESS",following ); 
							Reporter.log("api/v2/network/followings");
							Reporter.log("statusCode 200");
							Reporter.log("following retrieve sucessfully");
							
	}
	@Test(priority=3)
	public void followings() {
				String followersofUser = given().log().all().headers("Content-Type","application/json")
								.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
									.when().get("api/v2/network/followers").then().log().all().assertThat().statusCode(200).extract().response().asString();
									System.out.println(followersofUser);
									JsonPath Fs3=new JsonPath(followersofUser);
									 String followers= "message";
										String Userfollowers=Fs3.getString(followers);
										System.out.println("meassage"+Userfollowers);
										Assert.assertEquals("SUCCESS",Userfollowers ); 

										Reporter.log("api/v2/network/followers");
										Reporter.log("statusCode 200");
										Reporter.log("following retrieve sucessfully");	
										
	}
	@Test(priority=4)
	public void Businessfollowers() {
					String Createbusinessforfollow = given().log().all().headers("Content-Type","application/json")
							.header("email",a.mail).body("{\r\n"
									+ "    \"businessName\":\""+a.BusinessName1+"\",\r\n"
									+ "    \"description\":\"services\",\r\n"
									+ "    \"industry\":\"Information Technology & Services\",\r\n"
									+ "    \"address\":\"Hyderabad\",\r\n"
									+ "    \"keywords\":[\"food\"],\r\n"
									+ "   \r\n"
									+ "    \"businessKind\":[\"Manufacturer\"],\r\n"
									+ "    \"lat\":\"19.93\",\r\n"
									+ "    \"long\":\"15.23\"\r\n"
									+ "}\r\n"
									+ "").headers("Authorization", a.AuthorizationToken)
					.when().post("api/v2/businessProfile").then().assertThat().statusCode(200).extract().response().asString();
		System.out.println(Createbusinessforfollow);
												JsonPath Jb1=new JsonPath(Createbusinessforfollow);

													String businessidfollow=Jb1.get("data[0]._id");
													System.out.println("businessid"+businessidfollow);					
										
			 String BusinessfollowersofUser = given().log().all().headers("Content-Type","application/json")
									.param("id", businessidfollow).headers("Authorization", a.AuthorizationToken).header("email",a.mail)
									.param("skip", "0").param("limit", "5")
									.when().get("/api/v2/network/business-followers").then().log().all().assertThat().statusCode(200).extract().response().asString();
									System.out.println(BusinessfollowersofUser);
									JsonPath Fs4=new JsonPath(BusinessfollowersofUser);
								   String Businessfollowers= "message";
									String BusinessUserfollowers=Fs4.getString(Businessfollowers);
									System.out.println("meassage"+BusinessUserfollowers);
									Assert.assertEquals("SUCCESS",BusinessUserfollowers ); 

									Reporter.log("api/v2/network/followers");
									Reporter.log("statusCode 200");
									Reporter.log("Business following data retrieve sucessfully");	
														
	}
	@Test(priority=5)
	public void Manage() {
						String Managenetwork = given().log().all().headers("Content-Type","application/json")
												.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
												.when().get("api/v2/network/manage-network").then().log().all().assertThat().statusCode(200).extract().response().asString();
												System.out.println(Managenetwork);
												JsonPath Fs5=new JsonPath(Managenetwork);
												 String UserManagenetwork= "message";
													String UserallManagenetwork=Fs5.getString(UserManagenetwork);
													System.out.println("meassage"+UserallManagenetwork);
													Assert.assertEquals("SUCCESS",UserallManagenetwork ); 

													Reporter.log("api/v2/network/manage-network");
													Reporter.log("statusCode 200");
													Reporter.log("User Getting all data");						
	}
	@Test(priority=6)
	public void Unfollow() {
			    String unfollow = given().log().all().headers("Content-Type","application/json")
															.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
																	+ "  \"following\": \""+a.FollowId+"\",\r\n"
																	+ "  \"ref_model\": \"personal_profile\"\r\n"
																	+ "}")
															.when().delete("/api/v2/network/follow").then().log().all().assertThat().statusCode(200).extract().response().asString();
															System.out.println(unfollow);
															JsonPath Fs5=new JsonPath(unfollow);
															 String Unfollowtheuser= "message";
																String Userunfollow=Fs5.getString(Unfollowtheuser);
															
															Assert.assertEquals("SUCCESS",Userunfollow ); 

															Reporter.log("/api/v2/network/follow");
															Reporter.log("statusCode 200");
															Reporter.log("Sucessfully unfollow");
								
	}
	@Test(priority=7)
	public void myreviews() {
						String Myreviews = given().log().all().headers("Content-Type","application/json")
												.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
												.when().get("/api/v2/network/my-reviews").then().log().all().assertThat().statusCode(200).extract().response().asString();
												System.out.println(Myreviews);
												JsonPath Fr6=new JsonPath(Myreviews);
												 String UserManagenetwork= "message";
													String myreviwdetails=Fr6.getString(UserManagenetwork);
													System.out.println("meassage"+myreviwdetails);
													Assert.assertEquals("SUCCESS",myreviwdetails); 
	}


}
