package Apimethods;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Connection {
	AuthorizationToken a=new AuthorizationToken();
	Businessprofile bc=new Businessprofile();


	@Test(priority=1)
	public void Connection() {
 		RestAssured.baseURI="http://hcpdev.curd.network:3000";

	String getpersonaldetailsForConnections = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getpersonaldetailsForConnections);
			JsonPath Cr=new JsonPath(getpersonaldetailsForConnections);
	        String PersonalprofIdforconnections = Cr.get("data._id");
	        System.out.println("personid "+PersonalprofIdforconnections);
	
	        String getpersonaldetailsForfriendConnection = given().log().all().headers("Content-Type","application/json")
	    			.headers("Authorization", a.buyertoken).header("email",a.buyermail)
	    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
	    			System.out.println(getpersonaldetailsForConnections);
	    			JsonPath Connect=new JsonPath(getpersonaldetailsForfriendConnection);
	    	        String Friend1 = Connect.get("data._id");
	    	        System.out.println("friend1"+Friend1);
	    	        String getpersonalForfriendConnection2 = given().log().all().headers("Content-Type","application/json")
	    	    			.headers("Authorization", a.SellerToken).header("email",a.sellermail)
	    	    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
	    	    			System.out.println(getpersonaldetailsForConnections);
	    	    			JsonPath Connect1=new JsonPath(getpersonaldetailsForfriendConnection);
	    	    	        String Friend2 = Connect.get("data._id");
	    	    	        System.out.println("friend1"+Friend2);
	    	    	
//Connections
//Connection Request
	
String ConnectionRequest=given().log().all().headers("Content-Type","application/json").param("id",Friend1 )
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
		.when().get("api/v2/network/connection/request").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(ConnectionRequest);
	JsonPath RC=new JsonPath(ConnectionRequest);

		String Requestmessage=RC.get("message");
	
			System.out.println("Requestmessage"+Requestmessage);
			Assert.assertEquals("SUCCESS",Requestmessage ); 

			Reporter.log("Endpoint :api/v2/network/connection/request");
	        Reporter.log("StatusCode :200");
			Reporter.log("Connection request sent sucessfully");

//Connection Accept

 String ConnectionAccept=given().log().all().headers("Content-Type","application/json").param("id", PersonalprofIdforconnections)
						.headers("Authorization", a.buyertoken).header("email",a.buyermail)
						.when().get("api/v2/network/connection/accept").then().log().all().assertThat().statusCode(200).extract().response().asString();
						System.out.println(ConnectionAccept);
					JsonPath AC=new JsonPath(ConnectionAccept);

						String Acceptmessage=AC.get("message");
							System.out.println("Acceptmessage"+Acceptmessage);
							Assert.assertEquals("SUCCESS",Acceptmessage ); 

							Reporter.log("Endpoint :api/v2/network/connection/accept");
					        Reporter.log("StatusCode :200");
							Reporter.log("Conection Accept Sucessfully");
	}
//Connection withdraw
		@Test(priority=2)	
		public void WithdrawConnection() {
			 String getpersonaldetailsForfriend2Connection = given().log().all().headers("Content-Type","application/json")
		    			.headers("Authorization", a.SellerToken).header("email",a.sellermail)
		    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
		    			System.out.println(getpersonaldetailsForfriend2Connection);
		    			JsonPath Connect=new JsonPath(getpersonaldetailsForfriend2Connection);
		    	        String Friend3 = Connect.get("data._id");
		    	        System.out.println("friend1"+Friend3);						
							
							
	String ConnectionRequest4=given().log().all().headers("Content-Type","application/json").param("id",Friend3 )
									.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
									.when().get("api/v2/network/connection/request").then().log().all().assertThat().statusCode(200).extract().response().asString();
									System.out.println(ConnectionRequest4);
			

							
						    String Connectionwithdraw=given().log().all().headers("Content-Type","application/json").param("id", Friend3)
									.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
									.when().get("api/v2/network/connection/withdrawal").then().log().all().assertThat().statusCode(200).extract().response().asString();
									System.out.println(Connectionwithdraw);
								JsonPath cr=new JsonPath(Connectionwithdraw);

									String messagewithdraw=cr.get("message");
									Assert.assertEquals("SUCCESS",messagewithdraw ); 

										System.out.println("Requestmessageforwithdraw"+messagewithdraw);
										Reporter.log("Endpoint :api/v2/network/connection/withdrawal");
								        Reporter.log("StatusCode :200");
										Reporter.log("Connection withdraw Sucessfully");
		}
		@Test(priority=3)
		public void ConnectionReject() {
// Connection Reject
					
		String getpersonaldetailsForfriendrejection= given().log().all().headers("Content-Type","application/json")
    			.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail)
    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
    			System.out.println(getpersonaldetailsForfriendrejection);
    			JsonPath Connect2=new JsonPath(getpersonaldetailsForfriendrejection);
    	        String Friend7 = Connect2.get("data._id");
    	        System.out.println("friend5"+Friend7);
    	        String getpersonaldetailsForfriendreject= given().log().all().headers("Content-Type","application/json")
    	    			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
    	    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
    	    			System.out.println(getpersonaldetailsForfriendreject);
    	    			JsonPath Connect3=new JsonPath(getpersonaldetailsForfriendreject);
    	    	        String Friend9 = Connect3.get("data._id");
    	    	        System.out.println("friend9"+Friend9);
    	        
    	        String ConnectionRequestforreject=given().log().all().headers("Content-Type","application/json").param("id",Friend7 )
    	        		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
    	        		.when().get("api/v2/network/connection/request").then().log().all().assertThat().statusCode(200).extract().response().asString();
    	        		System.out.println(ConnectionRequestforreject);
    	        
         		 String Connectionreject=given().log().all().headers("Content-Type","application/json").param("id",Friend9)
											.headers("Authorization", a.ReferrarToken).header("email",a.Referrermail)
										.when().get("api/v2/network/connection/reject").then().log().all().assertThat().statusCode(200).extract().response().asString();
											System.out.println(Connectionreject);
										JsonPath cw=new JsonPath(Connectionreject);

													String reject=cw.get("message");
														System.out.println("messageforreject"+reject);
														Assert.assertEquals("SUCCESS",reject ); 
		
														Reporter.log("Endpoint :api/v2/network/connection/reject");
												        Reporter.log("StatusCode :200");
														Reporter.log("Connection Reject Sucessfully");		
}					
		@Test(priority=4)
		public void ConnectionRemove() {
//Connection Remove
			String getpersonaldetailsForfriendConnection = given().log().all().headers("Content-Type","application/json")
	    			.headers("Authorization", a.buyertoken).header("email",a.buyermail)
	    			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
	    			System.out.println(getpersonaldetailsForfriendConnection);
	    			JsonPath Connect=new JsonPath(getpersonaldetailsForfriendConnection);
	    	        String Friend6 = Connect.get("data._id");
	    	        System.out.println("friend6"+Friend6);
		 String ConnectionRequest=given().log().all().headers("Content-Type","application/json").param("id",Friend6 )
	        		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
	        		.when().get("api/v2/network/connection/request").then().log().all().assertThat().statusCode(200).extract().response().asString();
	        		System.out.println(ConnectionRequest);
				
					 String Connectionremove=given().log().all().headers("Content-Type","application/json").param("id", Friend6)
														.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
													.when().get("/api/v2/network/connection/remove").then().log().all().assertThat().statusCode(200).extract().response().asString();
												System.out.println(Connectionremove);
													JsonPath cR=new JsonPath(Connectionremove);

												String messageremove=cR.get("message");
					           				System.out.println("messageforremove"+messageremove);
											Assert.assertEquals("SUCCESS",messageremove ); 

					           				Reporter.log("Endpoint :/api/v2/network/connection/remove");
									        Reporter.log("StatusCode :200");
					           				Reporter.log("Connection Remove Sucessfully");
}
@Test(priority=4)
public void Connectionsent() {
//Connection Sent
					           				
					String Connectionsent=given().log().all().headers("Content-Type","application/json")
										.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
												.when().get("api/v2/network/connection/sent").then().log().all().assertThat().statusCode(200).extract().response().asString();
											System.out.println(Connectionsent);
												JsonPath cS=new JsonPath(Connectionsent);
												
											String messagesent=cS.get("message");
				           				System.out.println("messageforsent"+messagesent);
										Assert.assertEquals("SUCCESS",messagesent );
										Reporter.log("Endpoint :api/v2/network/connection/sent");
								        Reporter.log("StatusCode :200");
				           				Reporter.log("Connection Sent data retrieve Sucessfully");


}
//Connection Received
	@Test(priority=5)	
	public void ConnectionReceive() {
String ConnectionReceived=given().log().all().headers("Content-Type","application/json")
												.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
														.when().get("/api/v2/network/connection/received").then().log().all().assertThat().statusCode(200).extract().response().asString();
													System.out.println(ConnectionReceived);
														JsonPath Rc=new JsonPath(ConnectionReceived);

													String messageReceived=Rc.get("message");
													Assert.assertEquals("SUCCESS",messageReceived );
													

						           				System.out.println("messageforReceived"+messageReceived);
						           				Reporter.log("Endpoint :/api/v2/network/connection/received");
										        Reporter.log("StatusCode :200");
						           				Reporter.log("Connection Received data retrieve Sucessfully");
						           				
	}
	@Test(priority=6)
	public void Connections() {
//Connections
		String getpersonaldetailsForConnections = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(getpersonaldetailsForConnections);
				JsonPath Cr=new JsonPath(getpersonaldetailsForConnections);
		        String PersonalprofIdforconnection = Cr.get("data._id");
		
String Connections=given().log().all().headers("Content-Type","application/json").param("id",PersonalprofIdforconnection )
					                .headers("Authorization", a.AuthorizationToken).header("email",a.mail)
									.when().get("/api/v2/network/connections").then().log().all().assertThat().statusCode(200).extract().response().asString();
							         System.out.println(Connections);
									JsonPath Connectionsobj=new JsonPath(Connections);

								   String messageConnections=Connectionsobj.get("message");
						  		System.out.println("messageforConnections"+messageConnections);
								Assert.assertEquals("SUCCESS",messageConnections );
								Reporter.log("Endpoint :/api/v2/network/connections");
						        Reporter.log("StatusCode :200");
						  		Reporter.log("User Retrieve Connections data Sucessfully");

	}
	@Test(priority=7)
	public void Recommandations() {
//Recommendations
	String Recommendations=given().log().all().headers("Content-Type","application/json").param("profile","personal" )
						                .headers("Authorization", a.AuthorizationToken).header("email",a.mail)
										.when().get("api/v2/network/recommendations").then().log().all().assertThat().statusCode(200).extract().response().asString();
								         System.out.println(Recommendations);
										JsonPath R=new JsonPath(Recommendations);

									   String messageRecommendations=R.get("message");
										Assert.assertEquals("SUCCESS",messageRecommendations );
  
							  		System.out.println("messageforRecommendation"+messageRecommendations);
							  		Reporter.log("Endpoint :api/v2/network/recommendations");
							        Reporter.log("StatusCode :200");
							  		Reporter.log("User Retrieve Recommandation Sucessfully");
   
						  		
							           				
}    
	@Test(priority=8)
	public void PersonalOraganization() {
//Recommendations
	String organizationRecommendations=given().log().all().headers("Content-Type","application/json").param("type","organization")
	                                       .param("skip", "0").param("limit", "5")
						                .headers("Authorization", a.AuthorizationToken).header("email",a.mail)
						       
										.when().get("/api/v2/network/personal-recommendations").then().log().all().assertThat().statusCode(200).extract().response().asString();
								         System.out.println(organizationRecommendations);
										JsonPath R=new JsonPath(organizationRecommendations);

									   String messageorganizationRecommendations=R.get("message");
										Assert.assertEquals("SUCCESS",messageorganizationRecommendations );
  
							  		System.out.println("messageforRecommendation"+messageorganizationRecommendations);
							  		Reporter.log("Endpoint :/api/v2/network/personal-recommendations");
							        Reporter.log("StatusCode :200");
							  		Reporter.log("User Retrieve Recommandation Sucessfully");
   
						  									           				
} 
	@Test(priority=9)
	public void Personalinstitute() {
//Recommendations
	String organizationRecommendations=given().log().all().headers("Content-Type","application/json").param("type","institute")
	                                       .param("skip", "0").param("limit", "5")
						                .headers("Authorization", a.AuthorizationToken).header("email",a.mail)
						       
										.when().get("/api/v2/network/personal-recommendations").then().log().all().assertThat().statusCode(200).extract().response().asString();
								         System.out.println(organizationRecommendations);
										JsonPath R=new JsonPath(organizationRecommendations);

									   String messageinstiRecommendations=R.get("message");
										Assert.assertEquals("SUCCESS",messageinstiRecommendations );
  
							  		System.out.println("messageforRecommendation"+messageinstiRecommendations);
							  		Reporter.log("Endpoint :/api/v2/network/personal-recommendations");
							        Reporter.log("StatusCode :200");
							  		Reporter.log("User Retrieve Recommandation Sucessfully");
   
						  		
							           				
}
	@Test(priority=10)
	public void getallconnections() {
		//Recommendations
			String allconnections=given().log().all().headers("Content-Type","application/json")
			                                       .param("skip", "0").param("limit", "5")
								                .headers("Authorization", a.AuthorizationToken).header("email",a.mail)
								       
												.when().get("/api/v2/network/get-all-connection").then().log().all().assertThat().statusCode(200).extract().response().asString();
										         System.out.println(allconnections);
												JsonPath R=new JsonPath(allconnections);

											   String messageallconnections=R.get("message");
												Assert.assertEquals("SUCCESS",messageallconnections );
		  
									  		System.out.println("messageforRecommendation"+messageallconnections);
									  		Reporter.log("Endpoint :/api/v2/network/get-all-connection");
									        Reporter.log("StatusCode :200");
									  		Reporter.log("User Retrieve all connectionslist Sucessfully");
		   							           				
		}
	@Test(priority=11)
	public void Businessconnectionrecom() {
		//Recommendations
			String bconnectionrec=given().log().all().headers("Content-Type","application/json").param("businessId",bc.BusinessProfileId)
			                                       .param("skip", "0").param("limit", "5")
								                .headers("Authorization", a.AuthorizationToken).header("email",a.mail)
								       
												.when().get("/api/v2/network/user-recommendations-for-business-contacts").then().log().all().assertThat().statusCode(200).extract().response().asString();
										         System.out.println(bconnectionrec);
												JsonPath BR=new JsonPath(bconnectionrec);

											   String messageBusiconnections=BR.get("message");
												Assert.assertEquals("SUCCESS",messageBusiconnections );
		  
									  		System.out.println("messageforbconnection"+messageBusiconnections);
									  		Reporter.log("Endpoint :/api/v2/network/user-recommendations-for-business-contacts");
									        Reporter.log("StatusCode :200");
									  		Reporter.log("User Retrieve all connectionslist Sucessfully");
		   							           				
		}
	@Test(priority=12)
	public void Businessfollow() {
		//Recommendations
			String busfollow=given().log().all().headers("Content-Type","application/json").param("businessId",bc.BusinessProfileId)
			                                       .param("skip", "0").param("limit", "5")
								                .headers("Authorization", a.AuthorizationToken).header("email",a.mail)
								       
												.when().get("/api/v2/network/user-recommendations-for-business-follow").then().log().all().assertThat().statusCode(200).extract().response().asString();
										         System.out.println(busfollow);
												JsonPath Bf=new JsonPath(busfollow);

											   String messageBusifollow=Bf.get("message");
												Assert.assertEquals("SUCCESS",messageBusifollow );
		  
									  		System.out.println("messageforbconnection"+messageBusifollow);
									  		Reporter.log("Endpoint :/api/v2/network/user-recommendations-for-business-follow");
									        Reporter.log("StatusCode :200");
									  		Reporter.log("User Retrieve all connectionslist Sucessfully");
		   							           				
		}
	

	
}
