package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Useractions {
	AuthorizationToken a=new AuthorizationToken();
	Personal P=new Personal();

	@Test(priority=1)
	
	public void Block() {
		RestAssured.baseURI="http://hcpdev.curd.network:3000";

		String getpersonaldetailsForblock = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.buyertoken).header("email",a.buyermail)
				.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(getpersonaldetailsForblock);
				JsonPath pg=new JsonPath(getpersonaldetailsForblock);
		        String PersonalprofIdforblock = pg.get("data._id");
		        System.out.println("personid "+PersonalprofIdforblock);
		
	String Blocktheuser=given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
					+ "  \"ref_id\": \""+PersonalprofIdforblock+"\",\r\n"
					+ "  \"ref_model\": \"personal_profile\"\r\n"
					+ "}\r\n"
					+ "")
			.when().post("api/v2/user-action/block").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(Blocktheuser);
		JsonPath block=new JsonPath(Blocktheuser);

			String Requestmessageapiblock=block.get("message");
		
				System.out.println("Requestmessage"+Requestmessageapiblock);
				Assert.assertEquals("SUCCESS",Requestmessageapiblock ); 

				Reporter.log("Endpoint :/api/v2/user-action/block");
		        Reporter.log("StatusCode :200");
				Reporter.log("User block sucessfully");
	}
@Test(priority=2)
	
	public void Blockusers() {

		
	String Blocktheuser=given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("/api/v2/user-action/blocked-users").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(Blocktheuser);
		JsonPath block=new JsonPath(Blocktheuser);

			String Requestmessagebuser=block.get("message");
		
				System.out.println("Requestmessage"+Requestmessagebuser);
				Assert.assertEquals("SUCCESS",Requestmessagebuser ); 

				Reporter.log("Endpoint :/api/v2/user-action/unblock");
		        Reporter.log("StatusCode :200");
				Reporter.log("User retrieve blocker list sucessfully");
	}
	
	
	
	
@Test(priority=3)
	
	public void UnBlock() {

		String getpersonaldetailsForblock = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.buyertoken).header("email",a.buyermail)
				.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(getpersonaldetailsForblock);
				JsonPath pg=new JsonPath(getpersonaldetailsForblock);
		        String PersonalprofIdforblock = pg.get("data._id");
		        System.out.println("personid "+PersonalprofIdforblock);
		
	String Blocktheuser=given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
					+ "  \"ref_id\": \""+PersonalprofIdforblock+"\",\r\n"
					+ "  \"ref_model\": \"personal_profile\"\r\n"
					+ "}\r\n"
					+ "")
			.when().post("/api/v2/user-action/unblock").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(Blocktheuser);
		JsonPath block=new JsonPath(Blocktheuser);

			String Requestmessageapiblock=block.get("message");
		
				System.out.println("Requestmessage"+Requestmessageapiblock);
				Assert.assertEquals("SUCCESS",Requestmessageapiblock ); 

				Reporter.log("Endpoint :/api/v2/user-action/unblock");
		        Reporter.log("StatusCode :200");
				Reporter.log("User unblock sucessfully");
	}
	
@Test(priority=4)

public void Ignore() {

	String getpersonaldetailsForIgnore = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.buyertoken).header("email",a.buyermail)
			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getpersonaldetailsForIgnore);
			JsonPath UI=new JsonPath(getpersonaldetailsForIgnore);
	        String PersonalprofIdforignore = UI.get("data._id");
	        System.out.println("personid "+PersonalprofIdforignore);
	
String Ignore=given().log().all().headers("Content-Type","application/json")
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
				+ "  \"ref_id\": \""+PersonalprofIdforignore+"\",\r\n"
				+ "  \"ref_model\": \"personal_profile\"\r\n"
				+ "}\r\n"
				+ "")
		.when().post("/api/v2/user-action/ignore").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(Ignore);
	JsonPath ignore=new JsonPath(Ignore);

		String Requestmessageapiignore=ignore.get("message");
	
			System.out.println("Requestmessage"+Requestmessageapiignore);
			Assert.assertEquals("SUCCESS",Requestmessageapiignore ); 

			Reporter.log("Endpoint :/api/v2/user-action/ignore");
	        Reporter.log("StatusCode :200");
			Reporter.log("User Ignore sucessfully");
}
@Test(priority=5)

public void Report() {

	String getpersonaldetailsForreport = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.buyertoken).header("email",a.buyermail)
			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getpersonaldetailsForreport);
			JsonPath rep=new JsonPath(getpersonaldetailsForreport);
	        String PersonalprofIdforreport = rep.get("data._id");
	        System.out.println("personid "+PersonalprofIdforreport);
	
String UserReport=given().log().all().headers("Content-Type","application/json")
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail).body("{\r\n"
				+ "  \"ref_id\": \""+PersonalprofIdforreport+"\",\r\n"
				+ "  \"ref_model\": \"personal_profile\",\r\n"
				+ "  \"reason\": {\r\n"
				+ "    \"type\": \"Hate Speach\",\r\n"
				+ "    \"text\": \"Words that could ....\"\r\n"
				+ "  }\r\n"
				+ "}")
		.when().post("/api/v2/user-action/report").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(UserReport);
	JsonPath Report=new JsonPath(UserReport);

		String Requestmessagereport=Report.get("message");
	
			System.out.println("Requestmessage"+Requestmessagereport);
			Assert.assertEquals("SUCCESS",Requestmessagereport ); 
 
			Reporter.log("Endpoint :/api/v2/user-action/report");
	        Reporter.log("StatusCode :200");
			Reporter.log("User reported sucessfully");
}
@Test(priority=6)

public void Reportpost() {

	String getpersonalcreatepostdetails = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getpersonalcreatepostdetails);
			JsonPath cp=new JsonPath(getpersonalcreatepostdetails);
	        String PersonalprofIdforpost = cp.get("data._id");
	        System.out.println("PersonalUserId "+PersonalprofIdforpost);

			 String CreatePostforreport=given().log().all().headers("Content-Type","multipart/form-data").header("email",a.mail)
						.headers("Authorization", a.AuthorizationToken).multiPart("postType","social").multiPart("visibleTo","everyone")
						.multiPart("caption","GoodMorningAll").multiPart("majorIndustry","Development").multiPart("minorIndustry","services")
						.multiPart("createdBy.ref_id",PersonalprofIdforpost).multiPart("createdBy.ref_model","personal_profile").multiPart("isRepost","false")
						.when().post("api/v2/post/create").then().log().all().assertThat().statusCode(200).extract().response().asString();
				System.out.println(CreatePostforreport);
					JsonPath postreport=new JsonPath(CreatePostforreport);

						String Postmessage=postreport.get("message");
						String PostIdforreport=postreport.get("data._id");
						System.out.println("PostId "+PostIdforreport);
							System.out.println("Postmessage"+Postmessage);
							
String UserpostReport=given().log().all().headers("Content-Type","application/json")
		.headers("Authorization", a.buyertoken).header("email",a.buyermail).body("{\r\n"
				+ "  \"postId\": \""+PostIdforreport+"\",\r\n"
				+ "  \"postType\": \"social\",\r\n"
				+ "  \"reason\": {\r\n"
				+ "    \"type\": \"Hate Speach\",\r\n"
				+ "    \"text\": \"Words that could ....\"\r\n"
				+ "  }\r\n"
				+ "}")
		.when().post("/api/v2/user-action/report-post").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(UserpostReport);
	JsonPath Report=new JsonPath(UserpostReport);

		String Requestmessagepostreport=Report.get("message");
	
			System.out.println("Requestmessage"+Requestmessagepostreport);
			Assert.assertEquals("SUCCESS",Requestmessagepostreport ); 
 
			Reporter.log("Endpoint :/api/v2/user-action/report-post");
	        Reporter.log("StatusCode :200");
			Reporter.log("User post reported sucessfully");
}


@Test(priority=7)

public void supportticket() {
	
String Supportticket=given().log().all().headers("Content-Type","multipart/form-data")
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail).multiPart("category","Wallet & CURD coins")
		.multiPart("issue","Unable to buy CURD coins")
		.when().post("/api/v2/user-action/support-ticket").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(Supportticket);
	JsonPath supportticketob=new JsonPath(Supportticket);

		String Ticket=supportticketob.get("message");
	
			System.out.println("Requestmessage"+Ticket);
			Assert.assertEquals("SUCCESS",Ticket ); 
 
			Reporter.log("Endpoint :/api/v2/user-action/support-ticket");
	        Reporter.log("StatusCode :200");
			Reporter.log("User raise support ticket sucessfully");
}
@Test(priority=8)

public void helpsupport() {
	
String Supporthelp=given().log().all().headers("Content-Type","application/json")
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
		.when().get("/api/v2/user-action/help-support").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(Supporthelp);
	JsonPath supportticketob=new JsonPath(Supporthelp);

		String Ticket=supportticketob.get("message");
	
			System.out.println("Requestmessage"+Ticket);
			Assert.assertEquals("SUCCESS",Ticket ); 
 
			Reporter.log("Endpoint :/api/v2/user-action/help-support");
	        Reporter.log("StatusCode :200");
			Reporter.log("User retrieve help support sucessfully");
}
@Test(priority=9)
public void Createreview() {
	String getpersonalforreview = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getpersonalforreview);
			JsonPath cp=new JsonPath(getpersonalforreview);
	        String PersonalprofIdreview= cp.get("data._id");
	        System.out.println("PersonalUserId "+PersonalprofIdreview);
	
	
String Review=given().log().all().headers("Content-Type","application/json").body("{\r\n"
		+ "  \"createdBy\": \""+PersonalprofIdreview+"\",\r\n"
		+ "  \"businessId\": \""+a.Businessid+"\",\r\n"
		+ "  \"review\": \"Dhai is amazing company with variety of dairy products\",\r\n"
		+ "  \"rating\": 5\r\n"
		+ "}\r\n"
		+ "")
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
		.when().post("/api/v2/user-action/create-review").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(Review);
	JsonPath supportticketob=new JsonPath(Review);
	String reviewId = supportticketob.get("data._id");
		String Reviewmessage=supportticketob.get("message");
	
			System.out.println("Requestmessage"+Reviewmessage);
			Assert.assertEquals("SUCCESS",Reviewmessage ); 
 
			Reporter.log("Endpoint :/api/v2/user-action/create-review");
	        Reporter.log("StatusCode :200");
			Reporter.log("User Reviewed business sucessfully");
}
@Test(priority=10)
public void Retrievereview() {

String GetReview=given().log().all().headers("Content-Type","application/json").param("skip","0")
.param("limit", "5").param("businessId", a.Businessid)
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
		.when().get("/api/v2/user-action/get-review").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(GetReview);
	JsonPath getreviewobj=new JsonPath(GetReview);

		String getReviewmessage=getreviewobj.get("message");
	
			System.out.println("Requestmessage"+getReviewmessage);
			Assert.assertEquals("SUCCESS",getReviewmessage ); 
 
			Reporter.log("Endpoint :/api/v2/user-action/get-review");
	        Reporter.log("StatusCode :200");
			Reporter.log("User retrieve review sucessfully");
}

@Test(priority=11)
public void BusinessIreview() {

String IReview=given().log().all().headers("Content-Type","application/json").param("skip","0")
.param("limit", "5")
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
		.when().get("/api/v2/user-action/business-i-review").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(IReview);
	JsonPath getreviewobj=new JsonPath(IReview);

		String getReviewmessage=getreviewobj.get("message");
	
			System.out.println("Requestmessage"+getReviewmessage);
			Assert.assertEquals("SUCCESS",getReviewmessage ); 
 
			Reporter.log("Endpoint :/api/v2/user-action/get-review");
	        Reporter.log("StatusCode :200");
			Reporter.log("User retrieve review sucessfully");
}
@Test(priority=12)
public void Reviewforbusiness() {
String GetReview=given().log().all().headers("Content-Type","application/json").param("skip","0")
.param("limit", "5").param("businessId", a.Businessid)
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
		.when().get("/api/v2/user-action/review-for-business").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(GetReview);
	JsonPath getreviewobj=new JsonPath(GetReview);

		String getReviewmessage=getreviewobj.get("message");
	
			System.out.println("Requestmessage"+getReviewmessage);
			Assert.assertEquals("SUCCESS",getReviewmessage ); 
 
			Reporter.log("Endpoint :/api/v2/user-action/review-for-business");
	        Reporter.log("StatusCode :200");
			Reporter.log("User retrieve reviewed business list sucessfully");
}
@Test(priority=14)
public void BusinessAction() {
	String Ignorebusiness=given().log().all().headers("Content-Type","application/json").body("{\r\n"
			+ "  \"personalId\": \""+P.PersonalprofileId+"\",\r\n"
			+ "  \"businessId\": \""+a.Businessid+"\",\r\n"
			+ "  \"type\": \"ignore\"\r\n"
			+ "}")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().post("/api/v2/user-action/business-action").then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(Ignorebusiness);
		JsonPath supportticketob=new JsonPath(Ignorebusiness);
		
			String BusinessIgnoremessage=supportticketob.get("message");
		
				System.out.println("Requestmessage"+BusinessIgnoremessage);
				Assert.assertEquals("SUCCESS",BusinessIgnoremessage ); 
	 
				Reporter.log("Endpoint :/api/v2/user-action/business-action");
		        Reporter.log("StatusCode :200");
				Reporter.log("User Ignore the Business connection");
}


@Test(priority=13)
public void Deletereview() {
	
	String getpersonalfordeleter = given().log().all().headers("Content-Type","application/json")
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().get("api/v2/user/profile").then().assertThat().statusCode(200).extract().response().asString();
			System.out.println(getpersonalfordeleter);
			JsonPath cp=new JsonPath(getpersonalfordeleter);
	        String PersonalprofIdreview= cp.get("data._id");
	        System.out.println("PersonalUserId "+PersonalprofIdreview);
	
	        String Review=given().log().all().headers("Content-Type","application/json").body("{\r\n"
	        		+ "  \"createdBy\": \""+PersonalprofIdreview+"\",\r\n"
	        		+ "  \"businessId\": \""+a.Businessid+"\",\r\n"
	        		+ "  \"review\": \"Dhai is amazing company with variety of dairy products\",\r\n"
	        		+ "  \"rating\": 5\r\n"
	        		+ "}\r\n"
	        		+ "")
	        		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
	        		.when().post("/api/v2/user-action/create-review").then().log().all().assertThat().statusCode(200).extract().response().asString();
	        		System.out.println(Review);
	        	JsonPath supportticketob=new JsonPath(Review);
	        	String reviewId = supportticketob.get("data._id");
	        		String Reviewmessage=supportticketob.get("message");
	        		

String DeleteReview=given().log().all().headers("Content-Type","application/json")
.param("id",reviewId ).param("businessId", a.Businessid)
		.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
		.when().delete("/api/v2/user-action/delete-review").then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println(DeleteReview);
	JsonPath deletobj=new JsonPath(DeleteReview);

		String DeleteReviewmessage=deletobj.get("message");
	
			System.out.println("Requestmessage"+DeleteReviewmessage);
			Assert.assertEquals("SUCCESS",DeleteReviewmessage ); 
 
			Reporter.log("Endpoint :/api/v2/user-action/delete-review");
	        Reporter.log("StatusCode :200");
			Reporter.log("User delete review sucessfully");
}


}
