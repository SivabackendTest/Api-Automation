package Apimethods;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class BusinessConnections {
	public AuthorizationToken token;
	public String businessfollowid;

	AuthorizationToken a=new AuthorizationToken();
	Businessprofile bp=new Businessprofile();
	@Test(priority=1)
	public void BusinessConnection(){
		String getbusinessConnection = given().log().all().headers("Content-Type","application/json")
				.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
				.when().get("/api/v2/network/business-connection").then().assertThat().statusCode(200).extract().response().asString();
				System.out.println(getbusinessConnection);
				
				JsonPath js9=new JsonPath(getbusinessConnection);
				
								String businessgetconnectionMessage=js9.get("message");
								System.out.println("businessConnectiongetapi message"+businessgetconnectionMessage);
								Assert.assertEquals("SUCCESS",businessgetconnectionMessage );

				Reporter.log("Endpoint :/api/v2/network/business-connection");
		        Reporter.log("StatusCode :200");
					Reporter.log("Retrieve business profile Connections sucessful");
					}
	@Test(priority=2)
	public void BusinessCreateConnection(){
	Response CreatebusinessConnection = given().log().all().headers("Content-Type","application/json").header("email",a.mail)
			.body("{\r\n"
					+ "  \"requestedBy\": \""+bp.BusinessProfileId+"\",\r\n"
					+ "  \"requestedTo\": \"6564a1961bf9b40720a296b6\",\r\n"
					+ "  \"module\": \"follow\"\r\n"
					+ "}")
			.headers("Authorization", a.AuthorizationToken)
			.when().post("/api/v2/network/business-connection");
			 String businessfollowid = CreatebusinessConnection.then().contentType(ContentType.JSON).extract().path("data._id");

			 String Businessprofilemessage = CreatebusinessConnection.then().contentType(ContentType.JSON).extract().path("message");

			Assert.assertEquals("SUCCESS",Businessprofilemessage );
			
			Reporter.log("Endpoint :/api/v2/network/business-connection");
	        Reporter.log("StatusCode :200");
			Reporter.log("Updated business profile sucessfully");
}
	@Test(priority=3)
	public void Deletefollow() {
	String deletefollow = given().log().all().headers("Content-Type","application/json").param("id", businessfollowid)
			.headers("Authorization", a.AuthorizationToken).header("email",a.mail)
			.when().delete("/api/v2/network/business-connection")
			.then().log().all().assertThat().statusCode(200).extract().response().asString();
			System.out.println(deletefollow);
			JsonPath jdf=new JsonPath(deletefollow);
			String businessdelete=jdf.get("message");
			Assert.assertEquals("SUCCESS",businessdelete );

			
			Reporter.log("Endpoint :api/v2/businessProfile");
	        Reporter.log("StatusCode :200");
			Reporter.log("Sucessfully deleted business follow request");
	
}
}