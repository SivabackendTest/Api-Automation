package Apimethods;



import freemarker.core.ReturnInstruction.Return;

public class Payload extends AuthorizationToken {
	
	
	public static String businessupdatepayload(String businessName, String typetext ) {
	String payload="{\"businessName\":\""+businessName+"\", \"type\":\""+typetext+"\"}";
	return payload;
}
	public static String postsignup(String Email,String Uid) {
		String payload="{\r\n"
				+ "    \"email\": \"akhiladevikatra2564@yopmail.com\",\r\n"
				+ "    \"uid\": \"yhGRbU4bvcfU2O3jnfVzdPyzdOi2\",\r\n"
				+ "    \"device\": {\r\n"
				+ "        \"token\": \"fWJKNjIgTaO0JSMmIu90K5:APA91bEabc8DaG8bArD5-TbmCeDwV9WfOwgijv8fa6SawL53UosaDkoGHRrPAzejQ20QdTWehiSIAdRSVLVKyXT-eNe103cmB_MI3Ep-hgWRYjzGbfMGAkm8pBW78pvC6UAcNiD1PJN-\",\r\n"
				+ "        \"os_sdk\": \"29\",\r\n"
				+ "        \"os_version\": \"10\",\r\n"
				+ "        \"isPhysicalDevice\": \"true\",\r\n"
				+ "        \"device_name\": \"1804\",\r\n"
				+ "        \"location\": \"Mumbai India\",\r\n"
				+ "        \"ip\": \"103.16.69.194\",\r\n"
				+ "        \"os_type\": \"Android\",\r\n"
				+ "        \"app_version\": \"2.0.0\"\r\n"
				+ "    },\r\n"
				+ "\r\n"
				+ "  \"channelData\": {\r\n"
				+ "    \"name\": \"email\"\r\n"
				+ "  }\r\n"
				+ "}\r\n"
				+ "";
		return payload;
	}
}
